# Stockland Ethiopia ERP 16.1.90

**Stockland ERP** is a role-based, responsive operations and finance platform for Stockland Ethiopia, supporting the central warehouse, branches, Product Master, retail operations, procurement, finance, reporting and payroll.





## Owner-only wholesale surplus protection — 16.1.87

- Adds a read-only Owner dashboard recommendation calculated from the Product Master and inventory ledger. It shows central physical/reserved/available quantities, each active branch's reorder level, branch current availability, picked/in-transit quantities, open requests, approved-but-undispatched quantities, active reservations, additional unrequested branch top-ups, and the Central Warehouse reorder floor.
- The safe wholesale suggestion is calculated per stockable variant. It protects all active branches even if they have not submitted a requisition, protects pending Requested/Reviewed requisitions and direct transfer requests, protects approved-uncollected commitments not already covered by reservations, treats picked/in-transit quantities as branch inbound, and withholds the configured central reorder floor.
- Read-only advice never posts, reserves, edits, creates a notification, changes a requisition, or writes to the ledger/audit chain. The Owner can edit a suggested quantity and open the existing wholesale form. The actual sale endpoint recalculates protection inside its transaction before posting.
- Wholesale advice and wholesale POST are restricted to the active Stockland Owner profile on the server. The frontend bootstrap reports wholesale capability only for Owner and the menu/form remain hidden/blocked for other roles. Role-capability sync markers are not changed.
- A sale above the current safe suggestion requires an explicit Owner confirmation plus a reason (minimum 10 characters) that is recorded with the existing wholesale sale audit event. If a fresh recalculation differs from the displayed advice, the submission fails and must be reviewed again. If ledger/stock integrity is uncertain for the SKU, a wholesale sale is blocked even if the Owner tries to override.
- Uses the existing 49-table contract. No schema version, table definition, transaction history, notification queue, role-capability migration or live record is changed by installing this UI/API update. Read query failure is fail-closed, never interpreted as zero.

**Acceptance boundary:** the isolated surplus-math test suite and local code/package checks are not a live database certification. Exact-version GitHub CI/Semgrep and authenticated WordPress/MariaDB deep integrity/workflow testing remain pending. Back up files and database, verify restore/rollback, then run the live Deep Integrity Audit before production acceptance.

## Exact-reference SaaS Command Center — 16.1.86

- Aligns the desktop shell to the supplied screenshot: 228px navy sidebar, 56px white toolbar, global search as the central top-bar focus, compact notifications/location/profile controls, and an accessible hamburger that collapses or expands the sidebar. Command palette, SOP guide, theme, WordPress Dashboard and sign-out remain available in the profile menu.
- Uses the brand-strip crop from the supplied dashboard reference as a first-party sidebar header asset. It is included in the plugin package and service-worker precache.
- Reorganizes existing authorized navigation into compact expandable Sales & POS, Inventory, Warehouse, Purchase & Procurement and Management groups; every existing route remains role/capability filtered and directly selectable.
- Rebalances the dashboard to match the sample: live welcome/date row, four compact KPI cards (active/configured branches), sales line chart without an extra total block, category doughnut with a full readable total, six sample-aligned role-filtered quick actions, low-stock alerts, flat branch totals, recent workflow activity, compact recent transaction sheet, and the existing apparel banner.
- Adds global-search CSS isolation from WordPress/theme/Elementor rules and a Bootstrap 5.3.8 light-theme variable bridge; results remain hidden until the existing search handler opens them. API route, result IDs and ARIA controls are preserved.
- Responsive rules keep the desktop/tablet header compact, stack analytics before mobile width, and preserve the existing card-based mobile tables. No fake production figures or transactions are added.
- This is cumulative from 16.1.84 and includes the recorded 16.1.85 search/Bootstrap compatibility corrections. No business controller, role authority, SOP transition, ledger, payroll calculation or schema version changes.

**Acceptance boundary:** the package and local smoke tests do not replace authenticated testing on the live WordPress/MariaDB installation. The user-provided live System Control screen reported 16.1.83 with the existing 49-table schema; this cumulative 16.1.86 package has not been deployed. Exact-version GitHub CI/Semgrep and authenticated host acceptance remain pending; back up files/database and verify restore before deploying.

## Source-quality and REST message-context remediation — 16.1.90

- Keeps payroll validation and allowance-reconciliation errors as plain REST message data. The existing frontend renders toast text with `textContent`, avoiding HTML interpretation and entity double-encoding.
- Applies reviewed WordPress coding-standard alignment to the payroll statutory validator, System Health diagnostics and wholesale advisory/query code; no calculation, query predicate, authority or workflow transition changes.
- Documents only the 18 established REST controller filename exceptions, maps the 36 already-registered Stockland capabilities in the source-analysis ruleset, and narrowly documents prepared live wholesale reads that intentionally remain uncached.
- Preserves the 49-table contract, database schema markers, role capability IDs, variant/SKU effective-date history, immutable stock ledger, current payroll v3 statutory calculation, Purchase Order/GRN/PLEDGER/GL behavior and existing approval/SOP paths. No schema migration or business-data write is included.
- Keeps the six CSS modules, compiled CSS bundles, Bootstrap 5.3.8 and original logos unchanged from 16.1.89. The plugin and route/cache identity are bumped to invalidate stale frontend assets; no unverified visual redesign is bundled.

**Acceptance boundary:** source/package verification does not equal live acceptance. Production certification still requires a verified backup, authenticated live deep-integrity/ledger audit, role-by-role SOP checks, physical-device PWA acceptance and tested restore/rollback.

## Four-theme header and real standalone install UX — 16.1.89

- Preserves the exact four themes (Stockland Sapphire, Emerald, Royal Violet and Copper), their existing primary/navy colors, and the `stockland_erp_theme` browser preference key. No palette is renamed or removed.
- Header, global-search focus, profile dropdown, action hover/focus, and mobile controls now derive colors from the selected theme tokens. `meta[name=theme-color]` follows the selected primary color when the theme changes.
- The existing Install App entry remains available through the profile/mobile menu. On supported platforms it invokes the browser’s real PWA installation prompt; the fallback now explains Android/iOS/Windows behavior and distinguishes standalone PWA installation from native EXE/APK packages. No fake installer links or placeholder binaries are added.
- Bootstrap 5.3.8 and original Stockland logo files are inherited unchanged from 16.1.88. Business workflows, database schema, Order/GRN/PLEDGER/GL/audit/authority code and payroll policy are unchanged.

## Premium classic SaaS dashboard — 16.1.84

- Reorganizes the Command Center into a welcome/date row, four live KPI cards, posted-sales trend and category mix, role-aware quick actions, a low-stock alert list, authorized-location stock summaries, recent workflow activity, an operational queue, and recent transactions.
- Keeps all displayed figures data-bound to the existing bootstrap/dashboard-insights/notifications APIs. Example figures in the design reference are not hardcoded into production views. Empty/error states remain explicit when the API returns no rows or fails.
- Preserves the existing left navigation and mobile MENU, role-scoped action links, dashboard refresh, chart loading, transaction table actions, low-stock and branch-inventory navigation, and existing 49-table business contract.
- Adds a bundled Stockland apparel hero image to the footer banner and adjusts the dashboard’s responsive breakpoint: below 1100px the analytics workspace stacks instead of squeezing the chart and right rail into narrow columns. Mobile KPI, quick-action, alert and branch cards stay responsive; headings are not sticky.
- This is a front-end presentation refinement. No data is seeded, no schema migration runs, and no backend role, ledger, POS, requisition, receiving, transfer, finance or payroll logic is changed.

**Release acceptance boundary:** local PHP/JS/CSS/package and synthetic browser smoke tests are not equivalent to authenticated live-site acceptance. Exact 16.1.84 GitHub CI/Semgrep and production WordPress/MariaDB tests are pending; live dashboard numbers must come from the installed application APIs. Back up files and database and verify restore/rollback before deploying.

## Deep audit corrections in 16.1.83 — cumulative, scope-preserving

- Removes the duplicate Workspace dropdown and duplicate-navigation event handlers while retaining role-scoped sidebar navigation and mobile MENU. Page headings and table headers stay in normal document flow.
- Fixes the Retail POS page gate to read the `sale` capability key returned by the actual bootstrap payload; authorized users were previously denied the checkout form by a frontend key mismatch.
- Restores the missing **Stock Count & Approval** frontend view. The view calls the existing protected count-preview, count-commit, batch-report/decision and manual-reconciliation endpoints; server-side permissions, scope resolution, workflow audit, locking and ledger posting remain the source of truth.
- Restores the manual stock-adjustment queue and authorized Owner/Management decision controls around the existing reconciliation decision route. Count-batch approvals remain separate from manual adjustment approvals.
- Fixes the physical-count batch table to display `total_abs_variance` as **Absolute variance units** rather than referencing a nonexistent `variance_lines` response field.
- Fixes printing at phone-width layouts by restoring responsive tables, headers, rows and cells to native table display only inside `@media print`, and suppresses phone-only data-label pseudo-labels; responsive cards continue to work on screen.
- Bumps plugin and frontend route/cache identity to 16.1.83 so updated UI assets are refreshed. No business schema, database version, REST permission, POS, finance, payroll, ledger or posting-service change is included.
- Exact 16.1.83 GitHub CI and authenticated WordPress host acceptance are pending. The local browser harness uses mock endpoints and does not prove live database writes, backup restoration or rollback. Back up the live site and test on staging before production replacement.

## UI refinement carried forward in 16.1.82 — SOP-preserving

- Improves notification-card hierarchy, touch target size, metadata wrapping, keyboard focus feedback and reduced-motion behavior.
- Suppresses only an exact case-insensitive duplicate notification title/body; unique message content remains visible.
- Formats Product Master, Inventory and report data as compact spreadsheet-style grids with Times New Roman typography and print rules. Mobile data-label cards remain responsive on screen and return to tabular form when printed. Requisition review, purchase-order opening, mark-read hooks, server authorization, payroll review, REST endpoints and the 49-table schema contract remain unchanged.
- The UI subsection describes presentation-only changes; payroll and System Health corrections are documented separately below. The cumulative update does not change business SOPs, role authority, inventory posting, ledger history, or schema migration policy.

## Payroll workflow and readiness corrections carried forward in 16.1.82

- Owner tax classification is a separate Owner-only action for each existing allowance component. It can change TAXABLE/EXEMPT treatment only (not the amount); EXEMPT needs a legal basis, evidence reference and explicit Owner confirmation. The server checks that the component snapshot reconciles before mutation, recalculates and audits transactionally, and preserves every other component. Management cannot change exemption totals from its draft amount editor.


- Management’s HR & Payroll workspace uses two collapsed setup panels: Add employee and Create monthly payroll. The payroll period key, start date and end date prefill the current full calendar month and remain editable.
- The payroll table now leads users through Generate → Review / Edit Draft → Submit for Owner Approval. The review opens one period and its employee lines, showing base, gross, taxable income, PAYE, employee and employer pension, other deductions, net pay, and allowance classification.
- Draft line adjustments recalculate through the existing server-side statutory service and are audited. Submitted, approved and paid periods cannot be edited; the Owner still makes the independent approval/GL decision and separately records the bank/cash payment.
- Legacy draft lines must be classified and recalculated under the current rule version before submission. An unverified line prevents submission; unsupported or malformed exemption evidence fails closed. Existing verified exemption evidence is preserved when only an unrelated draft value changes.
- The current installed PAYE rule remains `ET-PAYE-1395-2025-v3-PENSION-BASE`: employee pension is deducted from taxable gross components before PAYE. The ETB 30,000 regression is taxable base 27,900, PAYE 7,715, employee pension 2,100, and net pay 20,185. The browser preview uses the same two-decimal rounding approach as the server. Historical posted payroll is not recalculated. No table/schema or database-version change is included.
- These are source-level changes only. No payroll period was generated and no real salary, payroll journal or employee payment was written. Exact 16.1.82 source/package CI and authenticated WordPress acceptance remain separate release gates. The existing deployed formula has been restored from the supplied 16.1.78 plugin; this package does not independently certify statutory interpretation, so obtain qualified Ethiopian payroll/tax review before changing the live rule.


## System Health and payroll readiness in 16.1.82

- System Health and payroll generation use one server-side compensation-readiness validator so they cannot silently disagree about whether the same effective-dated record is safe for payroll.
- Standard Management-prepared compensation stays valid when required fields are present, all allowances are taxable, the exemption total is zero, and pensionable salary equals base salary. Owner-only exemptions and non-standard pensionability remain backed by a documented basis and the required component evidence.
- Health groups unresolved payroll configuration by reason and provides a direct route to HR & Payroll. It does not expose salary values in health diagnostics, change compensation, or write transactions.
- When payroll readiness is the only failed deep-health gate, the UI identifies the issue as a payroll-specific operational warning rather than suggesting that unrelated verified ERP workflows are unavailable. Other failed mandatory gates remain visible and are not masked.
- Malformed non-empty allowance JSON, unknown tax treatment, mismatched component totals, and non-standard pensionability without a sufficient basis fail closed. Legacy records with a genuinely absent component snapshot remain compatible only where no exemption is claimed and the stored taxable totals can be represented safely.
- The v3 pension-first PAYE rule and its ETB 30,000 regression are preserved from the supplied live 16.1.78 plugin. No historical posted payroll is rewritten and no database schema or business SOP is changed by this update.

## Cumulative workflow corrections through 16.1.78

- Requisition creation requires a stable retry key; identical retries return the existing request and a reused key with different content returns a conflict.
- Branch requisition drafts display live branch availability and read-only Central Warehouse/peer-branch sourcing. A failed source lookup is not presented as zero stock and does not mutate inventory.
- The Central Warehouse Manager may PICK NOW from an Approved requisition or choose RESERVE / ASSIGN when a pickup appointment is needed. A Warehouse Employee may pick only after the requisition is Reserved. The server rechecks role, row-locked state, available stock, active reservation, ledger dispatch, workflow and audit before committing.
- The current installed PAYE rule `ET-PAYE-1395-2025-v3-PENSION-BASE` calculates PAYE on taxable salary and taxable allowances after employee pension contribution. The ETB 30,000 regression expects a taxable base of ETB 27,900, PAYE of ETB 7,715, employee pension of ETB 2,100, and net pay of ETB 20,185. This cumulative update deliberately retains that live rule and does not silently migrate existing compensation records or rewrite posted payroll. Payroll periods use one month input; the server derives the first and last calendar dates. Existing DRAFT lines are not automatically duplicated or rewritten by a new calculation run.
- Owner-created corporate expenses remain pending and unposted rather than self-approving or creating an unreviewed GL journal.

## Included capabilities

- Data-backed role-scoped dashboard with posted-sales trend, category mix, branch performance, recent transactions and explicit empty/error states; responsive desktop, tablet and mobile shell with persistent operational sidebar.
- Product Master and live SKU lookup for stockable products and variants.
- Retail POS and branch-scoped Daily POS Import from external POS Excel workbooks.
- Inventory, requisitions, transfers, Central Warehouse receiving, returns, stock count and reconciliation.
- Finance & Procurement, supplier and customer master data, purchase orders, supplier invoice/AP, customer AR, payment allocation, expense workflows, general ledger and financial reporting.
- HR and payroll, user/organization management, audit log and system-health tools.

## Finance & Procurement workflows

**Purchase orders:** Management selects an existing active supplier and existing stockable Product Master SKUs, then enters quantity and unit cost for each line. The purchase order can be created and submitted without first creating an AP invoice or AR transaction. The Owner makes the independent approval decision. The Central Warehouse Manager records the actual accepted quantity against the approved order.

**Supplier invoice and accounts payable:** Management prepares an invoice against the Owner-approved purchase order and recorded receiving. The Owner's separate invoice decision posts the matched accounting entries. Payments are recorded and allocated as a separate step against posted invoices.

**Branch expenses:** The active Branch Manager enters and makes the final decision on expenses for the assigned branch. The branch is derived from the active ERP profile; the form does not let the user claim another branch.

**Central Warehouse expenses:** The active Central Warehouse Manager enters and makes the final decision on expenses for Central Warehouse.

**Management and Owner expenses:** Each role records its own corporate expense without choosing a branch. Management's corporate expense remains pending until the Owner makes an independent decision. The Owner cannot approve their own corporate expense: it remains PENDING and unposted until an independent approver is explicitly authorized by the approved SOP. Both roles can review location-expense reports but do not decide branch or warehouse expenses.

## Operating authority

| Work | Operational entry | Decision / final authority |
|---|---|---|
| Daily external POS workbook | Authorized branch salesperson or Branch Manager | Branch Manager releases the staged import to ERP |
| Branch expense | Assigned Branch Manager | Assigned Branch Manager |
| Central Warehouse expense | Central Warehouse Manager | Central Warehouse Manager |
| External product purchase | Management | Independent Owner approval |
| Purchase receiving | Central Warehouse Manager | Actual accepted quantity posts to inventory |
| Supplier invoice/AP and finance payment | Management prepares the transaction | Owner makes the configured finance decision |
| Corporate expense | Owner or Management, each for their own expense | Management submits for Owner approval; Owner-created expenses remain pending and unposted until a separate approver is authorized; no self-posting |

The ERP enforces the authority model on the server as well as in the interface. A hidden button is not treated as an access-control mechanism.

## Install or update in WordPress

1. Back up the current plugin files and WordPress database before an in-place update.
2. In WordPress, open **Plugins → Add New Plugin → Upload Plugin** and select the Stockland ERP 16.1.87 installer ZIP.
3. For an in-place update, choose the option to replace the existing Stockland ERP plugin when WordPress offers it. For a fresh installation, install and activate the plugin.
4. Open the Stockland ERP front end. Use the Owner's Users & Organization controls to assign each active ERP role and its branch/location.
5. Use **Finance & Procurement** from the ERP navigation for purchasing, expenses, AP/AR, payments and financial reporting.

The update preserves the existing business-data model: 49 application tables across Core/Operations, Accounting/Procurement and HR/Payroll, with the existing core, accounting and HR schema-version markers. It is a cumulative update and does not create a parallel plugin or reset existing business data.

## Product entry and purchase workflow

Product Master is the SKU catalog. Adding a product master record does not itself post stock. For an external supplier purchase, select a stockable SKU from the live picker, enter quantity and unit cost, and create/submit the purchase order. Receiving the Owner-approved order is the stock-posting step. Branch replenishment continues through the requisition and transfer workflows.

## Design and compatibility

The interface uses the local Bootstrap 5.3.8 stylesheet and a compact six-module responsive CSS build. Finance forms use live data, role-scoped actions and server-side validation. The plugin does not seed demonstration sales, stock movements, payroll entries, orders or customer transactions.



## 16.1.88 mobile header/profile and procurement regression verification

- Inherits the existing `assets/stockland-logo.jpg` and localized `A.logo` URL without replacing brand assets. At widths 390px and below, keeps the top-header logo visible at 28px and constrains brand copy rather than hiding company identity.
- Fixes a verified Purchase Order form defect: after an async Finance data refresh the UI could append a second blank line with a required cost field. The initializer now creates the default line only when none exists. Regression-tested create → submit → independent Owner approve → actual-quantity PO receipt with an idempotency key, plus Owner supplier invoice/payment decisions; all browser API calls were mocked and created no real records.
- Positions the profile menu from the actual profile trigger’s bounding rectangle. It recalculates on resize, orientation changes, document scroll and VisualViewport updates, clamps the menu to the viewport, and preserves Escape/outside-click/ARIA behavior. Selecting Command Palette, SOP Guide or Appearance dismisses the profile menu first.
- Purchase order and PLEDGER/GL path was reviewed as an end-to-end contract: Management drafts/submits; Owner approval is independent; PO submission/approval does not post stock or ledgers; only Central Warehouse receiving against Owner-approved PO lines posts inventory ledger, balanced GRNI/input-tax journal and audit/notifications in one transaction; supplier invoice/AP and payment paths remain explicit follow-on steps; a failed journal/audit/notification/commit rolls back. Existing code was not modified in these server workflows.
- No DDL/schema/role sync, payroll record or business transaction changed. Live System Health evidence supplied for 16.1.87 has audit chain/supplemental scans passing but payroll compensation classification still failing for five missing active-employee compensation records; that failure remains visible and is not bypassed.
- Exact-version GitHub CI/Semgrep and authenticated live-host tests are pending because this session’s GitHub access is read-only and has no authenticated WordPress/MariaDB control.

## Acceptance boundary — 16.1.87 Owner wholesale surplus

- Local isolated surplus calculations: 18/18 pass, including stock 500 / four branches / floor 2 / warehouse floor 200, per-SKU floor precedence, reservations, pending and approved-but-uncollected requests, in-transit quantities, negative stock and query failures.
- Owner wholesale UI browser tests use synthetic data only and verify branch details, review-to-sale prefill, safe-sale submission, reasoned override above the safe suggestion, and that no sidebar/command-palette wholesale entrypoint is available outside the Owner dashboard.
- Regression suite: 47/47 PHP files lint; payroll/Health 22/22; notification drawer 15/15; payroll preview 6 assertions; release/source invariants 19/19; CSS rebuild/minification, JS syntax and JSON validation pass.
- The advisory endpoint is a read-only `GET`. It performs no stock reservation, sale, notification, order, ledger, or audit write. Failed queries and unreconciled inventory holds suppress advice instead of appearing as zero stock/need.
- Existing wholesale `POST` runs the existing transaction/order/ledger/PLEDGER/GL/audit workflow. The server recalculates surplus during the sale transaction; exceeding the safe suggestion requires the exact fresh advisory amount, explicit Owner confirmation and a documented reason (at least 10 characters). Inventory integrity holds cannot be overridden.
- No schema change, new table, capability synchronization/version change, synthetic business record, notification insertion or live database mutation is included in package preparation. Database schema version remains `16.1.1`; business table contract remains 49.

**Live acceptance is still required:** the quick Health screen shown by the user explicitly says the deep audit is deferred/unverified. This session does not have an authenticated WordPress/MariaDB production connection, so the actual live audit-chain hashes, ledger balances, negative-stock/reference scans, order/PLEDGER/AP/AR/GL reconciliation, payroll classification scan, backup restoration/rollback, and live role workflow tests have **not** been run. After making and verifying a backup, run **System Health → RUN DEEP INTEGRITY AUDIT** on the installed system and exercise a real but non-destructive read-only owner recommendation. Do not submit a wholesale sale until the live advice accurately matches the real branch and central stock/queue state. Exact-release GitHub Actions/Semgrep is also pending because the canonical repository integration available here is read-only.

### Historical 16.1.78 global search

The header search is connected to a read-only REST endpoint. Results are scoped by ERP role, capability and assigned location; product/SKU matches do not expose cost/profit data, and customer matches do not expose contact or balance data. Database failures return an error rather than a false empty result. This update preserves the existing 49-table schema contract.

The header search returns active Product Master variants to authorized ERP profiles. Inactive variants are discoverable only by users with the existing `stockland_manage_products` capability and are explicitly labeled `INACTIVE MASTER SKU`; inventory quantity does not define catalog identity. SKU/receipt/PO identifiers use prefix matching, while product/customer/supplier descriptive fields may use text matching.
