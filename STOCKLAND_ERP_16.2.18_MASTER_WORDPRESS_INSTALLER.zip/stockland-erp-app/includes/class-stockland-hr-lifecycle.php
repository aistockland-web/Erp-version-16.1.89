<?php
/**
 * Expanded HRIS schema and effective-dated rule services.
 * All DDL is additive and runs through the protected, bounded setup controller.
 *
 * @package Stockland_ERP
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_HR_Lifecycle {
	const SCHEMA_VERSION = '16.2.1';

	public static function table_keys() {
		return array(
			'hr_workforce_plans','hr_positions','hr_requisitions','hr_candidates',
			'hr_applications','hr_interviews','hr_documents','hr_contracts',
			'hr_onboarding_tasks','hr_shifts','hr_attendance','hr_leave_policies',
			'hr_leave_balances','hr_leave_requests','hr_compensation_components',
			'hr_rule_sets','hr_rule_components','hr_employee_events','hr_payroll_events',
			'hr_payroll_payments','hr_payroll_adjustments','hr_exit_settlements',
			'hr_training_records','hr_performance_reviews',
			'hr_payroll_runs','hr_payroll_run_lines','hr_payroll_run_exceptions',
			'hr_payroll_payment_batches','hr_payroll_payment_items','hr_statutory_remittances',
			'hr_individual_payees','hr_individual_payee_obligations','hr_individual_payee_payments',
			'hr_resources','hr_social_campaigns','hr_social_snapshots','hr_employee_reimbursements'
		);
	}

	/** DDL source for fresh installs. Existing installs create one missing table per protected setup batch. */
	public static function table_ddl( $p, $cc ) {
		$t = array();
		// The setup caller passes the raw wpdb prefix; the logical table service uses prefix + stock_.
		$p .= 'stock_';
		$t[] = "CREATE TABLE {$p}hr_workforce_plans (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			plan_code VARCHAR(40) NOT NULL,
			fiscal_year VARCHAR(20) NOT NULL,
			version_no INT UNSIGNED NOT NULL DEFAULT 1,
			location_id BIGINT UNSIGNED NULL,
			department VARCHAR(120) NOT NULL,
			planned_headcount INT UNSIGNED NOT NULL DEFAULT 0,
			annual_salary_budget DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			other_cost_budget DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			justification TEXT NOT NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			submitted_at DATETIME NULL,
			submitted_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			decision_note VARCHAR(500) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY plan_version (plan_code,version_no), KEY status_year (status,fiscal_year), KEY location_department (location_id,department)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_positions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			position_code VARCHAR(40) NOT NULL,
			title VARCHAR(160) NOT NULL,
			department VARCHAR(120) NOT NULL,
			grade_code VARCHAR(40) NULL,
			location_id BIGINT UNSIGNED NULL,
			headcount_slots INT UNSIGNED NOT NULL DEFAULT 1,
			annual_salary_min DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			annual_salary_max DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			workforce_plan_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY position_code (position_code), KEY location_status (location_id,status), KEY department_grade (department,grade_code)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_requisitions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			requisition_code VARCHAR(40) NOT NULL,
			position_id BIGINT UNSIGNED NOT NULL,
			workforce_plan_id BIGINT UNSIGNED NULL,
			location_id BIGINT UNSIGNED NULL,
			openings INT UNSIGNED NOT NULL DEFAULT 1,
			employment_type VARCHAR(40) NOT NULL DEFAULT 'FULL_TIME',
			target_start_date DATE NULL,
			justification TEXT NOT NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			opened_at DATETIME NULL,
			approved_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			decision_note VARCHAR(500) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY requisition_code (requisition_code), KEY position_status (position_id,status), KEY location_status (location_id,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_candidates (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			candidate_code VARCHAR(40) NOT NULL,
			full_name VARCHAR(180) NOT NULL,
			email VARCHAR(190) NULL,
			phone VARCHAR(60) NULL,
			source VARCHAR(80) NULL,
			consent_at DATETIME NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'NEW',
			notes VARCHAR(500) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY candidate_code (candidate_code), KEY status_created (status,created_at), KEY email (email)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_applications (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			requisition_id BIGINT UNSIGNED NOT NULL,
			candidate_id BIGINT UNSIGNED NOT NULL,
			selected_employee_id BIGINT UNSIGNED NULL,
			applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			stage VARCHAR(24) NOT NULL DEFAULT 'APPLIED',
			screening_score DECIMAL(7,2) NULL,
			decision VARCHAR(24) NOT NULL DEFAULT 'PENDING',
			decision_reason VARCHAR(500) NULL,
			decided_by BIGINT UNSIGNED NULL,
			decided_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY requisition_candidate (requisition_id,candidate_id), KEY requisition_stage (requisition_id,stage), KEY decision (decision)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_interviews (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			application_id BIGINT UNSIGNED NOT NULL,
			interview_round VARCHAR(40) NOT NULL DEFAULT 'INITIAL',
			scheduled_at DATETIME NULL,
			panel_json LONGTEXT NULL,
			scorecard_json LONGTEXT NULL,
			total_score DECIMAL(7,2) NULL,
			recommendation VARCHAR(24) NOT NULL DEFAULT 'PENDING',
			notes VARCHAR(1000) NULL,
			completed_by BIGINT UNSIGNED NULL,
			completed_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY application_round (application_id,interview_round), KEY scheduled_at (scheduled_at)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_documents (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			subject_type VARCHAR(20) NOT NULL,
			subject_id BIGINT UNSIGNED NOT NULL,
			document_type VARCHAR(60) NOT NULL,
			document_reference VARCHAR(190) NOT NULL,
			document_sha256 CHAR(64) NULL,
			issued_on DATE NULL,
			expires_on DATE NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'PENDING_REVIEW',
			verified_by BIGINT UNSIGNED NULL,
			verified_at DATETIME NULL,
			notes VARCHAR(500) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY subject_type_id (subject_type,subject_id), KEY expiry (expires_on,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_contracts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			contract_code VARCHAR(60) NOT NULL,
			contract_type VARCHAR(40) NOT NULL,
			start_date DATE NOT NULL,
			end_date DATE NULL,
			probation_end DATE NULL,
			position_id BIGINT UNSIGNED NULL,
			location_id BIGINT UNSIGNED NULL,
			terms_json LONGTEXT NULL,
			document_id BIGINT UNSIGNED NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			signed_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY contract_code (contract_code), KEY employee_dates (employee_id,start_date,end_date), KEY status_end (status,end_date)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_onboarding_tasks (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			task_code VARCHAR(60) NOT NULL,
			task_title VARCHAR(180) NOT NULL,
			responsible_role VARCHAR(40) NOT NULL DEFAULT 'MANAGEMENT',
			due_date DATE NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
			evidence_reference VARCHAR(190) NULL,
			completed_by BIGINT UNSIGNED NULL,
			completed_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_status (employee_id,status), KEY due_status (due_date,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_shifts (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			shift_code VARCHAR(40) NOT NULL,
			shift_name VARCHAR(100) NOT NULL,
			location_id BIGINT UNSIGNED NULL,
			start_time TIME NOT NULL,
			end_time TIME NOT NULL,
			break_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			effective_from DATE NOT NULL,
			effective_to DATE NULL,
			rule_set_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY shift_code (shift_code), KEY location_effective (location_id,effective_from,effective_to)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_attendance (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			location_id BIGINT UNSIGNED NULL,
			shift_id BIGINT UNSIGNED NULL,
			work_date DATE NOT NULL,
			check_in DATETIME NULL,
			check_out DATETIME NULL,
			ordinary_minutes INT UNSIGNED NOT NULL DEFAULT 0,
			overtime_minutes INT UNSIGNED NOT NULL DEFAULT 0,
			absence_type VARCHAR(30) NULL,
			source VARCHAR(24) NOT NULL DEFAULT 'MANUAL',
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			correction_reason VARCHAR(500) NULL,
			submitted_by BIGINT UNSIGNED NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY employee_work_date (employee_id,work_date), KEY location_date (location_id,work_date), KEY status_date (status,work_date)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_leave_policies (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			policy_code VARCHAR(50) NOT NULL,
			leave_type VARCHAR(40) NOT NULL,
			annual_entitlement_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			max_carry_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			min_notice_days SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			paid_status VARCHAR(16) NOT NULL DEFAULT 'PAID',
			rule_set_id BIGINT UNSIGNED NULL,
			effective_from DATE NOT NULL,
			effective_to DATE NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY policy_effective (policy_code,effective_from), KEY leave_type_dates (leave_type,effective_from,effective_to)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_leave_balances (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			leave_type VARCHAR(40) NOT NULL,
			leave_year SMALLINT UNSIGNED NOT NULL,
			opening_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			accrued_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			used_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			adjusted_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			closing_days DECIMAL(8,2) NOT NULL DEFAULT 0.00,
			updated_by BIGINT UNSIGNED NOT NULL,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY employee_leave_year (employee_id,leave_type,leave_year), KEY leave_year (leave_year,leave_type)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_leave_requests (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			leave_type VARCHAR(40) NOT NULL,
			start_date DATE NOT NULL,
			end_date DATE NOT NULL,
			requested_days DECIMAL(8,2) NOT NULL,
			reason VARCHAR(1000) NULL,
			evidence_reference VARCHAR(190) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED',
			submitted_by BIGINT UNSIGNED NOT NULL,
			submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			decided_by BIGINT UNSIGNED NULL,
			decided_at DATETIME NULL,
			decision_note VARCHAR(500) NULL,
			payroll_period_key VARCHAR(40) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_dates (employee_id,start_date,end_date), KEY status_start (status,start_date)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_compensation_components (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			compensation_id BIGINT UNSIGNED NOT NULL,
			component_type VARCHAR(24) NOT NULL DEFAULT 'ALLOWANCE',
			category VARCHAR(40) NOT NULL,
			label VARCHAR(160) NOT NULL,
			amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			currency VARCHAR(10) NOT NULL DEFAULT 'ETB',
			effective_from DATE NOT NULL,
			effective_to DATE NULL,
			tax_treatment VARCHAR(20) NOT NULL DEFAULT 'TAXABLE',
			exempt_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			taxable_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			pensionable_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			rule_set_id BIGINT UNSIGNED NULL,
			rule_set_version VARCHAR(80) NULL,
			source_hash CHAR(64) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_effective (employee_id,effective_from,effective_to), KEY compensation_id (compensation_id), KEY rule_ref (rule_set_id,rule_set_version)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_rule_sets (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			rule_code VARCHAR(80) NOT NULL,
			rule_type VARCHAR(24) NOT NULL,
			version_label VARCHAR(80) NOT NULL,
			jurisdiction VARCHAR(80) NOT NULL DEFAULT 'ETHIOPIA-FEDERAL',
			effective_from DATE NOT NULL,
			effective_to DATE NULL,
			source_title VARCHAR(240) NOT NULL,
			source_url VARCHAR(500) NOT NULL,
			source_clause VARCHAR(240) NOT NULL,
			source_sha256 CHAR(64) NULL,
			source_publication_date DATE NULL,
			review_status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			rules_json LONGTEXT NOT NULL,
			reviewer_note VARCHAR(1000) NULL,
			submitted_by BIGINT UNSIGNED NULL,
			submitted_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY rule_version (rule_code,version_label), KEY type_effective (rule_type,review_status,effective_from,effective_to)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_rule_components (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			rule_set_id BIGINT UNSIGNED NOT NULL,
			category VARCHAR(40) NOT NULL,
			tax_treatment VARCHAR(20) NOT NULL DEFAULT 'TAXABLE',
			exemption_cap DECIMAL(14,2) NULL DEFAULT NULL,
			pensionable_treatment VARCHAR(24) NOT NULL DEFAULT 'SALARY_ONLY',
			pensionable_cap DECIMAL(14,2) NULL DEFAULT NULL,
			source_clause VARCHAR(240) NOT NULL,
			source_note VARCHAR(1000) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY ruleset_category (rule_set_id,category), KEY category (category)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_employee_events (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			event_type VARCHAR(40) NOT NULL,
			effective_date DATE NOT NULL,
			old_snapshot_json LONGTEXT NULL,
			new_snapshot_json LONGTEXT NOT NULL,
			reason VARCHAR(1000) NOT NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_effective (employee_id,effective_date), KEY event_type (event_type,created_at)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_events (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			entity_type VARCHAR(30) NOT NULL,
			entity_id BIGINT UNSIGNED NOT NULL,
			event_type VARCHAR(40) NOT NULL,
			from_status VARCHAR(24) NULL,
			to_status VARCHAR(24) NULL,
			rule_set_id BIGINT UNSIGNED NULL,
			rule_version VARCHAR(80) NULL,
			payload_sha256 CHAR(64) NOT NULL,
			payload_json LONGTEXT NULL,
			actor_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY entity_history (entity_type,entity_id,id), KEY event_type (event_type,created_at), KEY rule_version (rule_set_id,rule_version)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_payments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			payment_code VARCHAR(60) NOT NULL,
			payroll_period_id BIGINT UNSIGNED NOT NULL,
			payment_type VARCHAR(24) NOT NULL DEFAULT 'EMPLOYEE_NET',
			amount DECIMAL(14,2) NOT NULL,
			currency VARCHAR(10) NOT NULL DEFAULT 'ETB',
			payment_method VARCHAR(30) NOT NULL,
			payment_reference VARCHAR(120) NOT NULL,
			payment_date DATE NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'RECORDED',
			recorded_by BIGINT UNSIGNED NOT NULL,
			recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY payment_code (payment_code), UNIQUE KEY period_type_reference (payroll_period_id,payment_type,payment_reference), KEY payment_date (payment_date,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_adjustments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			source_period_id BIGINT UNSIGNED NULL,
			target_period_key VARCHAR(40) NOT NULL,
			adjustment_type VARCHAR(24) NOT NULL,
			amount DECIMAL(14,2) NOT NULL,
			taxable_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			pensionable_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			reason VARCHAR(1000) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			posted_journal_id BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_period (employee_id,target_period_key), KEY status (status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_exit_settlements (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			settlement_code VARCHAR(60) NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			exit_type VARCHAR(30) NOT NULL,
			exit_date DATE NOT NULL,
			last_work_date DATE NOT NULL,
			reason VARCHAR(1000) NOT NULL,
			components_json LONGTEXT NOT NULL,
			gross_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			taxable_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			exempt_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			tax_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employee_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employer_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			other_deductions_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			net_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			rule_set_id BIGINT UNSIGNED NULL,
			rule_version VARCHAR(80) NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			submitted_by BIGINT UNSIGNED NULL,
			submitted_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			paid_by BIGINT UNSIGNED NULL,
			paid_at DATETIME NULL,
			payment_reference VARCHAR(120) NULL,
			journal_id BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY settlement_code (settlement_code), KEY employee_exit (employee_id,exit_date), KEY status (status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_training_records (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			training_code VARCHAR(60) NOT NULL,
			title VARCHAR(180) NOT NULL,
			provider VARCHAR(180) NULL,
			start_date DATE NULL,
			end_date DATE NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'PLANNED',
			evidence_reference VARCHAR(190) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_dates (employee_id,start_date,end_date), KEY status (status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_performance_reviews (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			review_period VARCHAR(40) NOT NULL,
			reviewer_id BIGINT UNSIGNED NOT NULL,
			goals_json LONGTEXT NULL,
			rating DECIMAL(5,2) NULL,
			outcome VARCHAR(30) NOT NULL DEFAULT 'DRAFT',
			notes VARCHAR(1000) NULL,
			reviewed_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY employee_period (employee_id,review_period), KEY reviewer (reviewer_id)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_runs (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			run_code VARCHAR(60) NOT NULL,
			idempotency_key VARCHAR(100) NOT NULL,
			run_kind VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
			parent_run_id BIGINT UNSIGNED NULL,
			period_key VARCHAR(40) NOT NULL,
			start_date DATE NOT NULL,
			end_date DATE NOT NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			rule_set_id BIGINT UNSIGNED NULL,
			rule_version VARCHAR(80) NULL,
			rule_source_sha256 CHAR(64) NULL,
			rules_snapshot_json LONGTEXT NULL,
			input_snapshot_sha256 CHAR(64) NULL,
			calculation_sha256 CHAR(64) NULL,
			exception_count INT UNSIGNED NOT NULL DEFAULT 0,
			employee_count INT UNSIGNED NOT NULL DEFAULT 0,
			gross_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			taxable_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			exempt_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			reimbursement_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			paye_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employee_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employer_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			other_deduction_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employer_cost_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			net_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			posted_journal_id BIGINT UNSIGNED NULL,
			submitted_by BIGINT UNSIGNED NULL,
			submitted_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			closed_by BIGINT UNSIGNED NULL,
			closed_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY run_code (run_code), UNIQUE KEY idempotency_key (idempotency_key),
			KEY period_status (period_key,status), KEY run_dates (start_date,end_date), KEY ruleset (rule_set_id,rule_version)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_run_lines (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			run_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			employee_code VARCHAR(40) NOT NULL,
			source_snapshot_json LONGTEXT NOT NULL,
			calculation_json LONGTEXT NOT NULL,
			source_snapshot_sha256 CHAR(64) NOT NULL,
			calculation_sha256 CHAR(64) NOT NULL,
			gross_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			taxable_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			exempt_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			reimbursement_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			paye_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employee_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employer_pension_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			other_deduction_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			employer_cost_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			net_total DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY run_employee (run_id,employee_id), KEY employee_id (employee_id), KEY calc_hash (calculation_sha256)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_run_exceptions (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			run_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NULL,
			exception_code VARCHAR(60) NOT NULL,
			severity VARCHAR(16) NOT NULL DEFAULT 'BLOCKER',
			summary VARCHAR(1000) NOT NULL,
			evidence_reference VARCHAR(190) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
			resolved_by BIGINT UNSIGNED NULL,
			resolved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), KEY run_status (run_id,status), KEY employee_code (employee_id,exception_code)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_payment_batches (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			batch_code VARCHAR(60) NOT NULL,
			idempotency_key VARCHAR(100) NOT NULL,
			run_id BIGINT UNSIGNED NOT NULL,
			payment_method VARCHAR(16) NOT NULL,
			currency VARCHAR(10) NOT NULL DEFAULT 'ETB',
			total_requested DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			total_paid DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			external_batch_reference VARCHAR(190) NULL,
			bank_statement_reference VARCHAR(190) NULL,
			payment_journal_id BIGINT UNSIGNED NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			reconciled_by BIGINT UNSIGNED NULL,
			reconciled_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY batch_code (batch_code), UNIQUE KEY idempotency_key (idempotency_key),
			KEY run_status (run_id,status), KEY external_reference (external_batch_reference)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_payroll_payment_items (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			batch_id BIGINT UNSIGNED NOT NULL,
			run_line_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			employee_code VARCHAR(40) NOT NULL,
			amount DECIMAL(14,2) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
			external_payment_reference VARCHAR(190) NULL,
			failure_reason VARCHAR(500) NULL,
			settled_by BIGINT UNSIGNED NULL,
			settled_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY batch_run_line (batch_id,run_line_id), KEY employee_status (employee_id,status), KEY reference_status (external_payment_reference,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_statutory_remittances (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			remittance_code VARCHAR(60) NOT NULL,
			run_id BIGINT UNSIGNED NOT NULL,
			statutory_type VARCHAR(30) NOT NULL,
			amount_due DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			due_date DATE NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			filing_reference VARCHAR(190) NULL,
			payment_reference VARCHAR(190) NULL,
			receipt_resource_id BIGINT UNSIGNED NULL,
			confirmed_amount DECIMAL(14,2) NULL,
			reconciled_by BIGINT UNSIGNED NULL,
			reconciled_at DATETIME NULL,
			rule_set_id BIGINT UNSIGNED NULL,
			rule_version VARCHAR(80) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY remittance_code (remittance_code), UNIQUE KEY run_type (run_id,statutory_type), KEY due_status (due_date,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_individual_payees (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			payee_code VARCHAR(60) NOT NULL,
			full_name VARCHAR(180) NOT NULL,
			payee_type VARCHAR(40) NOT NULL,
			residency_status VARCHAR(30) NOT NULL DEFAULT 'UNKNOWN',
			registration_status VARCHAR(30) NOT NULL DEFAULT 'UNKNOWN',
			tin_ciphertext LONGTEXT NULL,
			tin_last4 VARCHAR(4) NULL,
			license_ciphertext LONGTEXT NULL,
			license_last4 VARCHAR(4) NULL,
			identity_resource_id BIGINT UNSIGNED NULL,
			contact_email VARCHAR(190) NULL,
			contact_phone VARCHAR(60) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY payee_code (payee_code), KEY type_status (payee_type,status), KEY tin_last4 (tin_last4)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_individual_payee_obligations (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			obligation_code VARCHAR(60) NOT NULL,
			payee_id BIGINT UNSIGNED NOT NULL,
			obligation_type VARCHAR(40) NOT NULL,
			contract_reference VARCHAR(190) NULL,
			campaign_reference VARCHAR(190) NULL,
			agreement_resource_id BIGINT UNSIGNED NULL,
			deliverables_json LONGTEXT NOT NULL,
			content_url VARCHAR(1000) NULL,
			cash_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			in_kind_value DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			currency VARCHAR(10) NOT NULL DEFAULT 'ETB',
			deliverables_accepted_by BIGINT UNSIGNED NULL,
			deliverables_accepted_at DATETIME NULL,
			tax_decision_status VARCHAR(24) NOT NULL DEFAULT 'LEGAL_REVIEW',
			tax_decision_json LONGTEXT NULL,
			tax_rule_set_id BIGINT UNSIGNED NULL,
			tax_rule_version VARCHAR(80) NULL,
			withholding_amount DECIMAL(14,2) NULL,
			net_payable_amount DECIMAL(14,2) NULL,
			expense_account_code VARCHAR(20) NULL,
			payable_account_code VARCHAR(20) NULL,
			payable_journal_id BIGINT UNSIGNED NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY obligation_code (obligation_code), KEY payee_status (payee_id,status), KEY tax_status (tax_decision_status,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_individual_payee_payments (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			payment_code VARCHAR(60) NOT NULL,
			obligation_id BIGINT UNSIGNED NOT NULL,
			payee_id BIGINT UNSIGNED NOT NULL,
			gross_cash_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			withholding_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			net_paid_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			payment_method VARCHAR(16) NOT NULL,
			external_payment_reference VARCHAR(190) NOT NULL,
			bank_statement_reference VARCHAR(190) NULL,
			withholding_receipt_reference VARCHAR(190) NULL,
			payment_journal_id BIGINT UNSIGNED NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'RECORDED',
			recorded_by BIGINT UNSIGNED NOT NULL,
			recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY payment_code (payment_code), UNIQUE KEY obligation_reference (obligation_id,external_payment_reference), KEY payee_status (payee_id,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_resources (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			resource_code VARCHAR(60) NOT NULL,
			title VARCHAR(190) NOT NULL,
			description VARCHAR(1000) NULL,
			role_code VARCHAR(60) NOT NULL DEFAULT 'ALL',
			language_code VARCHAR(12) NOT NULL DEFAULT 'en-am',
			resource_type VARCHAR(40) NOT NULL,
			version_label VARCHAR(40) NOT NULL,
			supersedes_resource_id BIGINT UNSIGNED NULL,
			private_file_ref VARCHAR(100) NOT NULL,
			file_sha256 CHAR(64) NOT NULL,
			file_name VARCHAR(190) NOT NULL,
			mime_type VARCHAR(120) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			created_by BIGINT UNSIGNED NOT NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY resource_code (resource_code), UNIQUE KEY private_file_ref (private_file_ref), KEY role_status (role_code,status), KEY type_language (resource_type,language_code), KEY supersedes_resource (supersedes_resource_id)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_social_campaigns (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			campaign_code VARCHAR(60) NOT NULL,
			title VARCHAR(190) NOT NULL,
			platform VARCHAR(40) NOT NULL,
			account_label VARCHAR(120) NOT NULL,
			manager_user_id BIGINT UNSIGNED NULL,
			start_date DATE NULL,
			end_date DATE NULL,
			budget DECIMAL(14,2) NOT NULL DEFAULT 0.00,
			status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY campaign_code (campaign_code), KEY platform_dates (platform,start_date,end_date), KEY manager_status (manager_user_id,status)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_employee_reimbursements (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			claim_code VARCHAR(60) NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			location_id BIGINT UNSIGNED NULL,
			expense_category VARCHAR(60) NOT NULL,
			description VARCHAR(1000) NOT NULL,
			business_purpose VARCHAR(1000) NOT NULL,
			incurred_date DATE NOT NULL,
			amount DECIMAL(14,2) NOT NULL,
			currency VARCHAR(10) NOT NULL DEFAULT 'ETB',
			receipt_resource_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
			submitted_by BIGINT UNSIGNED NULL,
			submitted_at DATETIME NULL,
			approved_by BIGINT UNSIGNED NULL,
			approved_at DATETIME NULL,
			expense_account_code VARCHAR(20) NULL,
			payable_account_code VARCHAR(20) NULL,
			accrual_journal_id BIGINT UNSIGNED NULL,
			payment_method VARCHAR(16) NULL,
			payment_reference VARCHAR(190) NULL,
			bank_statement_reference VARCHAR(190) NULL,
			payment_journal_id BIGINT UNSIGNED NULL,
			paid_by BIGINT UNSIGNED NULL,
			paid_at DATETIME NULL,
			reviewer_note VARCHAR(1000) NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY claim_code (claim_code), KEY employee_status (employee_id,status), KEY location_status (location_id,status), KEY incurred_date (incurred_date)
		) ENGINE=InnoDB {$cc};";
		$t[] = "CREATE TABLE {$p}hr_social_snapshots (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			snapshot_code VARCHAR(60) NOT NULL,
			campaign_id BIGINT UNSIGNED NULL,
			platform VARCHAR(40) NOT NULL,
			account_label VARCHAR(120) NOT NULL,
			period_start DATE NOT NULL,
			period_end DATE NOT NULL,
			report_as_of DATETIME NOT NULL,
			source_kind VARCHAR(24) NOT NULL DEFAULT 'MANUAL_EXPORT',
			source_reference VARCHAR(1000) NULL,
			source_sha256 CHAR(64) NULL,
			reach_count BIGINT UNSIGNED NULL,
			view_count BIGINT UNSIGNED NULL,
			watch_time_minutes DECIMAL(14,2) NULL,
			engagement_count BIGINT UNSIGNED NULL,
			follower_delta BIGINT NULL,
			click_count BIGINT UNSIGNED NULL,
			lead_count BIGINT UNSIGNED NULL,
			spend_amount DECIMAL(14,2) NULL,
			attributed_sales DECIMAL(14,2) NULL,
			attribution_method VARCHAR(190) NULL,
			notes VARCHAR(1000) NULL,
			captured_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id), UNIQUE KEY snapshot_code (snapshot_code), KEY account_asof (platform,account_label,report_as_of), KEY campaign_dates (campaign_id,period_start,period_end)
		) ENGINE=InnoDB {$cc};";

		return $t;
	}

	public static function write_event( $entity_type, $entity_id, $event_type, $from_status, $to_status, $payload, $rule_set_id = null, $rule_version = null ) {
		$json = wp_json_encode( $payload );
		if ( ! is_string( $json ) ) { return false; }
		$inserted = Stockland_DB::insert_record(
			Stockland_DB::table( 'hr_payroll_events' ),
			array(
				'entity_type' => sanitize_key( $entity_type ),
				'entity_id' => (int) $entity_id,
				'event_type' => sanitize_key( $event_type ),
				'from_status' => $from_status ? sanitize_key( $from_status ) : null,
				'to_status' => $to_status ? sanitize_key( $to_status ) : null,
				'rule_set_id' => $rule_set_id ? (int) $rule_set_id : null,
				'rule_version' => $rule_version ? sanitize_text_field( $rule_version ) : null,
				'payload_sha256' => hash( 'sha256', $json ),
				'payload_json' => $json,
				'actor_id' => (int) get_current_user_id(),
			)
		);
		if ( ! $inserted ) { return false; }
		return Stockland_Audit::log(
			get_current_user_id(), null, 'HR_' . strtoupper( sanitize_key( $event_type ) ),
			null, null, $from_status, $to_status, substr( $json, 0, 500 ), strtoupper( $entity_type ) . (int) $entity_id
		);
	}

	/**
	 * Verify the exact signed legal-opinion object linked to a statutory rule.
	 *
	 * The SHA-256 is checked against both the HR document record and decrypted
	 * vault bytes. A hash-shaped value or typed reviewer note is not evidence.
	 *
	 * @param array  $payload Rule JSON payload.
	 * @param int    $rule_set_id Rule-set ID the opinion covers.
	 * @param string $expected_status Required HR document status.
	 * @param bool   $lock Whether to lock the document row in the caller transaction.
	 * @return bool True only when the matching private PDF/DOCX decrypts and hashes correctly.
	 */
	public static function verify_legal_opinion_document( $payload, $rule_set_id, $expected_status = 'APPROVED', $lock = false ) {
		if ( ! is_array( $payload ) || ! isset( $payload['qualified_legal_review'] ) || ! is_array( $payload['qualified_legal_review'] ) ) { return false; }
		$q = $payload['qualified_legal_review'];
		$document_id = filter_var( $q['opinion_document_id'] ?? null, FILTER_VALIDATE_INT );
		$expected_hash = strtolower( (string) ( $q['opinion_sha256'] ?? '' ) );
		if ( ! $document_id || $document_id < 1 || ! preg_match( '/^[a-f0-9]{64}$/D', $expected_hash ) || (int) $rule_set_id < 1 ) { return false; }

		global $wpdb;
		$sql = $wpdb->prepare(
			'SELECT id,subject_type,subject_id,document_type,document_reference,document_sha256,status,verified_by,verified_at FROM %i WHERE id=%d AND subject_type=%s AND subject_id=%d AND document_type=%s LIMIT 1',
			Stockland_DB::table( 'hr_documents' ),
			(int) $document_id,
			'RULE_SET',
			(int) $rule_set_id,
			'LEGAL_OPINION'
		);
		if ( $lock ) { $sql .= ' FOR UPDATE'; }
		$row = Stockland_DB::read_row( $sql, ARRAY_A );
		if ( ! is_array( $row )
			|| strtoupper( (string) $row['status'] ) !== strtoupper( (string) $expected_status )
			|| ( 'APPROVED' === strtoupper( (string) $expected_status ) && ( (int) ( $row['verified_by'] ?? 0 ) < 1 || empty( $row['verified_at'] ) || ! Stockland_Authority::is_owner( (int) $row['verified_by'] ) ) )
			|| ! preg_match( '/^[a-f0-9]{64}$/iD', (string) $row['document_sha256'] )
			|| ! hash_equals( strtolower( (string) $row['document_sha256'] ), $expected_hash )
		) { return false; }

		$resolved = Stockland_HR_Private_Vault::resolve( (string) $row['document_reference'], $expected_hash );
		if ( is_wp_error( $resolved ) || ! is_array( $resolved ) || empty( $resolved['path'] ) || ! is_file( $resolved['path'] ) ) { return false; }
		$mime = (string) ( $resolved['mime_type'] ?? '' );
		$allowed_mimes = array( 'application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' );
		$actual_hash = hash_file( 'sha256', $resolved['path'] );
		// The vault registers shutdown cleanup for this owner-only decrypted temp file.
		return in_array( $mime, $allowed_mimes, true )
			&& is_string( $actual_hash )
			&& hash_equals( $expected_hash, strtolower( $actual_hash ) )
			&& hash_equals( $expected_hash, strtolower( (string) ( $resolved['sha256'] ?? '' ) ) );
	}

	/** Require independent, evidence-backed professional review before any statutory rule can be used. */
	/**
	 * Accept only an evidence-backed independent professional review.
	 *
	 * Owner approval is a separate business-control step in approve_rule().
	 * A Stockland Owner declaration, WordPress Administrator identity, or a
	 * statement without a signed-opinion evidence reference is never legal review.
	 *
	 * @param array $payload Versioned statutory rule payload.
	 * @return bool Whether independent legal-review evidence is structurally complete.
	 */
	public static function has_qualified_legal_review( $payload ) {
		if ( ! is_array( $payload ) || ! isset( $payload['qualified_legal_review'] ) || ! is_array( $payload['qualified_legal_review'] ) ) {
			return false;
		}
		$q = $payload['qualified_legal_review'];
		if ( 'INDEPENDENT_PROFESSIONAL_OPINION' !== strtoupper( trim( (string) ( $q['basis'] ?? '' ) ) ) ) {
			return false;
		}

		$sha     = strtolower( (string) ( $q['opinion_sha256'] ?? '' ) );
		$clauses = $q['clauses_reviewed'] ?? array();
		$params  = $q['approved_parameters'] ?? array();

		return 'APPROVED' === strtoupper( (string) ( $q['decision'] ?? '' ) )
			&& ! empty( $q['independence_confirmed'] )
			&& strlen( trim( (string) ( $q['reviewer_name'] ?? '' ) ) ) >= 3
			&& strlen( trim( (string) ( $q['reviewer_id'] ?? '' ) ) ) >= 3
			&& strlen( trim( (string) ( $q['professional_basis'] ?? '' ) ) ) >= 8
			&& preg_match( '/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', (string) ( $q['review_date'] ?? '' ) )
			&& strlen( trim( (string) ( $q['opinion_reference'] ?? '' ) ) ) >= 6
			&& preg_match( '/^[a-f0-9]{64}$/', $sha )
			&& (int) ( $q['opinion_document_id'] ?? 0 ) > 0
			&& is_array( $clauses ) && count( $clauses ) > 0
			&& is_array( $params )
			&& in_array( 'paye_bands', $params, true )
			&& in_array( 'monthly_tax_bands', $params, true )
			&& in_array( 'tax_base_method', $params, true )
			&& in_array( 'paye_tax_base_method', $params, true )
			&& in_array( 'pensionable_base_method', $params, true )
			&& in_array( 'employee_pension_rate', $params, true )
			&& in_array( 'employer_pension_rate', $params, true )
			&& in_array( 'component_treatments', $params, true )
			&& in_array( 'rounding_method', $params, true );
	}

	/** Validate the persisted legacy and frozen-run payroll schemas before activation. */
	private static function payroll_rate_micro_contract( $value ) {
		if ( ! is_string( $value ) || 1 !== preg_match( '/^(0|1)(\.[0-9]{1,6})?$/D', $value ) ) { return null; }
		$parts = explode( '.', $value, 2 );
		$fraction = isset( $parts[1] ) ? str_pad( $parts[1], 6, '0' ) : '000000';
		$rate = ( (int) $parts[0] * 1000000 ) + (int) $fraction;
		return $rate <= 1000000 ? $rate : null;
	}

	public static function has_payroll_calculator_contract( $rules ) {
		if ( ! is_array( $rules ) ) { return false; }
		$review = $rules['qualified_legal_review'] ?? array();
		$approved = is_array( $review ) ? ( $review['approved_parameters'] ?? array() ) : array();
		if ( ! is_array( $approved ) || ! in_array( 'monthly_tax_bands', $approved, true ) || ! in_array( 'tax_base_method', $approved, true ) ) { return false; }

		$base_map = array(
			'TAXABLE_GROSS' => 'TAXABLE_EARNINGS',
			'TAXABLE_GROSS_LESS_EMPLOYEE_PENSION' => 'TAXABLE_EARNINGS_LESS_EMPLOYEE_PENSION',
		);
		$legacy_base = strtoupper( (string) ( $rules['tax_base_method'] ?? '' ) );
		$engine_base = strtoupper( (string) ( $rules['paye_tax_base_method'] ?? '' ) );
		if ( ! isset( $base_map[ $legacy_base ] ) || $base_map[ $legacy_base ] !== $engine_base ) { return false; }
		if ( 'SUM_PENSIONABLE_ITEMS' !== ( $rules['pensionable_base_method'] ?? null ) || 'HALF_UP_MINOR_UNIT' !== ( $rules['rounding_method'] ?? null ) ) { return false; }
		if ( null === self::payroll_rate_micro_contract( $rules['employee_pension_rate'] ?? null ) || null === self::payroll_rate_micro_contract( $rules['employer_pension_rate'] ?? null ) ) { return false; }

		$legacy = $rules['monthly_tax_bands'] ?? null;
		$engine = $rules['paye_bands'] ?? null;
		if ( ! is_array( $legacy ) || ! is_array( $engine ) || ! $legacy || count( $legacy ) !== count( $engine ) ) { return false; }
		$legacy = array_values( $legacy );
		$engine = array_values( $engine );
		$previous = -1;
		$unbounded = false;
		foreach ( $legacy as $i => $band ) {
			$calc_band = $engine[ $i ] ?? null;
			if ( ! is_array( $band ) || ! is_array( $calc_band ) || ! array_key_exists( 'up_to', $band ) || ! array_key_exists( 'up_to', $calc_band ) || ! isset( $band['rate'], $band['credit'], $calc_band['rate'] ) || ! is_numeric( $band['credit'] ) ) { return false; }
			try {
				$credit = Stockland_Money::minor( $band['credit'] );
				$legacy_cap = null === $band['up_to'] ? null : Stockland_Money::minor( $band['up_to'] );
				$engine_cap = null === $calc_band['up_to'] ? null : Stockland_Money::minor( $calc_band['up_to'] );
			} catch ( Throwable $e ) { return false; }
			if ( $credit < 0 || $legacy_cap !== $engine_cap ) { return false; }
			$legacy_rate = self::payroll_rate_micro_contract( (string) $band['rate'] );
			$engine_rate = self::payroll_rate_micro_contract( $calc_band['rate'] );
			if ( null === $legacy_rate || null === $engine_rate || $legacy_rate !== $engine_rate ) { return false; }
			if ( null === $legacy_cap ) {
				if ( $i !== count( $legacy ) - 1 ) { return false; }
				$unbounded = true;
			} else {
				if ( $legacy_cap < 0 || $legacy_cap <= $previous ) { return false; }
				$previous = $legacy_cap;
			}
		}
		if ( ! $unbounded ) { return false; }

		$treatments = $rules['component_treatments'] ?? null;
		if ( ! is_array( $treatments ) || ! $treatments ) { return false; }
		foreach ( $treatments as $code => $treatment ) {
			if ( ! is_string( $code ) || '' === $code || ! is_array( $treatment ) || ! isset( $treatment['kind'], $treatment['taxable'], $treatment['pensionable'] ) ) { return false; }
			if ( ! in_array( $treatment['kind'], array( 'EARNING', 'DEDUCTION', 'REIMBURSEMENT', 'EMPLOYER_COST' ), true ) || ! is_bool( $treatment['taxable'] ) || ! is_bool( $treatment['pensionable'] ) ) { return false; }
			if ( 'EARNING' !== $treatment['kind'] && ( true === $treatment['taxable'] || true === $treatment['pensionable'] ) ) { return false; }
		}
		return true;
	}

	/** The PAYE rules are not guessed: payroll is blocked unless one approved rule version covers the entire month. */
	public static function payroll_rules_for_period( $start_date, $end_date ) {
		global $wpdb;
		$table = Stockland_DB::table( 'hr_rule_sets' );
		$row = Stockland_DB::read_row( $wpdb->prepare(
			"SELECT * FROM %i WHERE rule_type='PAYROLL' AND review_status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s) ORDER BY effective_from DESC,id DESC LIMIT 1",
			$table, $start_date, $end_date
		), ARRAY_A );
		if ( ! $row || ! empty( $wpdb->last_error ) ) {
			return new WP_Error( 'payroll_rules_unapproved', 'No Owner-approved Ethiopian payroll rule version covers the entire payroll period. Add the official rule source, effective dates and test vectors, then obtain independent payroll/tax review and Owner approval.', array( 'status' => 409 ) );
		}
		$payload = json_decode( (string) $row['rules_json'], true );
		if ( ! self::has_qualified_legal_review( $payload ) ) {
			return new WP_Error( 'payroll_legal_review_missing', 'Payroll is blocked: independent qualified Ethiopian tax/pension review evidence is missing from this exact rule version.', array( 'status' => 409 ) );
		}
		if ( ! self::verify_legal_opinion_document( $payload, (int) $row['id'], 'APPROVED' ) ) {
			return new WP_Error( 'payroll_legal_opinion_unverified', 'Payroll is blocked: the exact approved, encrypted legal-opinion document is missing, unreadable, or does not match its recorded SHA-256.', array( 'status' => 409 ) );
		}
		if ( ! is_array( $payload ) || empty( $payload['monthly_tax_bands'] ) || empty( $payload['employee_pension_rate'] ) || empty( $payload['employer_pension_rate'] ) || empty( $payload['tax_base_method'] ) ) {
			return new WP_Error( 'payroll_rules_invalid', 'The approved payroll rule version is incomplete; payroll was not generated.', array( 'status' => 409 ) );
		}
		$payload['status'] = 'APPROVED';
		$payload['rule_version'] = (string) $row['version_label'];
		$payload['rule_set_id'] = (int) $row['id'];
		$payload['effective_from'] = (string) $row['effective_from'];
		$payload['effective_to'] = $row['effective_to'] ? (string) $row['effective_to'] : null;
		$payload['source_title'] = (string) $row['source_title'];
		$payload['source_clause'] = (string) $row['source_clause'];
		$payload['source_url'] = (string) $row['source_url'];
		$payload['source_sha256'] = (string) $row['source_sha256'];
		$payload['approved_by'] = (int) $row['approved_by'];
		$payload['approved_at'] = (string) $row['approved_at'];
		return $payload;
	}

	public static function allowance_rules_for_date( $date ) {
		global $wpdb;
		$sets = Stockland_DB::read_results( $wpdb->prepare(
			"SELECT * FROM %i WHERE rule_type='ALLOWANCE' AND review_status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s) ORDER BY effective_from DESC,id DESC",
			Stockland_DB::table( 'hr_rule_sets' ), $date, $date
		), ARRAY_A );
		if ( ! is_array( $sets ) || ! $sets ) { return array(); }
		$active = $sets[0];
		$payload = json_decode( (string) $active['rules_json'], true );
		if ( ! self::has_qualified_legal_review( $payload ) ) { return array(); }
		if ( ! self::verify_legal_opinion_document( $payload, (int) $active['id'], 'APPROVED' ) ) { return array(); }
		$rows = Stockland_DB::read_results( $wpdb->prepare( 'SELECT * FROM %i WHERE rule_set_id=%d ORDER BY category', Stockland_DB::table( 'hr_rule_components' ), (int) $active['id'] ), ARRAY_A );
		$rules = array();
		foreach ( (array) $rows as $row ) {
			$row['rule_set_id'] = (int) $active['id'];
			$row['rule_set_version'] = (string) $active['version_label'];
			$row['source_title'] = (string) $active['source_title'];
			$row['source_url'] = (string) $active['source_url'];
			$row['source_sha256'] = (string) $active['source_sha256'];
			$row['source_clause'] = (string) $row['source_clause'];
			$row['approved_by'] = (int) $active['approved_by'];
			$row['approved_at'] = (string) $active['approved_at'];
			$rules[(string) $row['category']] = $row;
		}
		return $rules;
	}

	/** Applies only approved, effective-dated rule components. Unknown categories default to taxable and salary-only pension treatment. */
	public static function split_allowances( $allowances, $date ) {
		$rules = self::allowance_rules_for_date( $date );
		$result = array( 'taxable_total' => '0.00', 'exempt_total' => '0.00', 'pensionable_allowance_total' => '0.00', 'components' => array(), 'rule_set_id' => null, 'rule_version' => null );
		foreach ( (array) $allowances as $item ) {
			if ( ! is_array( $item ) ) { throw new InvalidArgumentException( 'Allowance components must be a list of structured rows.' ); }
			$category = strtoupper( sanitize_key( (string) ( $item['category'] ?? 'OTHER' ) ) );
			$label = sanitize_text_field( (string) ( $item['label'] ?? $category ) );
			$amount = Stockland_Money::decimal( Stockland_Money::minor( $item['amount'] ?? '0.00' ) );
			if ( Stockland_Money::minor( $amount ) < 0 ) { throw new InvalidArgumentException( 'Allowance amounts cannot be negative.' ); }
			$rule = $rules[$category] ?? null;
			$treatment = $rule ? strtoupper( (string) $rule['tax_treatment'] ) : 'TAXABLE';
			$exempt = '0.00';
			if ( $rule && 'EXEMPT_FULL' === $treatment ) {
				$exempt = $amount;
			} elseif ( $rule && 'EXEMPT_CAP' === $treatment ) {
				if ( null === $rule['exemption_cap'] || '' === $rule['exemption_cap'] ) {
					throw new RuntimeException( 'Approved allowance rule ' . $category . ' is missing its exemption cap; payroll blocked.' );
				}
				$exempt = Stockland_Money::decimal( min( Stockland_Money::minor( $amount ), Stockland_Money::minor( $rule['exemption_cap'] ) ) );
			} elseif ( 'TAXABLE' !== $treatment ) {
				throw new RuntimeException( 'Allowance rule for ' . $category . ' is unsupported; payroll blocked.' );
			}
			$taxable = Stockland_Money::subtract( $amount, $exempt );
			$pensionable = 'PENSIONABLE' === strtoupper( (string) ( $rule['pensionable_treatment'] ?? 'SALARY_ONLY' ) ) ? $amount : '0.00';
			$base_component = array(
				'category' => $category,
				'label' => $label,
				'original_amount' => $amount,
				'system_rule_classified' => (bool) $rule,
				'rule_set_id' => $rule ? (int) $rule['rule_set_id'] : null,
				'rule_set_version' => $rule ? (string) $rule['rule_set_version'] : null,
				'rule_approved_by' => $rule ? (int) $rule['approved_by'] : null,
				'rule_approved_at' => $rule ? (string) $rule['approved_at'] : null,
				'legal_basis' => $rule ? (string) $rule['source_title'] . ' — ' . (string) $rule['source_clause'] : '',
				'evidence_reference' => $rule ? (string) $rule['source_url'] : '',
				'source_hash' => $rule ? (string) $rule['source_sha256'] : '',
				'owner_verified' => false,
			);
			// Store taxable and exempt allocations as separate ledger-like rows. This
			// keeps every historical validator/snapshot reconciliation exact to cents.
			if ( Stockland_Money::minor( $taxable ) > 0 ) {
				$result['components'][] = array_merge( $base_component, array(
					'amount' => $taxable, 'tax_treatment' => 'TAXABLE',
					'taxable_amount' => $taxable, 'exempt_amount' => '0.00',
					'pensionable_amount' => 'PENSIONABLE' === strtoupper( (string) ( $rule['pensionable_treatment'] ?? 'SALARY_ONLY' ) ) ? $taxable : '0.00',
				) );
			}
			if ( Stockland_Money::minor( $exempt ) > 0 ) {
				$result['components'][] = array_merge( $base_component, array(
					'amount' => $exempt, 'tax_treatment' => 'EXEMPT',
					'taxable_amount' => '0.00', 'exempt_amount' => $exempt,
					'pensionable_amount' => 'PENSIONABLE' === strtoupper( (string) ( $rule['pensionable_treatment'] ?? 'SALARY_ONLY' ) ) ? $exempt : '0.00',
				) );
			}
			$result['taxable_total'] = Stockland_Money::add( $result['taxable_total'], $taxable );
			$result['exempt_total'] = Stockland_Money::add( $result['exempt_total'], $exempt );
			$result['pensionable_allowance_total'] = Stockland_Money::add( $result['pensionable_allowance_total'], $pensionable );
			if ( $rule ) {
				$result['rule_set_id'] = (int) $rule['rule_set_id'];
				$result['rule_version'] = (string) $rule['rule_set_version'];
			}
		}
		return $result;
	}
}
