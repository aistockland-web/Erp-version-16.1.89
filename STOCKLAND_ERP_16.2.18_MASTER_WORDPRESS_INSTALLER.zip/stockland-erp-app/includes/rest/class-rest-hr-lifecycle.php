<?php
/**
 * Full employee-lifecycle, statutory-rule and final-settlement REST handlers.
 * @package Stockland_ERP
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_REST_HR_Lifecycle extends Stockland_REST_Base {
	private $entities = array(
		'workforce-plans'=>array('table'=>'hr_workforce_plans','fields'=>array('plan_code','fiscal_year','version_no','location_id','department','planned_headcount','annual_salary_budget','other_cost_budget','justification')),
		'positions'=>array('table'=>'hr_positions','fields'=>array('position_code','title','department','grade_code','location_id','headcount_slots','annual_salary_min','annual_salary_max','workforce_plan_id')),
		'requisitions'=>array('table'=>'hr_requisitions','fields'=>array('requisition_code','position_id','workforce_plan_id','location_id','openings','employment_type','target_start_date','justification')),
		'candidates'=>array('table'=>'hr_candidates','fields'=>array('candidate_code','full_name','email','phone','source','consent_at','notes')),
		'applications'=>array('table'=>'hr_applications','fields'=>array('requisition_id','candidate_id','stage','screening_score','decision_reason')),
		'interviews'=>array('table'=>'hr_interviews','fields'=>array('application_id','interview_round','scheduled_at','panel_json','scorecard_json','total_score','recommendation','notes')),
		'documents'=>array('table'=>'hr_documents','fields'=>array('subject_type','subject_id','document_type','document_reference','document_sha256','issued_on','expires_on','notes')),
		'contracts'=>array('table'=>'hr_contracts','fields'=>array('employee_id','contract_code','contract_type','start_date','end_date','probation_end','position_id','location_id','terms_json','document_id')),
		'onboarding'=>array('table'=>'hr_onboarding_tasks','fields'=>array('employee_id','task_code','task_title','responsible_role','due_date','evidence_reference')),
		'shifts'=>array('table'=>'hr_shifts','fields'=>array('shift_code','shift_name','location_id','start_time','end_time','break_minutes','effective_from','effective_to','rule_set_id')),
		'attendance'=>array('table'=>'hr_attendance','fields'=>array('employee_id','location_id','shift_id','work_date','check_in','check_out','ordinary_minutes','overtime_minutes','absence_type','source','correction_reason')),
		'leave-policies'=>array('table'=>'hr_leave_policies','fields'=>array('policy_code','leave_type','annual_entitlement_days','max_carry_days','min_notice_days','paid_status','rule_set_id','effective_from','effective_to')),
		'leave-balances'=>array('table'=>'hr_leave_balances','fields'=>array('employee_id','leave_type','leave_year','opening_days','accrued_days','used_days','adjusted_days','closing_days')),
		'leave-requests'=>array('table'=>'hr_leave_requests','fields'=>array('employee_id','leave_type','start_date','end_date','requested_days','reason','evidence_reference')),
		'training'=>array('table'=>'hr_training_records','fields'=>array('employee_id','training_code','title','provider','start_date','end_date','status','evidence_reference')),
		'performance'=>array('table'=>'hr_performance_reviews','fields'=>array('employee_id','review_period','reviewer_id','goals_json','rating','outcome','notes')),
		'adjustments'=>array('table'=>'hr_payroll_adjustments','fields'=>array('employee_id','source_period_id','target_period_key','adjustment_type','amount','taxable_amount','pensionable_amount','reason')),
	);
	public function __construct(){add_action('stockland_register_rest_routes',array($this,'register_routes'));}
	public function register_routes(){
		if ( ! Stockland_HR::is_schema_ready() ) { return; }
		$ns=self::NAMESPACE_V1;
		register_rest_route($ns,'/hr/lifecycle/bootstrap',array('methods'=>'GET','callback'=>array($this,'bootstrap'),'permission_callback'=>function(){return Stockland_Authority::can_view_hr();}));
		register_rest_route($ns,'/hr/lifecycle/(?P<entity>workforce-plans|positions|requisitions|candidates|applications|interviews|documents|contracts|onboarding|shifts|attendance|leave-policies|leave-balances|leave-requests|training|performance|adjustments)',array('methods'=>'POST','callback'=>array($this,'create'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/(?P<entity>workforce-plans|positions|requisitions|candidates|applications|interviews|documents|contracts|onboarding|shifts|attendance|leave-policies|leave-balances|leave-requests|training|performance|adjustments)/(?P<id>\d+)/decision',array('methods'=>'POST','callback'=>array($this,'decision'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/applications/(?P<id>\d+)/select',array('methods'=>'POST','callback'=>array($this,'select_candidate'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/contracts/(?P<id>\d+)/sign',array('methods'=>'POST','callback'=>array($this,'sign_contract'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/employees/(?P<id>\d+)/activate',array('methods'=>'POST','callback'=>array($this,'activate_hire'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/exits/(?P<id>\d+)/approve',array('methods'=>'POST','callback'=>array($this,'approve_exit'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/rules',array('methods'=>'POST','callback'=>array($this,'create_rule'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/rules/(?P<id>\\d+)/legal-opinion',array('methods'=>'POST','callback'=>array($this,'upload_rule_legal_opinion'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/rules/(?P<id>\d+)/approve',array('methods'=>'POST','callback'=>array($this,'approve_rule'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/allowance-preview',array('methods'=>'POST','callback'=>array($this,'allowance_preview'),'permission_callback'=>function(){return Stockland_Authority::can_view_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/compensation',array('methods'=>'POST','callback'=>array($this,'save_compensation'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/compensation/(?P<id>\d+)/approve',array('methods'=>'POST','callback'=>array($this,'approve_compensation'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
		register_rest_route($ns,'/hr/lifecycle/exits/calculate',array('methods'=>'POST','callback'=>array($this,'calculate_exit'),'permission_callback'=>function(){return Stockland_Authority::can_manage_hr();}));
		register_rest_route($ns,'/hr/lifecycle/exits/(?P<id>\d+)/pay',array('methods'=>'POST','callback'=>array($this,'pay_exit'),'permission_callback'=>function(){return Stockland_Authority::can_approve_payroll();}));
	}
	private function bad($message,$code='hr_lifecycle_invalid',$status=400){return new WP_Error($code,$message,array('status'=>$status));}
	private function table($key){return Stockland_DB::table($key);}
	private function owner(){return Stockland_Authority::can_approve_payroll();}
	private function date($v,$optional=true){if(($v===null||$v==='')&&$optional)return null;$v=sanitize_text_field((string)$v);if(!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/',$v,$m)||!checkdate((int)$m[2],(int)$m[3],(int)$m[1]))return false;return $v;}
	private function json_value($v,$name){$s=is_string($v)?$v:wp_json_encode($v);if(!is_string($s)||json_last_error()!==JSON_ERROR_NONE&&is_string($v))return $this->bad($name.' must be valid JSON.');json_decode($s,true);if(json_last_error()!==JSON_ERROR_NONE)return $this->bad($name.' must be valid JSON.');return $s;}
	private function sanitize_fields($payload,$fields){
		$out=array();$dates=array('target_start_date','issued_on','expires_on','start_date','end_date','probation_end','effective_from','effective_to','work_date','due_date','last_work_date','exit_date','scheduled_at','check_in','check_out','consent_at');
		$money=array('annual_salary_budget','other_cost_budget','annual_salary_min','annual_salary_max','annual_entitlement_days','max_carry_days','requested_days','opening_days','accrued_days','used_days','adjusted_days','closing_days','amount','taxable_amount','pensionable_amount','gross_total','taxable_total','exempt_total','tax_total','employee_pension_total','employer_pension_total','other_deductions_total','net_total','screening_score','total_score','rating');
		$ints=array('version_no','location_id','planned_headcount','headcount_slots','workforce_plan_id','position_id','openings','requisition_id','candidate_id','application_id','subject_id','employee_id','document_id','break_minutes','shift_id','ordinary_minutes','overtime_minutes','min_notice_days','leave_year','reviewer_id','source_period_id','rule_set_id');
		$json=array('terms_json','panel_json','scorecard_json','goals_json','components_json');
		foreach($fields as $f){if(!array_key_exists($f,$payload))continue;$v=$payload[$f];
			if(in_array($f,array('scheduled_at','check_in','check_out','consent_at'),true)){ $raw=sanitize_text_field((string)$v); if($raw==='')$v=null; else { $dt=DateTimeImmutable::createFromFormat('!Y-m-d\\TH:i',$raw); if(!$dt)return $this->bad('Invalid date/time value for '.$f.'.'); $v=$dt->format('Y-m-d H:i:s'); } } elseif(in_array($f,$dates,true)){$v=$this->date($v,true);if($v===false)return $this->bad('Invalid date/time value for '.$f.'.');}
			elseif(in_array($f,$json,true)){$v=$this->json_value($v,$f);if(is_wp_error($v))return $v;}
			elseif(in_array($f,$money,true)){try{$v=Stockland_Money::decimal(Stockland_Money::minor($v));if(Stockland_Money::minor($v)<0)return $this->bad($f.' cannot be negative.');}catch(Throwable $e){return $this->bad('Invalid numeric value for '.$f.'.');}}
			elseif(in_array($f,$ints,true)){if($v===null||$v==='')$v=null;else{$v=filter_var($v,FILTER_VALIDATE_INT);if($v===false||$v<0)return $this->bad('Invalid integer value for '.$f.'.');}}
			elseif($f==='email'){$v=sanitize_email($v);if(($payload[$f]??'')!==''&&!is_email($v))return $this->bad('Invalid email address.');}
			elseif(in_array($f,array('notes','reason','justification','decision_reason','correction_reason','source_note','decision_note'),true))$v=sanitize_textarea_field((string)$v);
			else $v=sanitize_text_field((string)$v);
			$out[$f]=$v;
		}return $out;
	}
	private function event($entity,$id,$event,$from,$to,$meta=array(),$rule_id=null,$version=null){return (bool)Stockland_HR_Lifecycle::write_event($entity,(int)$id,$event,$from,$to,$meta,$rule_id,$version);}
	private function list_table($key,$limit=300){global $wpdb;$table=$this->table($key);$rows=Stockland_DB::read_results($wpdb->prepare('SELECT * FROM %i ORDER BY id DESC LIMIT %d',$table,$limit),ARRAY_A);return is_array($rows)?$rows:array();}
	public function bootstrap(WP_REST_Request $req){
		global $wpdb;$pay=Stockland_Authority::can_view_payroll();
		$out=array('locations'=>array(),'employees'=>array(),'compensation'=>array(),'payroll'=>array(),'payroll_visible'=>$pay,'capabilities'=>array('hr_manage'=>Stockland_Authority::can_manage_hr(),'payroll_manage'=>Stockland_Authority::can_manage_payroll(),'payroll_approve'=>Stockland_Authority::can_approve_payroll()),'rule_sets'=>$this->list_table('hr_rule_sets'),'rule_components'=>$this->list_table('hr_rule_components'),'lists'=>array());
		$out['rule_sets']=Stockland_DB::read_results($wpdb->prepare(
			'SELECT r.*,d.id AS legal_opinion_document_id,d.status AS legal_opinion_status,d.document_sha256 AS legal_opinion_sha256
			 FROM %i r
			 LEFT JOIN %i d ON d.id=(
				SELECT MAX(dx.id) FROM %i dx
				WHERE dx.subject_type=%s AND dx.subject_id=r.id AND dx.document_type=%s
			 )
			 ORDER BY r.effective_from DESC,r.id DESC LIMIT 200',
			$this->table('hr_rule_sets'),
			$this->table('hr_documents'),
			$this->table('hr_documents'),
			'RULE_SET',
			'LEGAL_OPINION'
		),ARRAY_A);
		$out['locations']=$this->list_table('locations',200);
		$out['employees']=$this->list_table('employees',500);
		$out['payroll']=$pay?$this->list_table('payroll_periods',120):array();
		if($pay){
			$out['compensation']=Stockland_DB::read_results($wpdb->prepare("SELECT c.id,c.employee_id,c.effective_from,c.base_salary,c.allowance_total,c.taxable_allowance_total,c.exempt_allowance_total,c.pensionable_salary,c.statutory_classification_status,c.statutory_classification_note,c.allowance_rule_version,c.approval_status AS stored_approval_status,CASE WHEN c.approval_status='APPROVED' AND c.created_by>0 AND c.approved_by>0 AND c.approved_by<>c.created_by AND c.approved_at IS NOT NULL AND c.approved_at<>'0000-00-00 00:00:00' THEN 'APPROVED' WHEN c.approval_status='APPROVED' THEN 'REVIEW_REQUIRED' ELSE c.approval_status END AS approval_status,c.approved_by,c.approved_at,c.created_by,e.employee_id employee_code,e.full_name,e.branch_location_id FROM %i c INNER JOIN %i e ON e.id=c.employee_id ORDER BY c.effective_from DESC,c.id DESC LIMIT 500",$this->table('employee_compensation'),$this->table('employees')),ARRAY_A);
		}
		foreach($this->entities as $slug=>$cfg){$out['lists'][$slug]=$this->list_table($cfg['table']);}
		$out['lists']['exits']=$this->list_table('hr_exit_settlements');
		if(!$pay){$out['compensation']=array();$out['payroll']=array();$out['rule_sets']=array();$out['rule_components']=array();$out['lists']['adjustments']=array();}
		return rest_ensure_response($out);
	}
	public function create(WP_REST_Request $req){
		$entity=(string)$req['entity'];if(!isset($this->entities[$entity]))return $this->bad('Unknown lifecycle entity.');if($entity==='exits')return $this->bad('Create final settlements using the rule-backed calculation endpoint.','settlement_calculation_required',409);
		$cfg=$this->entities[$entity];$p=$req->get_json_params();$row=$this->sanitize_fields(is_array($p)?$p:array(),$cfg['fields']);if(is_wp_error($row))return $row;
		if(isset($row['location_id'])&&!empty($row['location_id'])&&!Stockland_Authority::can_access_location($row['location_id']))return $this->bad('Record location is outside the current authorization scope.','hr_location_forbidden',403);
		if(in_array($entity,array('documents','contracts'),true)&&empty($row['document_reference'])&&$entity==='documents')return $this->bad('Store a private vault reference; public file URLs are prohibited.');
		if($entity==='documents'&&!empty($row['document_reference'])&&preg_match('~^https?://~i',$row['document_reference']))return $this->bad('Public/external document URLs are prohibited. Use the approved private document-vault reference.');
		$required=array('workforce-plans'=>array('plan_code','fiscal_year','department','justification'),'positions'=>array('position_code','title','department'),'requisitions'=>array('requisition_code','position_id','justification'),'candidates'=>array('candidate_code','full_name'),'applications'=>array('requisition_id','candidate_id'),'interviews'=>array('application_id','interview_round'),'documents'=>array('subject_type','subject_id','document_type','document_reference'),'contracts'=>array('employee_id','contract_code','contract_type','start_date'),'onboarding'=>array('employee_id','task_code','task_title'),'shifts'=>array('shift_code','shift_name','start_time','end_time','effective_from'),'attendance'=>array('employee_id','work_date'),'leave-policies'=>array('policy_code','leave_type','effective_from'),'leave-balances'=>array('employee_id','leave_type','leave_year'),'leave-requests'=>array('employee_id','leave_type','start_date','end_date','requested_days'),'training'=>array('employee_id','training_code','title'),'performance'=>array('employee_id','review_period','reviewer_id'),'adjustments'=>array('employee_id','target_period_key','adjustment_type','amount','reason'));
		foreach($required[$entity]??array() as $f){if(!isset($row[$f])||$row[$f]==='')return $this->bad('Required field missing: '.$f.'.');}
		if($entity==='leave-requests'&&$row['end_date']<$row['start_date'])return $this->bad('Leave end date cannot be before start date.');
		if($entity==='attendance'&&isset($row['check_in'],$row['check_out'])&&$row['check_in']&&$row['check_out']&&$row['check_out']<$row['check_in'])return $this->bad('Attendance check-out must follow check-in.');
		if($entity==='candidates'&&empty($row['consent_at']))$row['consent_at']=current_time('mysql');
		$status_field=array('workforce-plans'=>'status','positions'=>'status','requisitions'=>'status','candidates'=>'status','applications'=>'stage','interviews'=>'recommendation','documents'=>'status','contracts'=>'status','onboarding'=>'status','shifts'=>'status','attendance'=>'status','leave-policies'=>'status','leave-balances'=>'closing_days','leave-requests'=>'status','training'=>'status','performance'=>'outcome','adjustments'=>'status');
		$sf=$status_field[$entity]??null;if($sf&&!array_key_exists($sf,$row))$row[$sf]=in_array($entity,array('applications'),true)?'APPLIED':'DRAFT';
		$row['created_by']=get_current_user_id();if($entity==='attendance'){$row['submitted_by']=get_current_user_id();$row['status']='SUBMITTED';}
		if(in_array($entity,array('workforce-plans','positions','requisitions','contracts','leave-policies','shifts','adjustments'),true))$row['status']='DRAFT';
		if($entity==='leave-requests')$row['status']='SUBMITTED';
		$payload_for_audit=$row;foreach(array('full_name','email','phone','terms_json','panel_json','scorecard_json','goals_json','notes') as $sensitive){if(isset($payload_for_audit[$sensitive]))$payload_for_audit[$sensitive]='[REDACTED]';}
		if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start HR record transaction.','hr_transaction_failed',500);
		if(Stockland_DB::insert_record($this->table($cfg['table']),$row)===false){Stockland_DB::execute_query('ROLLBACK');return $this->bad('Record could not be saved. Check fields and schema readiness.','hr_lifecycle_insert_failed',409);}
		global $wpdb;$id=(int)$wpdb->insert_id;
		if(!$this->event($entity,$id,'CREATED',null,$row[$sf]??'DRAFT',array('fields'=>array_keys($row),'snapshot_sha256'=>hash('sha256',wp_json_encode($payload_for_audit))))){Stockland_DB::execute_query('ROLLBACK');return $this->bad('Audit event failed; record creation was rolled back.','hr_audit_event_failed',500);}
		if(Stockland_DB::execute_query('COMMIT')===false){Stockland_DB::execute_query('ROLLBACK');return $this->bad('HR record transaction could not commit.','hr_transaction_failed',500);}
		return rest_ensure_response(array('id'=>$id,'entity'=>$entity,'status'=>$row[$sf]??'DRAFT','message'=>'Saved. Workflow approvals remain separate.'));
	}
	public function decision(WP_REST_Request $req){
		$entity=(string)$req['entity'];$id=(int)$req['id'];$p=$req->get_json_params();$decision=strtoupper(sanitize_key((string)($p['decision']??'')));$note=sanitize_textarea_field((string)($p['note']??''));if(!isset($this->entities[$entity])&&$entity!=='exits')return $this->bad('Unknown lifecycle entity.');
		if(!in_array($decision,array('SUBMIT','APPROVE','REJECT','COMPLETE','CONFIRM'),true))return $this->bad('Unsupported state transition.');
		if($decision==='APPROVE'&&!$this->owner()&&in_array($entity,array('workforce-plans','positions','requisitions','applications','contracts','leave-policies','adjustments'),true))return $this->bad('Owner approval is required for this financial/employment commitment.','forbidden',403);
		if($entity==='exits'&&in_array($decision,array('APPROVE','PAY'),true))return $this->bad('Final settlement approval/payment uses the dedicated rule-backed settlement handler.','settlement_handler_required',409);
		$cfg=$this->entities[$entity];$table=$this->table($cfg['table']);$statusCol='performance'===$entity?'outcome':('applications'===$entity?'decision':('interviews'===$entity?'recommendation':'status'));
		global $wpdb;if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start workflow transaction.','hr_transaction_failed',500);
		try{
			$row=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$table,$id),ARRAY_A);if(!$row)throw new RuntimeException('Record does not exist.');
			if($entity==='documents'&&strtoupper((string)($row['subject_type']??''))==='RULE_SET'&&strtoupper((string)($row['document_type']??''))==='LEGAL_OPINION')throw new RuntimeException('Rule legal opinions can only be ratified by the dedicated Owner rule-approval transaction; general document decisions are disabled for these evidence records.');
			$from=(string)($row[$statusCol]??'DRAFT');
			$map=array('SUBMIT'=>array('DRAFT'=>'SUBMITTED','CALCULATED'=>'SUBMITTED','PENDING'=>'SUBMITTED'),'APPROVE'=>array('SUBMITTED'=>'APPROVED','PENDING_REVIEW'=>'APPROVED','CALCULATED'=>'APPROVED','RECOMMENDED'=>'APPROVED'),'REJECT'=>array('SUBMITTED'=>'REJECTED','DRAFT'=>'REJECTED','PENDING_REVIEW'=>'REJECTED','RECOMMENDED'=>'REJECTED'),'COMPLETE'=>array('OPEN'=>'COMPLETE','PLANNED'=>'COMPLETE','IN_PROGRESS'=>'COMPLETE'),'CONFIRM'=>array('OFFERED'=>'CONFIRMED','PROBATION'=>'CONFIRMED'));
			$to=$map[$decision][$from]??null;if(!$to)throw new RuntimeException('Invalid transition '.$from.' → '.$decision.'.');
			if(in_array($decision,array('APPROVE','PAY','CONFIRM'),true)&&$note==='')$note='Approved by authorized reviewer.';
			$data=array($statusCol=>$to);
			if(in_array($decision,array('APPROVE','REJECT','CONFIRM'),true)&&isset($row['created_by'])&&(int)$row['created_by']===(int)get_current_user_id())throw new RuntimeException('Maker-checker: the record creator cannot approve or reject their own record.');
			if(in_array($decision,array('APPROVE','REJECT'),true)){
				if(array_key_exists('approved_by',$row)){$data['approved_by']=get_current_user_id();$data['approved_at']=current_time('mysql');}
				if(isset($row['decision_note']))$data['decision_note']=$note;
				if($entity==='documents'){$data['verified_by']=get_current_user_id();$data['verified_at']=current_time('mysql');}
				if($entity==='applications'){$data['decided_by']=get_current_user_id();$data['decided_at']=current_time('mysql');$data['decision_reason']=$note;}
				if($entity==='interviews'){$data['completed_by']=get_current_user_id();$data['completed_at']=current_time('mysql');$data['notes']=$note;}
			}
			if($entity==='attendance'&&$decision==='APPROVE'){$data['approved_by']=get_current_user_id();$data['approved_at']=current_time('mysql');}
			if($entity==='leave-requests'&&in_array($decision,array('APPROVE','REJECT'),true)){$data['decided_by']=get_current_user_id();$data['decided_at']=current_time('mysql');$data['decision_note']=$note;}
			if(Stockland_DB::update_record($table,$data,array('id'=>$id))===false)throw new RuntimeException('Could not persist workflow decision.');
			if(!$this->event($entity,$id,$decision,$from,$to,array('note'=>$note,'actor_role'=>Stockland_Authority::role())))throw new RuntimeException('Audit event failed; transition rolled back.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Workflow commit failed.');
			return rest_ensure_response(array('id'=>$id,'status'=>$to));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hr_workflow_transition_failed',409);}
	}
	public function select_candidate(WP_REST_Request $req){
		$id=(int)$req['id'];$payload=$req->get_json_params();$note=sanitize_textarea_field((string)($payload['selection_rationale']??''));if(strlen(trim($note))<20)return $this->bad('Document the human selection rationale (at least 20 characters).');
		global $wpdb;if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start selection transaction.','hr_transaction_failed',500);
		try{
			$app=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_applications'),$id),ARRAY_A);
			if(!$app||!in_array($app['decision'],array('PENDING','RECOMMENDED'),true))throw new RuntimeException('Application is not in a selectable state.');
			$reqRow=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_requisitions'),(int)$app['requisition_id']),ARRAY_A);
			if(!$reqRow||$reqRow['status']!=='APPROVED')throw new RuntimeException('A selected candidate needs an approved requisition.');
			$candidate=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_candidates'),(int)$app['candidate_id']),ARRAY_A);
			$position=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d',$this->table('hr_positions'),(int)$reqRow['position_id']),ARRAY_A);
			if(!$candidate||!$position)throw new RuntimeException('Candidate or approved position is missing.');
			$interviews=Stockland_DB::read_results($wpdb->prepare('SELECT * FROM %i WHERE application_id=%d ORDER BY id',$this->table('hr_interviews'),$id),ARRAY_A);
			$recommended=false;foreach((array)$interviews as $it){if(in_array(strtoupper((string)$it['recommendation']),array('RECOMMEND','APPROVED'),true))$recommended=true;}
			if(!$recommended)throw new RuntimeException('At least one completed interview panel recommendation is required before selection.');
			$loc=(int)($reqRow['location_id']??0);if($loc>0&&!Stockland_Authority::can_access_location($loc))throw new RuntimeException('Vacancy is outside your allowed branch scope.');
			$year=current_time('Y');$employeeCode='SL'.$year.'-'.str_pad((string)$id,6,'0',STR_PAD_LEFT);
			$existing=Stockland_DB::read_row($wpdb->prepare('SELECT id FROM %i WHERE employee_id=%s',$this->table('employees'),$employeeCode),ARRAY_A);if($existing)throw new RuntimeException('This application already produced an employee record.');
			$hireDate=$reqRow['target_start_date']?:current_time('Y-m-d');
			$employee=array('employee_id'=>$employeeCode,'full_name'=>sanitize_text_field((string)$candidate['full_name']),'branch_location_id'=>$loc?:null,'position_title'=>sanitize_text_field((string)$position['title']),'employment_type'=>sanitize_key((string)$reqRow['employment_type']?:'FULL_TIME'),'hire_date'=>$hireDate,'termination_date'=>null,'status'=>'PENDING','phone'=>sanitize_text_field((string)$candidate['phone']),'email'=>sanitize_email((string)$candidate['email']),'notes'=>'Selected application '.$id.'; '.$note,'created_by'=>get_current_user_id(),'updated_by'=>get_current_user_id());
			if(Stockland_DB::insert_record($this->table('employees'),$employee)===false)throw new RuntimeException('Could not create pending employee record.');
			$employeeId=(int)$wpdb->insert_id;
			$contractCode='CON-'.$employeeCode;
			if(Stockland_DB::insert_record($this->table('hr_contracts'),array('employee_id'=>$employeeId,'contract_code'=>$contractCode,'contract_type'=>sanitize_key((string)$reqRow['employment_type']?:'FULL_TIME'),'start_date'=>$hireDate,'end_date'=>null,'probation_end'=>null,'position_id'=>(int)$position['id'],'location_id'=>$loc?:null,'terms_json'=>wp_json_encode(array('status'=>'DRAFT','selection_rationale'=>$note,'application_id'=>$id)),'document_id'=>null,'status'=>'DRAFT','created_by'=>get_current_user_id()))===false)throw new RuntimeException('Could not create contract draft.');
			$contractId=(int)$wpdb->insert_id;
			$tasks=array(array('CONTRACT_SIGN','Sign employment contract','OWNER'),array('PERSONNEL_DOCS','Verify required personnel documents','MANAGEMENT'),array('PAYROLL_SETUP','Set up approved compensation and statutory profile','OWNER'),array('INDUCTION','Complete orientation and induction','MANAGEMENT'));
			foreach($tasks as $task){if(Stockland_DB::insert_record($this->table('hr_onboarding_tasks'),array('employee_id'=>$employeeId,'task_code'=>$task[0],'task_title'=>$task[1],'responsible_role'=>$task[2],'due_date'=>$hireDate,'status'=>'OPEN','evidence_reference'=>null,'created_by'=>get_current_user_id()))===false)throw new RuntimeException('Could not seed required onboarding checklist.');}
			if(Stockland_DB::update_record($this->table('hr_applications'),array('decision'=>'SELECTED','stage'=>'OFFER','selected_employee_id'=>$employeeId,'decision_reason'=>$note,'decided_by'=>get_current_user_id(),'decided_at'=>current_time('mysql')),array('id'=>$id))===false)throw new RuntimeException('Could not save selection decision.');
			if(!$this->event('application',$id,'CANDIDATE_SELECTED','RECOMMENDED','SELECTED',array('employee_id'=>$employeeId,'contract_id'=>$contractId,'rationale'=>$note)))throw new RuntimeException('Selection audit event failed.');
			if(!$this->event('employee',$employeeId,'HIRE_DRAFT_CREATED',null,'PENDING',array('application_id'=>$id,'contract_id'=>$contractId)))throw new RuntimeException('Pending hire audit event failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Selection commit failed.');
			return rest_ensure_response(array('application_id'=>$id,'employee_id'=>$employeeId,'employee_code'=>$employeeCode,'status'=>'PENDING','contract_id'=>$contractId,'message'=>'Selected candidate created as pending hire. Signed contract, verified documents and completed onboarding/compensation prerequisites are required before activation.'));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'candidate_selection_failed',409);}
	}


	public function sign_contract(WP_REST_Request $req){
		$id=(int)$req['id'];$p=$req->get_json_params();$signed=$this->date($p['signed_at']??null,false);$doc=(int)($p['document_id']??0);
		if($signed===false||$doc<1)return $this->bad('Signed date and verified document ID are required.');
		global $wpdb;if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start contract-signing transaction.','hr_transaction_failed',500);
		try{
			$c=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_contracts'),$id),ARRAY_A);
			if(!$c||$c['status']!=='DRAFT')throw new RuntimeException('Only a draft employment contract can be signed.');
			$d=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE id=%d AND subject_type='CONTRACT' AND subject_id=%d AND status='APPROVED'",$this->table('hr_documents'),$doc,$id),ARRAY_A);
			if(!$d||strtoupper((string)$d['document_type'])!=='EMPLOYMENT_CONTRACT'||empty($d['document_reference'])||preg_match('~^https?://~i',(string)$d['document_reference']))throw new RuntimeException('A verified private-vault EMPLOYMENT_CONTRACT document is required.');
			if(Stockland_DB::update_record($this->table('hr_contracts'),array('signed_at'=>$signed.' 00:00:00','document_id'=>$doc,'status'=>'SUBMITTED'),array('id'=>$id))===false)throw new RuntimeException('Could not record signed contract.');
			if(!$this->event('contract',$id,'CONTRACT_SIGNED','DRAFT','SUBMITTED',array('signed_at'=>$signed,'document_id'=>$doc,'document_sha256'=>$d['document_sha256']??null)))throw new RuntimeException('Contract audit event failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Contract signing commit failed.');
			return rest_ensure_response(array('id'=>$id,'status'=>'SUBMITTED','signed_at'=>$signed,'document_id'=>$doc,'message'=>'Signature registered. Owner approval remains a separate stage.'));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hr_contract_sign_failed',409);}
	}
	public function activate_hire(WP_REST_Request $req){
		$id=(int)$req['id'];$p=$req->get_json_params();$note=sanitize_textarea_field((string)($p['approval_note']??''));if(strlen(trim($note))<10)return $this->bad('Record the Owner hire approval rationale.');
		global $wpdb;if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start hire activation transaction.','hr_transaction_failed',500);
		try{
			$e=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('employees'),$id),ARRAY_A);
			if(!$e||strtoupper((string)$e['status'])!=='PENDING')throw new RuntimeException('Only a pending employee can be activated.');
			if((int)$e['created_by']===(int)get_current_user_id())throw new RuntimeException('Maker-checker: the employee-file creator cannot approve the hire.');
			$c=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE employee_id=%d AND status='APPROVED' AND signed_at IS NOT NULL ORDER BY start_date DESC,id DESC LIMIT 1",$this->table('hr_contracts'),$id),ARRAY_A);
			if(!$c||empty($c['document_id']))throw new RuntimeException('A signed and Owner-approved employment contract is required before activation.');
			$d=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE id=%d AND status='APPROVED' AND subject_type='CONTRACT' AND subject_id=%d",$this->table('hr_documents'),(int)$c['document_id'],$c['id']),ARRAY_A);
			if(!$d||strtoupper((string)$d['document_type'])!=='EMPLOYMENT_CONTRACT')throw new RuntimeException('The approved private employment-contract document is missing.');
			$required=Stockland_DB::read_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE employee_id=%d AND task_code IN ('CONTRACT_SIGN','PERSONNEL_DOCS','PAYROLL_SETUP','INDUCTION') AND status<>'COMPLETE'",$this->table('hr_onboarding_tasks'),$id));
			if((int)$required>0)throw new RuntimeException('Complete the contract, personnel-document, payroll-setup and induction checklist before activation.');
			$comp=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE employee_id=%d AND approval_status='APPROVED' AND created_by>0 AND approved_by>0 AND approved_by<>created_by AND approved_at IS NOT NULL AND approved_at<>'0000-00-00 00:00:00' AND effective_from<=%s ORDER BY effective_from DESC,id DESC LIMIT 1",$this->table('employee_compensation'),$id,$e['hire_date']?:current_time('Y-m-d')),ARRAY_A);
			if(!$comp)throw new RuntimeException('An authorized, effective-dated and approved compensation record is required before activation.');
			if(Stockland_DB::update_record($this->table('employees'),array('status'=>'ACTIVE','updated_by'=>get_current_user_id()),array('id'=>$id,'status'=>'PENDING'))===false)throw new RuntimeException('Could not activate employee.');
			if(!$this->event('employee',$id,'HIRE_ACTIVATED','PENDING','ACTIVE',array('approval_note'=>$note,'contract_id'=>$c['id'],'compensation_id'=>$comp['id'],'document_id'=>$d['id'])))throw new RuntimeException('Hire-activation audit event failed.');
			if(!Stockland_Audit::log(get_current_user_id(),$e['branch_location_id'],'HR_EMPLOYEE_ACTIVATE',null,null,'PENDING','ACTIVE',$note,'EMP'.$id))throw new RuntimeException('Hire-activation immutable audit failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Hire activation commit failed.');
			return rest_ensure_response(array('id'=>$id,'status'=>'ACTIVE','message'=>'Hire activated after signed contract, verified document, complete onboarding and approved compensation checks.'));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hire_activation_failed',409);}
	}
	public function approve_exit(WP_REST_Request $req){
		$id=(int)$req['id'];$p=$req->get_json_params();$note=sanitize_textarea_field((string)($p['approval_note']??''));if(strlen(trim($note))<20)return $this->bad('Independent Owner review note is required for final settlement.');
		global $wpdb;if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start final-settlement approval.','hr_transaction_failed',500);
		try{
			$r=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_exit_settlements'),$id),ARRAY_A);
			if(!$r||$r['status']!=='CALCULATED')throw new RuntimeException('Only a calculated settlement can be submitted to Owner review.');
			if((int)$r['created_by']===(int)get_current_user_id())throw new RuntimeException('Maker-checker: settlement preparer cannot approve the settlement.');
			$rules=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE id=%d AND rule_type='FINAL_SETTLEMENT' AND review_status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s)",$this->table('hr_rule_sets'),(int)$r['rule_set_id'],$r['exit_date'],$r['exit_date']),ARRAY_A);
			if(!$rules||$rules['version_label']!==$r['rule_version'])throw new RuntimeException('The exact approved final-settlement rule version is no longer valid for the exit date.');
			$reconciled=Stockland_Money::add($r['taxable_total'],$r['exempt_total']);
			if(Stockland_Money::minor($reconciled)!==Stockland_Money::minor($r['gross_total']))throw new RuntimeException('Gross versus taxable/exempt settlement totals do not reconcile.');
			$net=Stockland_Money::subtract(Stockland_Money::subtract(Stockland_Money::subtract($r['gross_total'],$r['tax_total']),$r['employee_pension_total']),$r['other_deductions_total']);
			if(Stockland_Money::minor($net)!==Stockland_Money::minor($r['net_total']))throw new RuntimeException('Settlement net total does not reconcile to gross, PAYE, employee pension and lawful deductions.');
			if(Stockland_DB::update_record($this->table('hr_exit_settlements'),array('status'=>'APPROVED','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql')),array('id'=>$id,'status'=>'CALCULATED'))===false)throw new RuntimeException('Could not approve settlement.');
			if(!$this->event('exit-settlement',$id,'SETTLEMENT_APPROVED','CALCULATED','APPROVED',array('approval_note'=>$note,'rule_version'=>$r['rule_version'],'gross_total'=>$r['gross_total'],'net_total'=>$r['net_total']),$r['rule_set_id'],$r['rule_version']))throw new RuntimeException('Settlement approval audit failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Settlement approval commit failed.');
			return rest_ensure_response(array('id'=>$id,'status'=>'APPROVED','message'=>'Settlement approved; payment and accounting posting are separate.'));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'settlement_approval_failed',409);}
	}

	public function create_rule(WP_REST_Request $req){
		$p=$req->get_json_params();$type=strtoupper(sanitize_key((string)($p['rule_type']??'')));$allowed=array('PAYROLL','ALLOWANCE','LEAVE','OVERTIME','FINAL_SETTLEMENT','INDIVIDUAL_PAYEE');$version=sanitize_text_field((string)($p['version_label']??''));$from=$this->date($p['effective_from']??null,false);$to=$this->date($p['effective_to']??null,true);$title=sanitize_text_field((string)($p['source_title']??''));$url=esc_url_raw((string)($p['source_url']??''));$clause=sanitize_text_field((string)($p['source_clause']??''));$sha=strtolower(sanitize_text_field((string)($p['source_sha256']??'')));$rules=$this->json_value($p['rules_json']??array(),'rules_json');if(is_wp_error($rules))return $rules;
		if(!in_array($type,$allowed,true)||$version===''||$from===false||$to===false||($to&&$to<$from)||$title===''||!preg_match('~^https://~i',$url)||$clause===''||!preg_match('/^[a-f0-9]{64}$/',$sha))return $this->bad('Rule type, version, effective dates, official HTTPS source, clause and source SHA-256 are mandatory.');
		if(Stockland_DB::insert_record($this->table('hr_rule_sets'),array('rule_code'=>sanitize_key((string)($p['rule_code']??$type)),'rule_type'=>$type,'version_label'=>$version,'jurisdiction'=>sanitize_text_field((string)($p['jurisdiction']??'ETHIOPIA-FEDERAL')),'effective_from'=>$from,'effective_to'=>$to,'source_title'=>$title,'source_url'=>$url,'source_clause'=>$clause,'source_sha256'=>$sha,'source_publication_date'=>$this->date($p['source_publication_date']??null,true),'review_status'=>'DRAFT','rules_json'=>$rules,'created_by'=>get_current_user_id()))===false)return $this->bad('Rule-set insert failed. The version or source identifier may already exist.','hr_rule_create_failed',409);
		global $wpdb;$id=(int)$wpdb->insert_id;$components=$p['components']??array();if(!is_array($components))return $this->bad('Rule components must be a list.');
		if($type==='ALLOWANCE'&&!$components)return $this->bad('An allowance rule requires explicit per-category classification components.');
		foreach($components as $c){if(!is_array($c)||empty($c['category'])||empty($c['source_clause']))return $this->bad('Each allowance rule component requires category and source clause.');$t=strtoupper(sanitize_key((string)($c['tax_treatment']??'TAXABLE')));if(!in_array($t,array('TAXABLE','EXEMPT_CAP','EXEMPT_FULL'),true))return $this->bad('Unknown tax treatment.');$cap=isset($c['exemption_cap'])?Stockland_Money::decimal(Stockland_Money::minor($c['exemption_cap'])):null;if($t==='EXEMPT_CAP'&&($cap===null||Stockland_Money::minor($cap)<0))return $this->bad('A non-negative exemption cap is required for EXEMPT_CAP.');if(Stockland_DB::insert_record($this->table('hr_rule_components'),array('rule_set_id'=>$id,'category'=>strtoupper(sanitize_key((string)$c['category'])),'tax_treatment'=>$t,'exemption_cap'=>$cap,'pensionable_treatment'=>strtoupper(sanitize_key((string)($c['pensionable_treatment']??'SALARY_ONLY'))),'pensionable_cap'=>isset($c['pensionable_cap'])?Stockland_Money::decimal(Stockland_Money::minor($c['pensionable_cap'])):null,'source_clause'=>sanitize_text_field((string)$c['source_clause']),'source_note'=>sanitize_textarea_field((string)($c['source_note']??'')),'created_by'=>get_current_user_id()))===false)return $this->bad('Could not save rule component.');}
		$this->event('rule-set',$id,'RULE_DRAFT',null,'DRAFT',array('type'=>$type,'version'=>$version,'source_sha256'=>$sha));return rest_ensure_response(array('id'=>$id,'review_status'=>'DRAFT','message'=>'Draft only. Owner cannot approve a rule created by the same account; use independent preparation and legal review.'));
	}

	/**
	 * Stores a signed independent legal opinion in the encrypted private vault and links it to a DRAFT rule.
	 * The uploader cannot activate the rule; the separate Owner approval step ratifies the exact bytes/hash.
	 */
	public function upload_rule_legal_opinion(WP_REST_Request $req){
		$id=(int)$req['id'];
		$files=$req->get_file_params();
		$file=is_array($files)&&isset($files['file'])?$files['file']:null;
		if(!is_array($file)||!isset($file['name'])||!in_array(strtolower(pathinfo(sanitize_file_name((string)$file['name']),PATHINFO_EXTENSION)),array('pdf','docx'),true)){
			return $this->bad('Upload the signed independent legal opinion as a PDF or DOCX file.','hr_legal_opinion_file_required',400);
		}
		$stored=Stockland_HR_Private_Vault::store_upload($file);
		if(is_wp_error($stored))return $stored;
		if(empty($stored['private_file_ref'])||!preg_match('/^[a-f0-9]{64}$/i',(string)($stored['file_sha256']??''))||!in_array((string)($stored['mime_type']??''),array('application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),true)){
			if(!empty($stored['private_file_ref']))Stockland_HR_Private_Vault::delete($stored['private_file_ref']);
			return $this->bad('The uploaded legal opinion failed private-vault type or integrity validation.','hr_legal_opinion_invalid',415);
		}
		global $wpdb;
		if(Stockland_DB::execute_query('START TRANSACTION')===false){Stockland_HR_Private_Vault::delete($stored['private_file_ref']);return $this->bad('Could not start legal-opinion attachment transaction.','hr_transaction_failed',500);}
		try{
			$rule=Stockland_DB::read_row($wpdb->prepare('SELECT id,rule_type,review_status,rules_json FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_rule_sets'),$id),ARRAY_A);
			if(!$rule||strtoupper((string)$rule['review_status'])!=='DRAFT')throw new RuntimeException('A legal opinion can only be attached to a DRAFT statutory rule.');
			if(!in_array(strtoupper((string)$rule['rule_type']),array('PAYROLL','ALLOWANCE','FINAL_SETTLEMENT','INDIVIDUAL_PAYEE','LEAVE','OVERTIME'),true))throw new RuntimeException('A legal opinion attachment is only valid for statutory rule types.');
			$existing=(int)Stockland_DB::read_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE subject_type='RULE_SET' AND subject_id=%d AND document_type='LEGAL_OPINION' AND status IN ('PENDING_REVIEW','APPROVED')",$this->table('hr_documents'),$id));
			if($existing>0)throw new RuntimeException('This rule already has a legal opinion attachment. Create a new rule version to replace legal evidence.');
			$inserted=Stockland_DB::insert_record($this->table('hr_documents'),array(
				'subject_type'=>'RULE_SET','subject_id'=>$id,'document_type'=>'LEGAL_OPINION',
				'document_reference'=>$stored['private_file_ref'],'document_sha256'=>strtolower($stored['file_sha256']),
				'status'=>'PENDING_REVIEW','created_by'=>get_current_user_id(),
				'notes'=>'Encrypted independent professional legal opinion; pending separate Stockland Owner ratification.'
			));
			$doc_id=false===$inserted?0:(int)$wpdb->insert_id;
			if($doc_id<1)throw new RuntimeException('Could not register the encrypted legal opinion document.');
			$payload=json_decode((string)$rule['rules_json'],true);
			if(!is_array($payload))throw new RuntimeException('Rule JSON is invalid; legal opinion was not linked.');
			if(!isset($payload['qualified_legal_review'])||!is_array($payload['qualified_legal_review']))$payload['qualified_legal_review']=array();
			$payload['qualified_legal_review']['opinion_document_id']=(int)$doc_id;
			$payload['qualified_legal_review']['opinion_sha256']=strtolower($stored['file_sha256']);
			$json=wp_json_encode($payload);
			if(!is_string($json)||Stockland_DB::update_record($this->table('hr_rule_sets'),array('rules_json'=>$json),array('id'=>$id))===false)throw new RuntimeException('Could not persist the exact legal-opinion reference on the DRAFT rule.');
			if(!$this->event('rule-set',$id,'RULE_LEGAL_OPINION_ATTACHED','DRAFT','DRAFT',array('document_id'=>(int)$doc_id,'document_sha256'=>strtolower($stored['file_sha256']),'mime_type'=>$stored['mime_type'],'size_bytes'=>(int)$stored['size_bytes'])))throw new RuntimeException('Legal-opinion attachment audit event failed.');
			if(false===Stockland_DB::execute_query('COMMIT'))throw new RuntimeException('Legal-opinion attachment transaction did not commit.');
			return rest_ensure_response(array('rule_set_id'=>$id,'document_id'=>(int)$doc_id,'document_status'=>'PENDING_REVIEW','document_sha256'=>strtolower($stored['file_sha256']),'encrypted_at_rest'=>true,'message'=>'The signed opinion is stored encrypted. It is not active until its independent-review details pass and a different authorized Stockland Owner ratifies this exact document.'));
		}catch(Throwable $e){
			Stockland_DB::execute_query('ROLLBACK');
			Stockland_HR_Private_Vault::delete($stored['private_file_ref']);
			return $this->bad($e->getMessage(),'hr_legal_opinion_attach_failed',409);
		}
	}

	public function approve_rule(WP_REST_Request $req){
		if(!$this->owner())return $this->bad('Owner approval is required.','forbidden',403);$id=(int)$req['id'];$p=$req->get_json_params();$note=sanitize_textarea_field((string)($p['independent_review_note']??''));if(strlen($note)<30)return $this->bad('Independent statutory/payroll reviewer and approved test-vector evidence are required.');global $wpdb;
		if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start rule approval transaction.','hr_transaction_failed',500);
		try{$r=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_rule_sets'),$id),ARRAY_A);if(!$r||$r['review_status']!=='DRAFT')throw new RuntimeException('Only DRAFT rules can be approved.');if((int)$r['created_by']===get_current_user_id())throw new RuntimeException('Maker-checker control: the rule creator cannot approve their own rule.');if(!preg_match('/^[a-f0-9]{64}$/i',(string)$r['source_sha256'])||!preg_match('~^https://~i',(string)$r['source_url'])||empty($r['source_clause']))throw new RuntimeException('Official source evidence is incomplete.');
			$rules=json_decode((string)$r['rules_json'],true);if(!is_array($rules))throw new RuntimeException('Rule JSON is invalid.');
			if(in_array($r['rule_type'],array('PAYROLL','ALLOWANCE','FINAL_SETTLEMENT','INDIVIDUAL_PAYEE','LEAVE','OVERTIME'),true)&&!Stockland_HR_Lifecycle::has_qualified_legal_review($rules))throw new RuntimeException('Independent qualified Ethiopian legal/payroll review evidence and approved parameter scope are required before statutory rules can be activated.');
			if(in_array($r['rule_type'],array('PAYROLL','ALLOWANCE','FINAL_SETTLEMENT','INDIVIDUAL_PAYEE','LEAVE','OVERTIME'),true)&&!Stockland_HR_Lifecycle::verify_legal_opinion_document($rules,$id,'PENDING_REVIEW',true))throw new RuntimeException('The signed independent legal opinion must be attached in the encrypted private vault; its document ID, rule scope and SHA-256 must match before Owner ratification.');
			if($r['rule_type']==='INDIVIDUAL_PAYEE'){if(!in_array(strtoupper((string)($rules['withholding_method']??'')),array('RATE_ON_GROSS_CASH','RATE_ON_CASH_PLUS_IN_KIND','NO_WITHHOLDING'),true))throw new RuntimeException('INDIVIDUAL_PAYEE rule must declare a legally reviewed withholding method.');if(strtoupper((string)($rules['withholding_method']??''))!=='NO_WITHHOLDING'&&(!isset($rules['withholding_rate'])||!is_string($rules['withholding_rate'])||!preg_match('/^(0|1)(\\.[0-9]{1,6})?$/D',$rules['withholding_rate'])))throw new RuntimeException('INDIVIDUAL_PAYEE rule needs an explicit reviewed withholding rate.');if(!in_array('withholding_method',$rules['qualified_legal_review']['approved_parameters']??array(),true)||!in_array('cash_in_kind_tax_basis',$rules['qualified_legal_review']['approved_parameters']??array(),true))throw new RuntimeException('Legal opinion must explicitly approve payee withholding method and cash/in-kind tax basis.');}
			if($r['rule_type']==='PAYROLL'&&!Stockland_HR_Lifecycle::has_payroll_calculator_contract($rules))throw new RuntimeException('Payroll rule does not match both legacy and frozen-run calculator contracts. Both band schedules, tax-base methods, pension rates, component treatments and reviewer-approved parameter scopes must reconcile.');
			if($r['rule_type']==='FINAL_SETTLEMENT'&&!is_array($rules['component_rules']??null))throw new RuntimeException('Final-settlement rule requires explicit component_rules with approved legal treatment.');
			if($r['rule_type']==='ALLOWANCE'){ $cs=Stockland_DB::read_results($wpdb->prepare('SELECT * FROM %i WHERE rule_set_id=%d',$this->table('hr_rule_components'),$id),ARRAY_A);if(!$cs)throw new RuntimeException('Allowance rules require components.');foreach($cs as $c){if($c['tax_treatment']==='EXEMPT_CAP'&&$c['exemption_cap']===null)throw new RuntimeException('EXEMPT_CAP missing cap.');}}
			$overlap=Stockland_DB::read_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE id<>%d AND rule_type=%s AND review_status='APPROVED' AND effective_from<=COALESCE(NULLIF(%s,''),'9999-12-31') AND COALESCE(effective_to,'9999-12-31')>=%s",$this->table('hr_rule_sets'),$id,$r['rule_type'],$r['effective_to'],$r['effective_from']));if(''!==(string)$wpdb->last_error)throw new RuntimeException('Could not verify statutory rule effective-date overlap: '.$wpdb->last_error);if((int)$overlap>0)throw new RuntimeException('An approved rule of this type overlaps these effective dates. Close the existing version first.');
			if(in_array($r['rule_type'],array('PAYROLL','ALLOWANCE','FINAL_SETTLEMENT','INDIVIDUAL_PAYEE','LEAVE','OVERTIME'),true)){ $doc_id=(int)$rules['qualified_legal_review']['opinion_document_id']; if(Stockland_DB::update_record($this->table('hr_documents'),array('status'=>'APPROVED','verified_by'=>get_current_user_id(),'verified_at'=>current_time('mysql')),array('id'=>$doc_id,'status'=>'PENDING_REVIEW'))===false)throw new RuntimeException('Could not persist Owner ratification of the exact legal opinion document.'); }
			if(Stockland_DB::update_record($this->table('hr_rule_sets'),array('review_status'=>'APPROVED','reviewer_note'=>$note,'approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql')),array('id'=>$id))===false)throw new RuntimeException('Could not update rule approval.');
			if(!$this->event('rule-set',$id,'RULE_APPROVED','DRAFT','APPROVED',array('note'=>$note,'source_sha256'=>$r['source_sha256'],'opinion_document_id'=>(int)($rules['qualified_legal_review']['opinion_document_id']??0),'opinion_sha256'=>(string)($rules['qualified_legal_review']['opinion_sha256']??'')),$id,$r['version_label']))throw new RuntimeException('Audit event failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Rule approval commit failed.');
			return rest_ensure_response(array('id'=>$id,'review_status'=>'APPROVED','rule_version'=>$r['version_label']));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hr_rule_approval_failed',409);}
	}
	public function allowance_preview(WP_REST_Request $req){
		$p=$req->get_json_params();$date=$this->date($p['effective_date']??current_time('Y-m-d'),false);if($date===false)return $this->bad('A valid effective date is required.');$items=$p['allowances']??array();if(!is_array($items))return $this->bad('Allowances must be a list.');try{$r=Stockland_HR_Lifecycle::split_allowances($items,$date);$input='0.00';foreach($r['components'] as $c)$input=Stockland_Money::add($input,$c['amount']);$check=Stockland_Money::add($r['taxable_total'],$r['exempt_total']);if(Stockland_Money::minor($input)!==Stockland_Money::minor($check))return $this->bad('Allowance totals do not reconcile.','allowance_reconciliation_failed',409);$r['input_total']=$input;$r['reconciled']=true;$r['is_legal_rule_configured']=!empty($r['rule_set_id']);return rest_ensure_response($r);}catch(Throwable $e){return $this->bad($e->getMessage(),'allowance_preview_failed',409);}
	}
	public function save_compensation(WP_REST_Request $req){
		if(!Stockland_Authority::can_manage_payroll())return $this->bad('Payroll preparation permission required.','forbidden',403);$p=$req->get_json_params();$employee=(int)($p['employee_id']??0);$from=$this->date($p['effective_from']??null,false);if($employee<1||$from===false)return $this->bad('Employee and effective date are required.');$base=Stockland_Money::decimal(Stockland_Money::minor($p['base_salary']??'0'));$deduct=Stockland_Money::decimal(Stockland_Money::minor($p['standard_deduction_total']??'0'));$pensionable=Stockland_Money::decimal(Stockland_Money::minor($p['pensionable_salary']??$base));$items=$p['allowances']??array();if(!is_array($items))return $this->bad('Allowances must be structured rows.');global $wpdb;$emp=Stockland_DB::read_row($wpdb->prepare('SELECT id,employee_id,full_name,branch_location_id,status FROM %i WHERE id=%d',$this->table('employees'),$employee),ARRAY_A);if(!$emp||$emp['status']!=='ACTIVE')return $this->bad('Compensation requires an active employee.');
		try{$split=Stockland_HR_Lifecycle::split_allowances($items,$from);}catch(Throwable $e){return $this->bad($e->getMessage(),'allowance_classification_failed',409);}if(!empty($emp['branch_location_id'])&&!Stockland_Authority::can_access_location((int)$emp['branch_location_id']))return $this->bad('Employee is outside the authorized branch scope.','hr_location_forbidden',403);
		$gross=Stockland_Money::add($base,Stockland_Money::add($split['taxable_total'],$split['exempt_total']));if(Stockland_Money::minor($pensionable)>Stockland_Money::minor($gross))return $this->bad('Pensionable salary cannot exceed gross compensation.');if(Stockland_Money::minor($pensionable)!==Stockland_Money::minor($base)&&strlen(trim((string)($p['notes']??'')))<20)return $this->bad('Non-standard pensionability needs a documented legal or contract basis (minimum 20 characters).');$hasExempt=Stockland_Money::minor($split['exempt_total'])>0;$exception=$hasExempt||Stockland_Money::minor($pensionable)!==Stockland_Money::minor($base);
		$status=$exception?'RULE_CLASSIFIED':'MANAGEMENT_PREPARED';$snapshot=wp_json_encode($split['components']);$row=array('employee_id'=>$employee,'effective_from'=>$from,'base_salary'=>$base,'allowance_total'=>Stockland_Money::add($split['taxable_total'],$split['exempt_total']),'standard_deduction_total'=>$deduct,'currency'=>'ETB','notes'=>sanitize_textarea_field((string)($p['notes']??'')),'taxable_allowance_total'=>$split['taxable_total'],'exempt_allowance_total'=>$split['exempt_total'],'pensionable_salary'=>$pensionable,'statutory_classification_status'=>$status,'statutory_classification_note'=>sanitize_textarea_field((string)($p['notes']??'')),'allowance_breakdown_json'=>$snapshot,'statutory_rule_set_id'=>null,'statutory_rule_version'=>null,'allowance_rule_set_id'=>$split['rule_set_id'],'allowance_rule_version'=>$split['rule_version'],'approval_status'=>'DRAFT','created_by'=>get_current_user_id());
		if(Stockland_Money::minor($split['exempt_total'])>0&&!$split['rule_set_id'])return $this->bad('No approved effective allowance rule exists. An exemption cannot be saved without source-backed authorization.','allowance_rule_missing',409);
		if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start compensation transaction.','hr_transaction_failed',500);
		try{if(Stockland_DB::insert_record($this->table('employee_compensation'),$row)===false)throw new RuntimeException('Could not save compensation draft.');$cid=(int)$wpdb->insert_id;
			foreach($split['components'] as $c){if(Stockland_DB::insert_record($this->table('hr_compensation_components'),array('employee_id'=>$employee,'compensation_id'=>$cid,'component_type'=>'ALLOWANCE','category'=>$c['category'],'label'=>$c['label'],'amount'=>$c['amount'],'currency'=>'ETB','effective_from'=>$from,'tax_treatment'=>$c['tax_treatment'],'exempt_amount'=>$c['exempt_amount'],'taxable_amount'=>$c['taxable_amount'],'pensionable_amount'=>$c['pensionable_amount'],'rule_set_id'=>$c['rule_set_id'],'rule_set_version'=>$c['rule_set_version'],'source_hash'=>$c['source_hash'],'status'=>'PENDING_OWNER','created_by'=>get_current_user_id()))===false)throw new RuntimeException('Could not save allowance component.');}
			if(!$this->event('compensation',$cid,'COMPENSATION_DRAFT',null,'DRAFT',array('employee_id'=>$employee,'effective_from'=>$from,'component_count'=>count($split['components']),'allowance_rule_version'=>$split['rule_version'],'source_hashes'=>array_values(array_filter(array_column($split['components'],'source_hash'))))))throw new RuntimeException('Compensation audit failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Compensation commit failed.');
			return rest_ensure_response(array('id'=>$cid,'employee_code'=>$emp['employee_id'],'status'=>'DRAFT','base_salary'=>$base,'taxable_allowance_total'=>$split['taxable_total'],'exempt_allowance_total'=>$split['exempt_total'],'allowance_rule_version'=>$split['rule_version'],'reconciled'=>Stockland_Money::minor(Stockland_Money::add($split['taxable_total'],$split['exempt_total']))===Stockland_Money::minor($row['allowance_total'])));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hr_compensation_save_failed',409);}
	}
	public function approve_compensation(WP_REST_Request $req){
		$id=(int)$req['id'];$approvalPayload=$req->get_json_params();$approvalNote=sanitize_textarea_field((string)($approvalPayload['approval_note']??''));if(strlen(trim($approvalNote))<10)return $this->bad('Owner approval rationale is required (minimum 10 characters).','approval_note_required',400);global $wpdb;if(!$this->owner())return $this->bad('Owner approval required.','forbidden',403);
		if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start approval transaction.','hr_transaction_failed',500);
		try{
			$r=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('employee_compensation'),$id),ARRAY_A);
			if(!$r)throw new RuntimeException('Compensation record was not found.');
            $approvalStatus=strtoupper(trim((string)($r['approval_status']??'DRAFT')));
            $creatorId=(int)($r['created_by']??0);
            $approverId=(int)($r['approved_by']??0);
            $hasApprovalEvidence=$creatorId>0 && $approverId>0 && $approverId!==$creatorId && !empty($r['approved_at']) && '0000-00-00 00:00:00' !== (string)$r['approved_at'];
            if('APPROVED'===$approvalStatus && $hasApprovalEvidence)throw new RuntimeException('This compensation record already has explicit approval evidence.');
            if(!in_array($approvalStatus,array('DRAFT','REVIEW_REQUIRED','APPROVED'),true))throw new RuntimeException('This compensation record is not in a reviewable state.');
            $previousApprovalState=('APPROVED'===$approvalStatus || 'REVIEW_REQUIRED'===$approvalStatus)?'REVIEW_REQUIRED':'DRAFT';
			if($creatorId<1)throw new RuntimeException('Compensation has no trustworthy preparer identity. Reconcile the historical source before approval.');
			if($creatorId===(int)get_current_user_id())throw new RuntimeException('Maker-checker: the compensation preparer cannot approve their own change.');
			$snapshotRaw=trim((string)($r['allowance_breakdown_json']??''));$legacyAggregateSnapshot=false;
			if(''===$snapshotRaw){
				// Older installations may have stored only aggregate allowance totals. Permit
				// independent Owner re-review of a taxable-only aggregate; never infer or
				// reconstruct an exemption, category, or legal classification from missing detail.
				if(!array_key_exists('taxable_allowance_total',$r)||!array_key_exists('exempt_allowance_total',$r)||!array_key_exists('allowance_total',$r))throw new RuntimeException('Legacy compensation lacks the aggregate totals required for safe Owner re-review.');
				$legacyTaxable=Stockland_Money::decimal(Stockland_Money::minor($r['taxable_allowance_total']));$legacyExempt=Stockland_Money::decimal(Stockland_Money::minor($r['exempt_allowance_total']));$legacyTotal=Stockland_Money::decimal(Stockland_Money::minor($r['allowance_total']));
				if(Stockland_Money::minor($legacyExempt)!==0||Stockland_Money::minor(Stockland_Money::add($legacyTaxable,$legacyExempt))!==Stockland_Money::minor($legacyTotal))throw new RuntimeException('Legacy compensation has an exemption or unreconciled allowance total; reconstruct and verify its source components before approval.');
				$snapshot=Stockland_Money::minor($legacyTaxable)>0?array(array('category'=>'LEGACY_TAXABLE_AGGREGATE','label'=>'Legacy taxable allowance aggregate — category detail not supplied','amount'=>$legacyTaxable,'tax_treatment'=>'TAXABLE','legacy_aggregate_reconstructed'=>true)):array();
				$legacyAggregateSnapshot=true;
			}else{$snapshot=json_decode($snapshotRaw,true);if(!is_array($snapshot)||JSON_ERROR_NONE!==json_last_error())throw new RuntimeException('Compensation allowance snapshot is malformed.');}
			$tax='0.00';$exempt='0.00';$verified=array();$needsOwner=false;
			foreach($snapshot as $c){
				if(!is_array($c))throw new RuntimeException('Compensation component row is malformed.');
				$amount=Stockland_Money::decimal(Stockland_Money::minor($c['amount']??'0.00'));
				if(strtoupper((string)($c['tax_treatment']??'TAXABLE'))==='EXEMPT'){
					$needsOwner=true;
					$ruleId=(int)($c['rule_set_id']??0);
					$rule=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE id=%d AND rule_type='ALLOWANCE' AND review_status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s)",$this->table('hr_rule_sets'),$ruleId,$r['effective_from'],$r['effective_from']),ARRAY_A);
					if(!$rule||!preg_match('/^[a-f0-9]{64}$/i',(string)($rule['source_sha256']??''))||!hash_equals(strtolower((string)$rule['source_sha256']),strtolower((string)($c['source_hash']??'')))||empty($c['legal_basis'])||empty($c['evidence_reference']))throw new RuntimeException('Every exempt component needs an effective approved rule, matching official-source SHA-256, clause and evidence reference.');
					$c['owner_verified']=true;$c['verified_by']=(int)get_current_user_id();$c['verified_at']=current_time('mysql');
					$exempt=Stockland_Money::add($exempt,$amount);
				}else{
					$c['tax_treatment']='TAXABLE';$c['owner_verified']=false;
					$tax=Stockland_Money::add($tax,$amount);
				}
				$verified[]=$c;
			}
			if(Stockland_Money::minor($tax)!==Stockland_Money::minor($r['taxable_allowance_total']??'0.00')||Stockland_Money::minor($exempt)!==Stockland_Money::minor($r['exempt_allowance_total']??'0.00')||Stockland_Money::minor(Stockland_Money::add($tax,$exempt))!==Stockland_Money::minor($r['allowance_total']??'0.00'))throw new RuntimeException('Taxable + exempt component snapshots must reconcile exactly to the approved allowance total.');
			$nonstandard=Stockland_Money::minor($r['pensionable_salary'])!==Stockland_Money::minor($r['base_salary']);
			if($nonstandard&&strlen(trim((string)($r['notes']??'')))<20)throw new RuntimeException('Non-standard pensionability needs a documented legal/contract basis of at least 20 characters.');
			if($needsOwner&&$nonstandard&&strlen(trim((string)($r['statutory_classification_note']??'')))<20)throw new RuntimeException('Exempt/non-standard compensation needs an explicit Owner legal-classification note.');
			$status=($needsOwner||$nonstandard)?'OWNER_CLASSIFIED':'MANAGEMENT_PREPARED';
			$versionIds=array_values(array_unique(array_filter(array_map(static function($c){return (int)($c['rule_set_id']??0);},$verified))));
			$versions=array_values(array_unique(array_filter(array_map(static function($c){return (string)($c['rule_set_version']??'');},$verified))));
			$update=array('approval_status'=>'APPROVED','approved_by'=>get_current_user_id(),'approved_at'=>current_time('mysql'),'statutory_classification_status'=>$status,'allowance_breakdown_json'=>wp_json_encode($verified),'allowance_rule_set_id'=>count($versionIds)===1?$versionIds[0]:null,'allowance_rule_version'=>count($versions)===1?$versions[0]:(count($versions)>1?'MULTI':null));
			if(Stockland_DB::update_record($this->table('employee_compensation'),$update,array('id'=>$id))===false)throw new RuntimeException('Approval save failed.');
			if(Stockland_DB::update_record($this->table('hr_compensation_components'),array('status'=>'APPROVED'),array('compensation_id'=>$id))===false)throw new RuntimeException('Allowance component approval failed.');
			if(!$this->event('compensation',$id,'COMPENSATION_APPROVED',$previousApprovalState,'APPROVED',array('approval_note'=>$approvalNote,'allowance_rule_version'=>$update['allowance_rule_version'],'classification'=>$status,'taxable_total'=>$tax,'exempt_total'=>$exempt,'recovered_legacy_implicit_approval'=>('REVIEW_REQUIRED'===$previousApprovalState),'legacy_taxable_aggregate_reconstructed'=>$legacyAggregateSnapshot)))throw new RuntimeException('Audit event failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Approval commit failed.');
			return rest_ensure_response(array('id'=>$id,'approval_status'=>'APPROVED','classification'=>$status,'taxable_allowance_total'=>$tax,'exempt_allowance_total'=>$exempt));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'hr_compensation_approval_failed',409);}
	}
	public function calculate_exit(WP_REST_Request $req){
		if(!Stockland_Authority::can_manage_hr())return $this->bad('HR management permission required.','forbidden',403);$p=$req->get_json_params();$employee=(int)($p['employee_id']??0);$exitDate=$this->date($p['exit_date']??null,false);$lastWork=$this->date($p['last_work_date']??null,false);$components=$p['components']??array();if($employee<1||$exitDate===false||$lastWork===false||$lastWork>$exitDate||!is_array($components)||!$components)return $this->bad('Employee, exit/last-work dates and settlement components are required.');
		global $wpdb;$emp=Stockland_DB::read_row($wpdb->prepare('SELECT id,employee_id,full_name,branch_location_id,status FROM %i WHERE id=%d',$this->table('employees'),$employee),ARRAY_A);if(!$emp)return $this->bad('Employee not found.');if(!empty($emp['branch_location_id'])&&!Stockland_Authority::can_access_location((int)$emp['branch_location_id']))return $this->bad('Employee is outside authorized location.','hr_location_forbidden',403);
		$final=Stockland_DB::read_row($wpdb->prepare("SELECT * FROM %i WHERE rule_type='FINAL_SETTLEMENT' AND review_status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s) ORDER BY effective_from DESC,id DESC LIMIT 1",$this->table('hr_rule_sets'),$exitDate,$exitDate),ARRAY_A);if(!$final)return $this->bad('No Owner-approved final-settlement legal ruleset covers the exit date. Settlement cannot be calculated.','settlement_rules_unapproved',409);$policy=json_decode($final['rules_json'],true);$cr=$policy['component_rules']??null;if(!is_array($cr)||!$cr)return $this->bad('Final-settlement rule lacks component treatment rules.','settlement_rules_invalid',409);
		$payroll=Stockland_HR_Lifecycle::payroll_rules_for_period($exitDate,$exitDate);if(is_wp_error($payroll))return $payroll;$gross='0.00';$taxable='0.00';$exempt='0.00';$pensionable='0.00';$normalized=array();
		foreach($components as $c){if(!is_array($c)||empty($c['category'])||!isset($c['amount'],$c['source_reference'],$c['legal_basis']))return $this->bad('Each final settlement line needs category, amount, legal basis and source reference.');$cat=strtoupper(sanitize_key((string)$c['category']));if(!isset($cr[$cat])||!is_array($cr[$cat]))return $this->bad('Settlement component '.$cat.' has no approved legal classification.','settlement_component_unclassified',409);$amount=Stockland_Money::decimal(Stockland_Money::minor($c['amount']));if(Stockland_Money::minor($amount)<0)return $this->bad('Settlement amounts cannot be negative.');$rule=$cr[$cat];$t=strtoupper((string)($rule['tax_treatment']??'UNCLASSIFIED'));$ex='0.00';if($t==='EXEMPT_FULL')$ex=$amount;elseif($t==='EXEMPT_CAP'){if(!isset($rule['exemption_cap']))return $this->bad('Settlement exemption cap is missing.','settlement_cap_missing',409);$ex=Stockland_Money::decimal(min(Stockland_Money::minor($amount),Stockland_Money::minor($rule['exemption_cap'])));}elseif($t!=='TAXABLE')return $this->bad('Settlement tax treatment is unsupported.','settlement_treatment_invalid',409);$tx=Stockland_Money::subtract($amount,$ex);$pension=strtoupper((string)($rule['pensionable_treatment']??'NOT_PENSIONABLE'))==='PENSIONABLE'?$amount:'0.00';$gross=Stockland_Money::add($gross,$amount);$taxable=Stockland_Money::add($taxable,$tx);$exempt=Stockland_Money::add($exempt,$ex);$pensionable=Stockland_Money::add($pensionable,$pension);$normalized[]=array('category'=>$cat,'label'=>sanitize_text_field((string)($c['label']??$cat)),'amount'=>$amount,'taxable_amount'=>$tx,'exempt_amount'=>$ex,'pensionable_amount'=>$pension,'legal_basis'=>sanitize_text_field((string)$c['legal_basis']),'source_reference'=>sanitize_text_field((string)$c['source_reference']),'rule_version'=>$final['version_label'],'rule_source_sha256'=>$final['source_sha256']);}
		$other=Stockland_Money::decimal(Stockland_Money::minor($p['other_deductions']??'0'));if(Stockland_Money::minor($other)<0)return $this->bad('Other deductions cannot be negative.');try{$calc=Stockland_Payroll_Statutory::calculate($taxable,'0.00',$exempt,$pensionable,$other,$payroll);}catch(Throwable $e){return $this->bad($e->getMessage(),'settlement_calculation_failed',409);}$actualGross=Stockland_Money::add($taxable,$exempt);if(Stockland_Money::minor($actualGross)!==Stockland_Money::minor($gross))return $this->bad('Settlement reconciliation failed.','settlement_reconciliation_failed',409);
		$code=sanitize_text_field((string)($p['settlement_code']??('SET-'.$emp['employee_id'].'-'.$exitDate)));$row=array('settlement_code'=>$code,'employee_id'=>$employee,'exit_type'=>sanitize_key((string)($p['exit_type']??'RESIGNATION')),'exit_date'=>$exitDate,'last_work_date'=>$lastWork,'reason'=>sanitize_textarea_field((string)($p['reason']??'')),'components_json'=>wp_json_encode(array('lines'=>$normalized,'other_deductions'=>$other,'calculation'=>$calc)),'gross_total'=>$gross,'taxable_total'=>$taxable,'exempt_total'=>$exempt,'tax_total'=>$calc['income_tax'],'employee_pension_total'=>$calc['employee_pension'],'employer_pension_total'=>$calc['employer_pension'],'other_deductions_total'=>$other,'net_total'=>$calc['net_pay'],'rule_set_id'=>(int)$final['id'],'rule_version'=>(string)$final['version_label'],'status'=>'CALCULATED','submitted_by'=>get_current_user_id(),'submitted_at'=>current_time('mysql'),'created_by'=>get_current_user_id());
		if(Stockland_DB::insert_record($this->table('hr_exit_settlements'),$row)===false)return $this->bad('Could not create settlement. Ensure the settlement code is unique.','settlement_insert_failed',409);$id=(int)$wpdb->insert_id;$ok=$this->event('exit-settlement',$id,'SETTLEMENT_CALCULATED',null,'CALCULATED',array('employee_id'=>$employee,'gross_total'=>$gross,'taxable_total'=>$taxable,'exempt_total'=>$exempt,'net_total'=>$calc['net_pay'],'component_count'=>count($normalized),'rule_source_sha256'=>$final['source_sha256']),$final['id'],$final['version_label']);if(!$ok)return $this->bad('Settlement created but audit event failed; do not approve.','hr_audit_event_failed',500);return rest_ensure_response(array('id'=>$id,'status'=>'CALCULATED','gross_total'=>$gross,'taxable_total'=>$taxable,'exempt_total'=>$exempt,'tax_total'=>$calc['income_tax'],'employee_pension_total'=>$calc['employee_pension'],'net_total'=>$calc['net_pay'],'rule_version'=>$final['version_label'],'message'=>'Calculated using approved rule versions. Review component eligibility and source documents before Owner approval.'));
	}
	public function pay_exit(WP_REST_Request $req){
		if(!$this->owner())return $this->bad('Owner approval required.','forbidden',403);$id=(int)$req['id'];$p=$req->get_json_params();$reference=sanitize_text_field((string)($p['payment_reference']??''));$method=strtoupper(sanitize_key((string)($p['payment_method']??'BANK')));if($reference===''||!in_array($method,array('BANK','CASH','CHEQUE'),true))return $this->bad('Payment reference and a valid payment method are required.');global $wpdb;
		if(Stockland_DB::execute_query('START TRANSACTION')===false)return $this->bad('Could not start settlement payment.','hr_transaction_failed',500);
		try{$r=Stockland_DB::read_row($wpdb->prepare('SELECT * FROM %i WHERE id=%d FOR UPDATE',$this->table('hr_exit_settlements'),$id),ARRAY_A);if(!$r||$r['status']!=='APPROVED')throw new RuntimeException('Only an approved settlement can be paid.');$gross=Stockland_Money::decimal(Stockland_Money::minor($r['gross_total']));$debit=Stockland_Money::add($gross,$r['employer_pension_total']??'0');$lines=array(array('account_code'=>'6200','debit'=>$gross,'credit'=>'0.00','description'=>'Final settlement gross'),array('account_code'=>'2020','debit'=>'0.00','credit'=>$r['net_total'],'description'=>'Employee final net payable'),array('account_code'=>'2031','debit'=>'0.00','credit'=>$r['tax_total'],'description'=>'Final settlement PAYE'),array('account_code'=>'2030','debit'=>'0.00','credit'=>$r['employee_pension_total'],'description'=>'Final settlement employee pension'),array('account_code'=>'2033','debit'=>'0.00','credit'=>$r['other_deductions_total'],'description'=>'Final settlement other deductions'));
			if(Stockland_Money::minor($r['employer_pension_total']??0)>0){$lines[]=array('account_code'=>'6210','debit'=>$r['employer_pension_total'],'credit'=>'0.00','description'=>'Final settlement employer pension expense');$lines[]=array('account_code'=>'2032','debit'=>'0.00','credit'=>$r['employer_pension_total'],'description'=>'Final settlement employer pension payable');}
			$credits='0.00';foreach($lines as $line)$credits=Stockland_Money::add($credits,$line['credit']);if(Stockland_Money::minor($credits)!==Stockland_Money::minor($debit))throw new RuntimeException('Settlement journal does not balance; payroll remains unposted.');
			$j=Stockland_Accounting::post_journal($r['exit_date'],'HR_FINAL_SETTLEMENT',$id,'Final settlement '.$r['settlement_code'],$lines,get_current_user_id());if(!$j)throw new RuntimeException('Accounting journal rejected the final settlement or could not balance.');$journal_id=(int)$j;if($journal_id<1)throw new RuntimeException('Accounting service did not return a journal ID.');
			if(Stockland_DB::insert_record($this->table('hr_payroll_payments'),array('payment_code'=>'SETTLEMENT-'.$r['settlement_code'],'payroll_period_id'=>0,'payment_type'=>'FINAL_SETTLEMENT','amount'=>$r['net_total'],'currency'=>'ETB','payment_method'=>$method,'payment_reference'=>$reference,'payment_date'=>current_time('Y-m-d'),'status'=>'RECORDED','recorded_by'=>get_current_user_id()))===false)throw new RuntimeException('Payment reference already exists or could not be saved.');
			if(Stockland_DB::update_record($this->table('hr_exit_settlements'),array('status'=>'PAID','paid_by'=>get_current_user_id(),'paid_at'=>current_time('mysql'),'payment_reference'=>$reference,'journal_id'=>$journal_id),array('id'=>$id))===false)throw new RuntimeException('Settlement payment status failed.');
			if(!$this->event('exit-settlement',$id,'SETTLEMENT_PAID','APPROVED','PAID',array('payment_reference'=>$reference,'payment_method'=>$method,'journal_id'=>$journal_id,'net_total'=>$r['net_total']),$r['rule_set_id'],$r['rule_version']))throw new RuntimeException('Payment audit event failed.');
			if(Stockland_DB::execute_query('COMMIT')===false)throw new RuntimeException('Settlement payment commit failed.');
			return rest_ensure_response(array('id'=>$id,'status'=>'PAID','journal_id'=>$journal_id,'payment_reference'=>$reference));
		}catch(Throwable $e){Stockland_DB::execute_query('ROLLBACK');return $this->bad($e->getMessage(),'settlement_payment_failed',409);}
	}
}