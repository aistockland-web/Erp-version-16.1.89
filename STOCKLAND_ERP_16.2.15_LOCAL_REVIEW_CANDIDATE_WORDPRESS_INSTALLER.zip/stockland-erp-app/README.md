# Stockland Ethiopia ERP — 16.2.15

One cumulative WordPress plugin package based on the supplied, checksum-verified 16.2.13 operational installer. This local release incorporates narrowly scoped data-safety, private-file encryption, health-status presentation, HR accessibility and release-provenance corrections while preserving the existing operational modules and database services.

## Package identity and source lineage

- Application version: **16.2.15**
- Base installer: `STOCKLAND_ERP_16.2.13_WORDPRESS_INSTALLER.zip`
- Base SHA-256: `74e3205d0b42151997dc356c29b09204688accee817c17a013a70cf90be04c13`
- Protected comparison / rollback reference: 16.1.95 (SHA-256 `494e777247508d009dfdb216c9607bb1bc96717197e94a0e8ad3459b7cc81625`)
- Source commit: **not supplied with the recovered installer**. This build does not invent a commit SHA.
- Build type: local cumulative package from the exact supplied installer; no GitHub/Codespaces actions or live-site writes are claimed.

The original 16.2.13 plugin remains the working base. The protected 16.1.95 package is a comparison/rollback reference, not a wholesale replacement. The 16.2.9 HR/payroll candidate and original HRX packages were not overlaid wholesale because their file/schema differences could remove later POS, inventory, CSS, HR and workflow code.

## Requirements

- WordPress 6.8 or later.
- PHP 8.3 or later, with OpenSSL and Fileinfo available for private HR documents.
- MySQL 8.0+ or MariaDB 10.11+ is the target database family for the cumulative project acceptance programme.
- HTTPS is required for authenticated operation.
- Enough PHP memory and upload capacity for the configured XLSX/PDF/DOCX workflows.

These are the project target requirements; this package was locally syntax-checked on PHP 8.4.24. A PHP 8.3 run and an actual WordPress/MySQL/MariaDB run were not available in the local build environment.

## Install / update

1. Before installing or updating, export the entire WordPress database and archive `wp-content`; verify that the backup can actually be restored to a separate test site.
2. Upload this ZIP through **WordPress → Plugins → Add New Plugin → Upload Plugin**.
3. For an existing Stockland installation, update the existing Stockland ERP plugin in place. Do not install a second copy alongside it, delete its database tables, or run a clean database reset.
4. Activate or complete the normal WordPress plugin update process, then sign in through the Stockland ERP front end and review System Health.
5. Confirm the plugin reports 16.2.15, verify the expected database table/column state, and execute the agreed role-based workflows on a restored staging copy before using the release for live transactions.
6. Preserve the prior plugin ZIP and database backup until the updated installation and rollback have been demonstrated.

This package does not automatically migrate or rewrite business history. Its only automatic legacy-data conversion is the one-file private-vault encryption described below; it does not change database rows or approval state. Any database migration is subject to the plugin's existing add-only upgrade behavior and must be tested on a restored database before production use.

## Private HR document encryption — required configuration

The HR attachment vault now requires AES-256-GCM encryption. New HR private-document uploads and downloads remain disabled until both settings are configured:

- `STOCKLAND_PRIVATE_VAULT_DIR`: an absolute, writable directory outside the public web root.
- `STOCKLAND_PRIVATE_VAULT_KEY`: a randomly generated 32-byte key, supplied as 64 hexadecimal characters or strict base64.

Generate a key on a trusted server/admin environment with `openssl rand -base64 32`. Put the resulting value in `wp-config.php` as a private constant; do not paste it into this plugin, the database, support chats, screenshots or a repository:

```php
define( 'STOCKLAND_PRIVATE_VAULT_DIR', '/absolute/private/path/stockland-hr-vault' );
define( 'STOCKLAND_PRIVATE_VAULT_KEY', 'REPLACE_WITH_THE_PRIVATE_32_BYTE_BASE64_KEY' );
```

Use a path the hosting account can write to that is not under `ABSPATH` or the web document root. The vault root and month folders must be owner-only (`0700`), and encrypted files owner-only (`0600`); the code now fails closed if these modes cannot be enforced. Store a recoverable copy of the key in a separate encrypted secrets store. Back up the encrypted vault and the key separately. If the key is lost, encrypted attachments cannot be recovered. Key rotation is not implemented in this candidate; do not replace the active key. A versioned keyring, rotation/rollback workflow and restore test are required before any rotation is attempted.

### Existing legacy HR attachments

Older vault files are plaintext, although their prior implementation stored them outside the public root with restrictive permissions and a SHA-256 digest. The new resolver does not serve a plaintext file. When an authorized HR-resource approval/download reaches a legacy file, it verifies the stored plaintext SHA-256 and atomically encrypts that one file before completing the read. The database reference and original plaintext hash remain unchanged. A guarded WP-CLI migration is also available for a planned one-file conversion after taking a verified vault backup:

```bash
wp stockland hr-vault-encrypt <private_file_ref> <plaintext_sha256>
```

The migration is per-file and refuses a hash mismatch. It does not change resource approval status. Configure and back up the encryption key before allowing authorized users to open legacy attachments.

## Compensation approval protection

- The add-only migration default for `employee_compensation.approval_status` is `DRAFT`, not `APPROVED`.
- Payroll readers, compensation totals and hire activation require `approval_status=APPROVED`, a positive `approved_by` identity and a real `approved_at` timestamp.
- Existing rows that carry an old `APPROVED` label without approval identity/time are not accepted for payroll or hire activation. An independent Owner must re-review them through the maker-checker flow; the original creator cannot approve their own row.
- The statutory readiness service independently rejects a compensation row without explicit approval evidence.

No existing production database was changed while preparing this package. Historical rows must be reconciled on a restored database before the installer is used on a live system.

## Schema, statutory and SOP boundaries

- Table-key counts are diagnostic inventory only; they do not approve an HR schema count or migration. Preserve the legacy HR tables and historical records. Do not DROP, TRUNCATE, RENAME or recreate tables to make a count match.
- The HRX extension remains recognized for preservation, not activated by this package.
- Historic pension constants in the source are not a substitute for qualified review of the exact current Stockland statutory rule set. Do not infer legal approval from a hard-coded value or version label.
- The 24 embedded Amharic SOP DOCX payloads passed byte/hash/ZIP integrity checks, but their manifest status remains `DRAFT_NOT_APPROVED`. They are not effective policies or approved contracts until the designated Stockland authorities review and approve them.
- The synthetic-only payroll test branch remains fail-closed in the inspected REST call path; complete proof that no runtime/public path can enable it, and moving all fixtures outside production runtime, remain acceptance work. Do not enable the synthetic flag or use its fixtures for live staff records.

## Verification boundary

This ZIP includes the operational application modules from the 16.2.13 base and the local corrections described above. Its matching local QA report lists exact checks and all gates not run. Local syntax, source-contract and isolated encryption/health-classifier tests are not substitutes for:

- authenticated WordPress installation/activation/update and REST tests;
- MySQL/MariaDB schema, idempotent upgrade, concurrency and rollback tests;
- role, maker-checker and branch/location positive/negative acceptance;
- POS, stock, warehouse, procurement, AP/AR, GL/PLEDGER and independent balance reconciliation;
- two real-rule payroll-period acceptance and qualified Ethiopian labour/tax/pension review;
- HR private-file key recovery, backup/restore, migration and access-control acceptance;
- browser, mobile, PWA, accessibility and print/export acceptance;
- verified backup restoration, rollback and Owner/Operations/HR/Finance/Legal approval of the exact final ZIP hash.

**Release disposition: local cumulative package built and static/isolated checks recorded; not certified as live production-ready.** Do not treat a successful local build as authorization to deploy or change live business data.

## Release documents

See `CHANGELOG.md` for the candidate change summary and `MIGRATION_GUIDE.md` for the breaking changes, staging migration, key management and rollback procedure.
