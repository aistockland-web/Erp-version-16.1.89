<?php
/**
 * Encrypted private HR resource storage.
 *
 * Files are stored outside the public web root as AES-256-GCM ciphertext. The
 * 32-byte encryption key is supplied only through wp-config.php as
 * STOCKLAND_PRIVATE_VAULT_KEY (64 hex characters or strict base64). It is never
 * stored in the ERP database or plugin files. Existing legacy plaintext files
 * are migrated atomically after their stored SHA-256 is verified on an authorized read;
 * operators may also run the guarded WP-CLI migration after a verified backup.
 *
 * @package Stockland_ERP
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_HR_Private_Vault {
	const MAX_BYTES = 10485760;
	const FORMAT_MAGIC = "STKHRV1\0";
	const NONCE_BYTES = 12;
	const TAG_BYTES = 16;

	private static function error( $code, $message, $status = 409 ) {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}

	/** Enforce owner-only filesystem permissions; fail closed when the host cannot. */
	private static function restrict_permissions( $path, $mode ) {
		if ( ! @chmod( $path, $mode ) ) {
			return false;
		}
		$actual = @fileperms( $path );
		return false !== $actual && 0 === ( $actual & 0077 ) && ( $actual & ( $mode & 0700 ) ) === ( $mode & 0700 );
	}

	private static function key_material() {
		if ( ! defined( 'STOCKLAND_PRIVATE_VAULT_KEY' ) || ! is_string( STOCKLAND_PRIVATE_VAULT_KEY ) || '' === trim( STOCKLAND_PRIVATE_VAULT_KEY ) ) {
			return self::error( 'hr_private_vault_key_missing', 'Encrypted HR document storage is disabled. Configure a private 32-byte STOCKLAND_PRIVATE_VAULT_KEY in wp-config.php before uploading or downloading employee documents.', 503 );
		}
		$value = trim( STOCKLAND_PRIVATE_VAULT_KEY );
		if ( preg_match( '/^[a-f0-9]{64}$/iD', $value ) ) {
			$key = hex2bin( $value );
		} else {
			if ( 0 === strpos( $value, 'base64:' ) ) {
				$value = substr( $value, 7 );
			}
			$key = base64_decode( $value, true );
		}
		if ( ! is_string( $key ) || 32 !== strlen( $key ) ) {
			return self::error( 'hr_private_vault_key_invalid', 'STOCKLAND_PRIVATE_VAULT_KEY must decode to exactly 32 bytes (64 hexadecimal characters or strict base64).', 503 );
		}
		if ( ! function_exists( 'openssl_encrypt' ) || ! function_exists( 'openssl_decrypt' ) || ! in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true ) ) {
			return self::error( 'hr_private_vault_crypto_unavailable', 'OpenSSL AES-256-GCM is unavailable; private HR document storage is disabled.', 503 );
		}
		return $key;
	}

	private static function aad( $reference, $extension ) {
		return 'stockland-hr-private-vault:v1:' . $reference . ':' . strtolower( $extension );
	}

	private static function encrypt_payload( $plain, $reference, $extension, $key ) {
		$nonce = random_bytes( self::NONCE_BYTES );
		$tag   = '';
		$ciphertext = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag, self::aad( $reference, $extension ), self::TAG_BYTES );
		if ( ! is_string( $ciphertext ) || self::TAG_BYTES !== strlen( $tag ) ) {
			return self::error( 'hr_private_encrypt_failed', 'The HR document could not be encrypted; no plaintext file was stored.', 500 );
		}
		return self::FORMAT_MAGIC . $nonce . $tag . $ciphertext;
	}

	private static function decrypt_payload( $payload, $reference, $extension, $key ) {
		$minimum = strlen( self::FORMAT_MAGIC ) + self::NONCE_BYTES + self::TAG_BYTES;
		if ( ! is_string( $payload ) || strlen( $payload ) < $minimum || 0 !== strpos( $payload, self::FORMAT_MAGIC ) ) {
			return self::error( 'hr_private_legacy_plaintext_migration_required', 'This HR document uses the legacy unencrypted vault format. Run the documented WP-CLI encryption migration before downloading it.', 409 );
		}
		$offset = strlen( self::FORMAT_MAGIC );
		$nonce = substr( $payload, $offset, self::NONCE_BYTES );
		$offset += self::NONCE_BYTES;
		$tag = substr( $payload, $offset, self::TAG_BYTES );
		$offset += self::TAG_BYTES;
		$ciphertext = substr( $payload, $offset );
		$plain = openssl_decrypt( $ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag, self::aad( $reference, $extension ) );
		if ( ! is_string( $plain ) ) {
			return self::error( 'hr_private_authentication_failed', 'The HR document could not be authenticated. The key may be incorrect or the ciphertext may have been altered.', 409 );
		}
		return $plain;
	}

	private static function root() {
		if ( ! defined( 'STOCKLAND_PRIVATE_VAULT_DIR' ) || ! is_string( STOCKLAND_PRIVATE_VAULT_DIR ) || '' === trim( STOCKLAND_PRIVATE_VAULT_DIR ) ) {
			return self::error( 'hr_private_vault_unconfigured', 'Private HR document storage is not configured. Define STOCKLAND_PRIVATE_VAULT_DIR outside the public web root before enabling uploads/downloads.', 503 );
		}
		$path = STOCKLAND_PRIVATE_VAULT_DIR;
		if ( ! str_starts_with( $path, DIRECTORY_SEPARATOR ) ) {
			return self::error( 'hr_private_vault_path_invalid', 'The private vault path must be absolute.', 503 );
		}
		if ( ! is_dir( $path ) && ! wp_mkdir_p( $path ) ) {
			return self::error( 'hr_private_vault_unavailable', 'The private vault directory could not be created.', 503 );
		}
		$real = realpath( $path );
		$web  = realpath( ABSPATH );
		$doc  = isset( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( (string) $_SERVER['DOCUMENT_ROOT'] ) : false;
		if ( false === $real || ( false !== $web && ( $real === $web || str_starts_with( $real . DIRECTORY_SEPARATOR, rtrim( $web, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) ) ) || ( false !== $doc && ( $real === $doc || str_starts_with( $real . DIRECTORY_SEPARATOR, rtrim( $doc, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) ) ) ) {
			return self::error( 'hr_private_vault_public_path', 'The configured HR vault is within the public web root. Private documents are disabled until the vault is moved outside it.', 503 );
		}
		if ( ! self::restrict_permissions( $real, 0700 ) ) {
			return self::error( 'hr_private_vault_permissions', 'The private HR vault directory must have owner-only 0700 permissions; private document storage is disabled.', 503 );
		}
		if ( ! is_writable( $real ) ) {
			return self::error( 'hr_private_vault_not_writable', 'The private HR vault is not writable.', 503 );
		}
		return $real;
	}

	private static function allowed_types() {
		return array(
			'pdf' => array( 'application/pdf' ),
			'docx' => array( 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip' ),
			'xlsx' => array( 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip' ),
			'txt' => array( 'text/plain' ),
			'png' => array( 'image/png' ),
			'jpg' => array( 'image/jpeg' ),
			'jpeg' => array( 'image/jpeg' ),
		);
	}

	private static function locate( $reference ) {
		$root = self::root();
		if ( is_wp_error( $root ) ) { return $root; }
		$matches = glob( $root . DIRECTORY_SEPARATOR . '*' . DIRECTORY_SEPARATOR . '*' . DIRECTORY_SEPARATOR . $reference . '.*', GLOB_NOSORT );
		if ( ! is_array( $matches ) || 1 !== count( $matches ) ) {
			return self::error( 'hr_private_file_missing', 'The private resource could not be found.', 404 );
		}
		$path = realpath( $matches[0] );
		if ( false === $path || ! is_file( $path ) || ! is_readable( $path ) || ! str_starts_with( $path, rtrim( $root, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) ) {
			return self::error( 'hr_private_file_unavailable', 'The private resource is not safely readable.', 404 );
		}
		return $path;
	}

	public static function store_upload( $file ) {
		if ( ! is_array( $file ) || ! isset( $file['error'], $file['tmp_name'], $file['name'], $file['size'] ) || UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return self::error( 'hr_upload_invalid', 'Select one valid file. The upload did not complete successfully.', 400 );
		}
		$size = (int) $file['size'];
		if ( $size < 1 || $size > self::MAX_BYTES || ! is_uploaded_file( $file['tmp_name'] ) || ! is_readable( $file['tmp_name'] ) ) {
			return self::error( 'hr_upload_size_or_source_invalid', 'The file is empty, exceeds the 10 MiB limit, or is not a valid HTTP upload.', 400 );
		}
		$original = sanitize_file_name( (string) $file['name'] );
		$ext = strtolower( pathinfo( $original, PATHINFO_EXTENSION ) );
		$types = self::allowed_types();
		if ( ! isset( $types[ $ext ] ) ) {
			return self::error( 'hr_upload_type_blocked', 'Allowed private HR resource types: PDF, DOCX, XLSX, TXT, PNG, JPG/JPEG. Legacy .doc files are not accepted as DOCX.', 415 );
		}
		if ( ! class_exists( 'finfo' ) ) {
			return self::error( 'hr_upload_mime_verification_unavailable', 'Server MIME verification is unavailable; uploads are disabled.', 503 );
		}
		$finfo = new finfo( FILEINFO_MIME_TYPE );
		$mime = (string) $finfo->file( $file['tmp_name'] );
		if ( ! in_array( $mime, $types[ $ext ], true ) ) {
			return self::error( 'hr_upload_mime_mismatch', 'The uploaded content does not match its file type.', 415 );
		}
		$key = self::key_material();
		if ( is_wp_error( $key ) ) { return $key; }
		$plain = file_get_contents( $file['tmp_name'] );
		if ( ! is_string( $plain ) || strlen( $plain ) !== $size ) {
			return self::error( 'hr_upload_read_failed', 'The uploaded file could not be read completely.', 500 );
		}
		$reference = 'hrv_' . bin2hex( random_bytes( 24 ) );
		$encrypted = self::encrypt_payload( $plain, $reference, $ext, $key );
		if ( is_wp_error( $encrypted ) ) { return $encrypted; }
		$root = self::root();
		if ( is_wp_error( $root ) ) { return $root; }
		$sub = $root . DIRECTORY_SEPARATOR . gmdate( 'Y' ) . DIRECTORY_SEPARATOR . gmdate( 'm' );
		if ( ! is_dir( $sub ) && ! wp_mkdir_p( $sub ) ) {
			return self::error( 'hr_vault_subdir_failed', 'Could not prepare the private resource storage directory.', 503 );
		}
		if ( ! self::restrict_permissions( $sub, 0700 ) ) {
			return self::error( 'hr_vault_subdir_permissions', 'The private HR vault subdirectory must have owner-only 0700 permissions.', 503 );
		}
		$target = $sub . DIRECTORY_SEPARATOR . $reference . '.' . $ext;
		$written = file_put_contents( $target, $encrypted, LOCK_EX );
		if ( false === $written || $written !== strlen( $encrypted ) ) {
			@unlink( $target );
			return self::error( 'hr_private_store_failed', 'Could not store the encrypted file in the private HR vault.', 500 );
		}
		if ( ! self::restrict_permissions( $target, 0600 ) ) {
			@unlink( $target );
			return self::error( 'hr_private_file_permissions', 'The encrypted HR document could not be restricted to owner-only 0600 permissions.', 500 );
		}
		return array(
			'private_file_ref' => $reference,
			'file_sha256' => hash( 'sha256', $plain ),
			'file_name' => $original,
			'mime_type' => $mime,
			'size_bytes' => strlen( $plain ),
			'stored_at' => gmdate( 'c' ),
			'encryption_version' => 'AES-256-GCM-v1',
		);
	}

	public static function resolve( $reference, $expected_hash = '' ) {
		if ( ! is_string( $reference ) || ! preg_match( '/^hrv_[a-f0-9]{48}$/D', $reference ) ) {
			return self::error( 'hr_private_ref_invalid', 'The private resource reference is invalid.', 404 );
		}
		if ( ! is_string( $expected_hash ) || ! preg_match( '/^[a-f0-9]{64}$/iD', $expected_hash ) ) {
			return self::error( 'hr_private_expected_hash_missing', 'The approved document SHA-256 is missing or invalid.', 409 );
		}
		$key = self::key_material();
		if ( is_wp_error( $key ) ) { return $key; }
		$path = self::locate( $reference );
		if ( is_wp_error( $path ) ) { return $path; }
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$mime_map = array( 'pdf'=>'application/pdf', 'docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'txt'=>'text/plain; charset=UTF-8', 'png'=>'image/png', 'jpg'=>'image/jpeg', 'jpeg'=>'image/jpeg' );
		if ( ! isset( $mime_map[ $ext ] ) ) { return self::error( 'hr_private_mime_blocked', 'Stored resource MIME type is not permitted.', 415 ); }
		$payload = file_get_contents( $path );
		if ( ! is_string( $payload ) ) { return self::error( 'hr_private_file_unavailable', 'The encrypted private resource could not be read.', 404 ); }
		// Authorized readers may trigger a one-file, hash-checked, atomic legacy
		// migration. No database rows or approval states are changed by this step.
		if ( 0 !== strpos( $payload, self::FORMAT_MAGIC ) ) {
			$migrated = self::migrate_legacy_file( $reference, $expected_hash );
			if ( is_wp_error( $migrated ) ) { return $migrated; }
			$payload = file_get_contents( $path );
			if ( ! is_string( $payload ) || 0 !== strpos( $payload, self::FORMAT_MAGIC ) ) {
				return self::error( 'hr_private_migration_verification_failed', 'Legacy document migration could not be verified; download was blocked.', 500 );
			}
		}
		$plain = self::decrypt_payload( $payload, $reference, $ext, $key );
		if ( is_wp_error( $plain ) ) { return $plain; }
		$hash = hash( 'sha256', $plain );
		if ( ! hash_equals( strtolower( $expected_hash ), strtolower( $hash ) ) ) {
			return self::error( 'hr_private_integrity_failed', 'The decrypted private resource does not match its approved SHA-256.', 409 );
		}
		$temp = tempnam( sys_get_temp_dir(), 'stockland-hr-' );
		if ( false === $temp ) { return self::error( 'hr_private_temp_unavailable', 'A private temporary download file could not be created.', 503 ); }
		if ( ! self::restrict_permissions( $temp, 0600 ) ) {
			@unlink( $temp );
			return self::error( 'hr_private_temp_permissions', 'The temporary HR download could not be restricted to owner-only 0600 permissions.', 503 );
		}
		$written = file_put_contents( $temp, $plain, LOCK_EX );
		if ( false === $written || $written !== strlen( $plain ) ) {
			@unlink( $temp );
			return self::error( 'hr_private_temp_write_failed', 'The authenticated document could not be prepared for download.', 500 );
		}
		register_shutdown_function( static function () use ( $temp ) {
			if ( is_file( $temp ) ) { @unlink( $temp ); }
		} );
		return array( 'path'=>$temp, 'sha256'=>$hash, 'mime_type'=>$mime_map[ $ext ], 'size_bytes'=>strlen( $plain ), 'encrypted_at_rest'=>true );
	}

	public static function delete( $reference ) {
		if ( ! is_string( $reference ) || ! preg_match( '/^hrv_[a-f0-9]{48}$/D', $reference ) ) {
			return self::error( 'hr_private_ref_invalid', 'The private resource reference is invalid.', 404 );
		}
		$path = self::locate( $reference );
		if ( is_wp_error( $path ) ) { return $path; }
		return @unlink( $path );
	}

	/**
	 * Explicitly encrypt one legacy plaintext attachment in place after hash check.
	 * Run only from WP-CLI after taking an encrypted, restorable vault backup.
	 */
	public static function migrate_legacy_file( $reference, $expected_hash ) {
		if ( ! is_string( $reference ) || ! preg_match( '/^hrv_[a-f0-9]{48}$/D', $reference ) || ! is_string( $expected_hash ) || ! preg_match( '/^[a-f0-9]{64}$/iD', $expected_hash ) ) {
			return self::error( 'hr_private_migration_args_invalid', 'A valid private file reference and plaintext SHA-256 are required.', 400 );
		}
		$key = self::key_material();
		if ( is_wp_error( $key ) ) { return $key; }
		$path = self::locate( $reference );
		if ( is_wp_error( $path ) ) { return $path; }
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$plain = file_get_contents( $path );
		if ( ! is_string( $plain ) ) { return self::error( 'hr_private_migration_read_failed', 'Legacy document could not be read.', 500 ); }
		if ( 0 === strpos( $plain, self::FORMAT_MAGIC ) ) { return array( 'status'=>'ALREADY_ENCRYPTED', 'reference'=>$reference ); }
		if ( ! hash_equals( strtolower( $expected_hash ), hash( 'sha256', $plain ) ) ) {
			return self::error( 'hr_private_migration_hash_mismatch', 'Legacy plaintext SHA-256 does not match the approved database hash; no file was changed.', 409 );
		}
		$encrypted = self::encrypt_payload( $plain, $reference, $ext, $key );
		if ( is_wp_error( $encrypted ) ) { return $encrypted; }
		$temp = $path . '.encrypt-' . bin2hex( random_bytes( 8 ) );
		$written = file_put_contents( $temp, $encrypted, LOCK_EX );
		if ( false === $written || $written !== strlen( $encrypted ) ) { @unlink( $temp ); return self::error( 'hr_private_migration_write_failed', 'Encrypted migration file could not be written; legacy file remains untouched.', 500 ); }
		if ( ! self::restrict_permissions( $temp, 0600 ) ) {
			@unlink( $temp );
			return self::error( 'hr_private_migration_permissions', 'The encrypted migration file could not be restricted to owner-only 0600 permissions; the legacy document remains untouched.', 503 );
		}
		if ( ! rename( $temp, $path ) ) { @unlink( $temp ); return self::error( 'hr_private_migration_replace_failed', 'Atomic replacement failed; legacy file remains available for a controlled retry.', 500 ); }
		if ( ! self::restrict_permissions( $path, 0600 ) ) {
			return self::error( 'hr_private_migration_final_permissions', 'The encrypted file was replaced but final permissions could not be verified; block access and restore from the protected backup.', 500 );
		}
		return array( 'status'=>'ENCRYPTED', 'reference'=>$reference, 'sha256'=>$expected_hash, 'encryption'=>'AES-256-GCM-v1' );
	}

	public static function cli_encrypt_legacy( $args, $assoc_args ) {
		if ( ! class_exists( 'WP_CLI' ) || count( $args ) !== 2 ) {
			WP_CLI::error( 'Usage: wp stockland hr-vault-encrypt <private_file_ref> <plaintext_sha256>' );
		}
		WP_CLI::confirm( 'This encrypts one verified legacy private HR document in place. Confirm you have an encrypted vault backup and recoverable key.' );
		$result = self::migrate_legacy_file( $args[0], $args[1] );
		if ( is_wp_error( $result ) ) { WP_CLI::error( $result->get_error_message() ); }
		WP_CLI::success( 'Vault migration status: ' . $result['status'] . ' (' . $result['reference'] . ').' );
	}
}

if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' ) ) {
	WP_CLI::add_command( 'stockland hr-vault-encrypt', array( 'Stockland_HR_Private_Vault', 'cli_encrypt_legacy' ) );
}
