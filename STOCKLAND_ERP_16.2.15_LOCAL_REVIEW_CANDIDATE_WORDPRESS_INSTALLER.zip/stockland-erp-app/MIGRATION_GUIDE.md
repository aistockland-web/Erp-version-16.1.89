# Stockland Ethiopia ERP 16.2.15 — Breaking Changes & Migration Guide

**Package status:** local cumulative review candidate. **Not approved for live production deployment.**

## 1. Source selection and compatibility

This package retains the exact 16.2.13 operational installer as its base and applies the recovered 16.2.14 source corrections plus the separate stock-balance DDL correction. It does not replace the newer operational source with the older 16.1.95 reference, and it does not wholesale overlay the 16.2.9 or 16.3.0 HRX packages.

The following public/internal contracts are intentionally unchanged:

- WordPress plugin identity: `stockland-inventory.php` / Stockland Ethiopia ERP.
- REST namespace: `stockland/v16`.
- Existing core, accounting, HR and database schema-version constants.
- Existing Stockland branch/warehouse and operational module source files.
- Existing historical sales, stock movement, payroll, ledger and audit data. This candidate does not seed synthetic production rows or authorize destructive migrations.

The plugin package is intended to update the existing Stockland ERP plugin in place. Do not install a second copy beside it.

## 2. Changes requiring operator action

### 2.1 Compensation approvals — important behavior change

The migration-added and fresh-install default for `employee_compensation.approval_status` is now `DRAFT`. Payroll selection requires all of the following: `approval_status='APPROVED'`, a positive `approved_by`, and a valid `approved_at` timestamp. The compensation approver must be different from the preparer.

Existing rows with an `APPROVED` label but no auditable approver identity/time are not implicitly approved for payroll or hire activation. An authorized independent Owner must re-review them through the application’s maker-checker workflow. Do not bulk-update historical rows to `APPROVED`, and do not create an approver identity or timestamp to bypass review.

### 2.2 Private HR attachments — configuration required

HR private-file upload/download is disabled until the host supplies both constants in `wp-config.php` (or an equivalent protected runtime configuration):

- `STOCKLAND_PRIVATE_VAULT_DIR`: absolute directory outside `ABSPATH` and the web document root.
- `STOCKLAND_PRIVATE_VAULT_KEY`: 32 random bytes, represented as 64 hexadecimal characters or strict base64.

Example key generation on a trusted host:

```bash
openssl rand -base64 32
```

Example configuration (replace the sample values with host-specific values; never commit the key):

```php
define( 'STOCKLAND_PRIVATE_VAULT_DIR', '/absolute/private/path/stockland-hr-vault' );
define( 'STOCKLAND_PRIVATE_VAULT_KEY', 'PUT_THE_32_BYTE_BASE64_KEY_HERE' );
```

The vault root/month directories must be owner-only `0700`; encrypted files and download temporary files must be owner-only `0600`. The candidate fails closed if those permissions cannot be enforced. Configure and test this only in isolated staging first.

Legacy plaintext attachment migration is one file at a time and requires a stored SHA-256 match. A verified encrypted vault backup and a separately protected recoverable key are prerequisites. The guarded WP-CLI command is:

```bash
wp stockland hr-vault-encrypt <private_file_ref> <plaintext_sha256>
```

**Key rotation is not implemented in this candidate. Do not replace the active key.** A versioned keyring, migration/rollback process and restore test are required before any rotation is attempted. Losing the key makes encrypted attachments unrecoverable.

### 2.3 Stock balances — fresh-install DDL correction

Fresh-install `stock_balances.variant_id` is now `BIGINT UNSIGNED NOT NULL`, consistent with its `(location_id, variant_id)` primary key. The existing guarded migration for older SKU-keyed installations remains in the codebase. Do not manually alter the live table or force the migration before staging tests. Existing unresolved variant rows must be reconciled from Product Master; the migration is designed to stop rather than guess when no matching variant exists.

### 2.4 Health and HR interface

The Health screen can show a targeted review state for payroll compensation classification, schema-contract approval and final release approval without presenting unrelated authorized operational modules as globally disabled. Genuine integrity and database failures must still remain blocking. HR lifecycle card artwork is replaced with accessible labels; the global shell/chart interface remains.

## 3. Required staging migration procedure

1. Preserve the current production plugin ZIP, database backup and `wp-content` backup. Restore those backups to a separate test site and verify the restore before testing this candidate.
2. Confirm the test host meets the target: WordPress 6.8+, PHP 8.3+, OpenSSL/Fileinfo, and run both MySQL 8.0 and MariaDB 10.11 acceptance where possible. Use HTTPS and do not expose the database port publicly.
3. Install/update this single plugin on the restored staging copy. Never reset the database, install a parallel copy or run `uninstall.php` as a migration tool.
4. Capture before/after table, column, primary-key, unique-key, foreign-key and index inventories. Confirm the actual Stockland schema, the 4 legacy HR/payroll tables, and all historical rows are preserved. Check repeated activation/upgrade for idempotency.
5. Verify `stock_balances` migration on a database clone containing representative variants, reservations and legacy rows. Confirm unresolved Product Master variants stop safely and no ledger or historical sale/transfer/count/return rows are rewritten.
6. Verify that new compensation remains `DRAFT`, creator self-approval is denied, an independent Owner can approve, and payroll excludes any record without explicit approval evidence. Reconcile the historical exception queue manually.
7. Configure the private HR vault in staging. Test new file storage, unauthorized/authorized retrieval, integrity mismatch, legacy hash-gated migration, owner-only file modes, encrypted backup/restore and key recovery. Do not upload real sensitive employee records until access and legal/privacy approval is complete.
8. Execute all role/location allow/deny tests and complete POS, inventory, receiving, reservation, requisition, transfer, returns, damage, count, wholesale, procurement, AP/AR, cash/bank, GL/PLEDGER, daily close and report reconciliation. Verify quantities and ETB balances independently.
9. Complete at least two payroll periods with effective-dated rule bundles that have qualified Ethiopian legal/payroll review. Test payout, remittance, settlement and reversal controls. Never infer current statutory values from historical constants.
10. Test PWA/browser/mobile/accessibility/printing, performance, backup restore and rollback. Obtain Owner, Operations, Warehouse, Finance, HR and Legal sign-off on the exact final package SHA-256.

## 4. Rollback

Rollback must use the preserved plugin ZIP **and** a verified database/vault restore plan. Reverting PHP files alone may not undo database DDL or restore legacy HR attachment bytes. Retain staging snapshots until the restore/rollback sequence has passed. Do not delete backup or timestamped migration tables until the applicable migration and business reconciliation are explicitly accepted.

## 5. Acceptance boundary

This package has source/static checks and isolated private-vault tests only. WordPress activation, MySQL/MariaDB migration, authenticated workflows, data reconciliation, full security/dependency scans, statutory review, backup/restore/rollback and stakeholder approvals remain open. A successful upload or plugin activation must not be interpreted as production approval.
