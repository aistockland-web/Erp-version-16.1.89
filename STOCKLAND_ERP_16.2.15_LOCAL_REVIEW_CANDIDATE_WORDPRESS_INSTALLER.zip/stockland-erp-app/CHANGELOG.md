# Changelog — Stockland Ethiopia ERP 16.2.15

## 16.2.15 — local cumulative review candidate

This candidate is built from the exact 16.2.13 operational WordPress installer and applies the recovered, selectively reviewed 16.2.14 source corrections plus the separate stock-balance DDL correction. It is a **local review candidate, not a production-certified release**.

### Included corrections

- Compensation approval migrations default new approval state to `DRAFT`; payroll selection and hire activation require explicit approval identity and timestamp. Maker-checker controls prevent the record preparer from approving their own record. Legacy approvals without auditable approval evidence require independent re-review.
- Private HR attachments are stored using AES-256-GCM authenticated encryption. The 32-byte key and off-webroot vault path must be configured outside the plugin. Legacy plaintext migration is hash-gated and one file at a time. Vault root/month directories and files enforce owner-only `0700`/`0600` permissions and fail closed if the host cannot apply them; key rotation is not implemented.
- Health UI presentation separates review-only payroll/schema/release states from true global integrity failures. It does not convert an unverified system into a healthy system.
- HR lifecycle card icon artwork is replaced with accessible labels while global ERP shell/chart iconography remains.
- Fresh-install `stock_balances.variant_id` is non-null to match the `(location_id, variant_id)` primary key. The existing guarded upgrade/reconciliation path remains and requires MySQL/MariaDB acceptance before production.
- Release metadata is added and reissued for 16.2.15. The 24 SOP payloads remain intact and `DRAFT_NOT_APPROVED`.

### Preserved

- All 113 files from the supplied 16.2.13 package; no baseline paths were deleted.
- Existing POS, product, warehouse, branch, wholesale, procurement, accounting, ledger, HR lifecycle and PWA source modules.
- Existing core/accounting/database schema version markers and REST namespace.
- Legacy HR/payroll tables and historical business records; no data reset or destructive migration is authorized.

### Acceptance still required

WordPress activation/update/REST workflow tests, MySQL 8 and MariaDB 10.11 fresh-install and upgrade tests, database/index/foreign-key reconciliation, end-to-end POS/inventory/warehouse/procurement/finance workflows, role/location access tests, payroll/statutory review by qualified Ethiopian advisers, private-vault key/backup/restore testing, PHPCS/WPCS/SAST/SCA/secret/license scans, SBOM, browser/PWA testing, backup/restore/rollback rehearsal, SOP approvals and Owner/Operations/HR/Finance/Legal sign-off are not represented as passed by this package build.
