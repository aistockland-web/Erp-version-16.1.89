# Start instruction — Stockland ERP

I am attaching two files:

1. `STOCKLAND_ERP_CODESPACES_AGENT_MASTER_HANDOVER_2026-11-05.md` — the full owner directive, project history, version map, business requirements, architecture invariants, missing inputs and acceptance gates.
2. `STOCKLAND_ERP_CODESPACES_SOURCE_ARCHAEOLOGY_INPUTS_2026-11-05.zip` — recovered historical source/audit ZIPs plus the exact 16.1.95, 16.2.9 and 16.3.0 GitHub Actions artifacts/installers, receipts and SHA inventory.

Treat the master handover as the controlling task. First read the PR #55 engineering directives, then inventory the entire repository history: all branches, tags, commits, PRs and both ERP version lines. Verify every supplied package by checksum and compare source at file and functional level. Do not begin application-code edits, destructive refactoring or schema activation until you publish the full source archaeology/reconciliation report and recommend the correct canonical base.

Do not assume 16.1.95 is the currently installed system: the last reported installed release is 16.2.13, and its exact ZIP is still required. Do not treat 16.2.9, 16.3.0, 16.3.1 or 16.1.101 as cumulative just because their version numbers are higher. PR #48 and PR #49 are closed/unmerged inputs, not production releases. Preserve the useful changes from both lines—especially POS/cart, CSS modules, HR/payroll, migration fixes and SOP assets—after testing them against the chosen baseline.

After the archaeology gate, implement each coherent workstream in an incremental GitHub commit, run exact-head CI and cumulative regressions, fix and rerun every failure, and keep source/build/test evidence attached to the PR. Test clean install and supported upgrades only in isolated WordPress/MariaDB environments. Preserve immutable ledger history, authorization/location scope, transactional posting, idempotency, rollback, the approved schema contract and actual owner data. Do not test on or write to live production data.

Deliver one cumulative WordPress installer built from the exact commit that passed all gates, with one plugin root, matching release markers, build receipt, source/installer hashes, full test/security evidence and a rehearsed backup/restore/rollback plan. “CI green” alone is not production acceptance. Do not deploy to live or claim production-ready until business-role E2E tests, actual SOP/resource validation, payroll legal review, management acceptance and the owner's explicit release approval are recorded.

Start now with source archaeology and a written evidence report. Do not ask me to restate the business context already in the master handover. Ask only for the missing exact 16.2.13 installed package and any actual SOP/16.3.1 files that cannot be recovered from the repository or Library.
