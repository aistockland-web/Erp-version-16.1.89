# STOCKLAND ETHIOPIA ERP — MASTER HANDOVER AND EXECUTION DIRECTIVE FOR THE CODESPACES AGENT

**Owner instruction date:** 5 November 2026  
**Repository:** `aistockland-web/Erp-version-16.1.89`  
**Goal:** reconcile the complete three-month engineering history across both ERP version lines, preserve every useful implementation, finish the real end-to-end ERP, prove it through exact-head CI and isolated WordPress/MariaDB testing, and produce one traceable WordPress installer that is genuinely eligible for production approval.  
**Important:** this document is an execution order and evidence map. It is not a claim that the ERP is currently production-ready, that any candidate is cumulative, or that a live deployment has happened.

---

## 1. Owner's non-negotiable direction

The owner wants the work already completed across approximately three months, across more than twenty releases and two related plugin/version series, to be reconciled and preserved before the team chooses a final foundation. Do not treat the newest version number as automatically correct. Do not discard an older package merely because a newer package exists. Do not assume that a CI-passing component from one line can be copied over another line without source and data-contract analysis.

The expected result is **one coherent, cumulative Stockland ERP**, not a collection of disconnected add-ons, demo ZIPs, parallel “final” plugins, or another stream of arbitrary version numbers.

The owner wants the engineering agent to:

1. Complete repository, branch, tag, PR, Library-package and owner-supplied-package archaeology before making application-code changes.
2. Identify the real operational baseline, including the exact package currently installed on the owner's site. The last reported installed version was **16.2.13**, but its exact package and SHA-256 have not yet been recovered in this handover.
3. Compare both version lines and all useful work at file and feature level. Preserve better implementations from either line after proving compatibility.
4. Carry out implementation in small, coherent targets. Commit each completed target to the working branch, run the target tests and cumulative regression on that exact commit, fix findings in follow-up commits, and rerun.
5. Keep all work in GitHub with readable commits, manifests, receipts, tests and review evidence. Do not make the owner reconstruct technical history manually.
6. Produce one canonical final ZIP from the exact commit that passed CI and staging acceptance. The package, receipt, source commit and SHA-256 must agree.
7. Prepare the live-update package and a truthful go/no-go report. **Do not write to the live WordPress database or deploy to production without a verified backup, completed acceptance gates and the owner's explicit release approval.**

The owner should only need to paste this directive into the Codespaces agent and upload the actual locally installed package / missing resource files when requested by the evidence intake checklist below.

## 2. GitHub control points — read these first

### Repository and protected baseline

- Repository: https://github.com/aistockland-web/Erp-version-16.1.89
- `main` base SHA recorded for the current work: `a46214f6bd5e21a9948d5c896d2136d722d36f16`
- Do not reset, force-push, overwrite or directly promote changes to `main` as a shortcut.

### Current owner-directive branch and PR

- Branch: `owner/incremental-target-commits-production-2026-11-05`
- Current head: `8dbf8c767cba7f90d5e89e60d75348364dc596d4`
- PR #55: https://github.com/aistockland-web/Erp-version-16.1.89/pull/55
- Incremental target-commit directive commit: `04dae2368952e1420cb8b7995e0f9e71cf70ec7a`
- Source archaeology directive commit: `8dbf8c767cba7f90d5e89e60d75348364dc596d4`

Read both committed documents before implementing:

1. `docs/engineering/STOCKLAND_ERP_INCREMENTAL_TARGET_COMMITS_AND_PRODUCTION_COMPLETION_2026-11-05.md`  
   https://github.com/aistockland-web/Erp-version-16.1.89/blob/owner/incremental-target-commits-production-2026-11-05/docs/engineering/STOCKLAND_ERP_INCREMENTAL_TARGET_COMMITS_AND_PRODUCTION_COMPLETION_2026-11-05.md
2. `docs/engineering/STOCKLAND_ERP_PREIMPLEMENTATION_VERSION_ARCHAEOLOGY_AND_SOURCE_RECONCILIATION_2026-11-05.md`  
   https://github.com/aistockland-web/Erp-version-16.1.89/blob/owner/incremental-target-commits-production-2026-11-05/docs/engineering/STOCKLAND_ERP_PREIMPLEMENTATION_VERSION_ARCHAEOLOGY_AND_SOURCE_RECONCILIATION_2026-11-05.md

Other controlling project documents:

- Cross-platform engineering directive (4 Nov): https://github.com/aistockland-web/Erp-version-16.1.89/blob/63e1b29477bbde60ddbdec8615822b39308bebaa/docs/engineering/STOCKLAND_ERP_CROSS_PLATFORM_PROJECT_WORK_DIRECTIVE_2026-11-04.md
- Release restriction / readiness corrective action plan: https://github.com/aistockland-web/Erp-version-16.1.89/blob/55e24b735417d3455bf7a591a5344c4ea05354e0/audit/STOCKLAND_ERP_RELEASE_RESTRICTION_CORRECTIVE_ACTION_PLAN_2026-11-04.md
- Local consolidation audit (4 Nov): https://github.com/aistockland-web/Erp-version-16.1.89/blob/audit/local-consolidation-closure-2026-11-04/audit/STOCKLAND_ERP_LOCAL_CONSOLIDATION_AUDIT_2026-11-04.md

Notion controlling pages recorded by the owner/project history:

- 16.1.95 Protected Master — HR/Payroll Integration Decision — 4 Nov 2026: https://app.notion.com/p/40d6db0f767e8140b744d32a043269f9
- Final Production Release Decision — 3 Nov 2026: https://app.notion.com/p/40d6db0f767e81eb9ed1d7ddb6525d10
- 16.3.0 Consolidation Evidence: https://app.notion.com/p/40c6db0f767e8115b6e2fc0b437d4a0a
- Canonical Release Audit & Acceptance Gates: https://app.notion.com/p/3fc6db0f767e81f2a3bbe644048054f9

**PR status snapshot checked for this handover:**

- PR #39 (`Feature/hr payroll full cycle 16 2 0`) is merged. Merge commit `bd6c78f180e3bc6871317aa32c1f11d4fab8a427`; head `996addd06c635de7deb3738772b1bc3678435b22`.
- PR #48 (16.3.0 HRX integration candidate) is **closed, not merged**. Candidate head `55e24b735417d3455bf7a591a5344c4ea05354e0`; do not merge the whole branch as a ready cumulative release.
- PR #49 (16.1.101 staging / HRX DDL and SOP tab) is **closed, not merged**. Head `28b9308db879b5b298739170120338f139de7326`; retain its useful changes as inputs only.
- PR #55 is the current open owner directive PR. Its changes are documentation/governance, not ERP runtime implementation.

A prior search reviewed up to 100 recent repository commit-search results, but that did **not** prove complete history coverage. The Codespaces agent must inspect the full reachable history, tags, branches, release refs, and relevant PRs. Do not report “all history checked” until the inventory is exhaustive and reproducible.

## 3. Recovered source package bundle supplied with this note

The companion archive `STOCKLAND_ERP_CODESPACES_SOURCE_ARCHAEOLOGY_INPUTS_2026-11-05.zip` contains the Library ZIPs and exact Actions artifacts that were recoverable at handover time. It includes:

### Library files recovered

- `STOCKLAND_ERP_16.1.79_GITHUB_READY_SOURCE.zip`
- `STOCKLAND_ERP_16.1.80_SOURCE_AUDIT_BUNDLE.zip`
- `STOCKLAND_ERP_16.1.81_SOURCE_AUDIT_BUNDLE.zip`
- `STOCKLAND_ERP_16.1.82_SOURCE_AUDIT_BUNDLE.zip`
- `STOCKLAND_ERP_16.1.82_FINAL_CANONICAL_BOOTSTRAP_5.3.8.zip`
- `STOCKLAND_ERP_16.1.83_CANONICAL_WORDPRESS_UPDATE.zip`
- `STOCKLAND_ERP_16.1.84_CANONICAL_WORDPRESS_UPDATE.zip`
- 16.1.84–16.1.88 audit, QA and update-guide files
- 16.1.91 QA evidence and 16.1.93 build-receipt metadata

The old installer and source archives are historical comparison material. They are **not** instructions to install an old package over the current ERP.

### CI artifacts recovered directly from GitHub Actions

1. **16.1.95 protected baseline**
   - Outer Actions artifact: `STOCKLAND_ERP_16.1.95_CI_ARTIFACT.zip`
   - Workflow `40036018031`, artifact `12536703884`
   - Outer artifact SHA-256: `7c9ee6ce4b1969182b20315cb0d68974147100925d84146d87f5fd5ed1005834`
   - Inner installer: `STOCKLAND_ERP_16.1.95_CANONICAL_WORDPRESS_UPDATE.zip`
   - Inner installer SHA-256: `494e777247508d009dfdb216c9607bb1bc96717197e94a0e8ad3459b7cc81625`
   - 75 plugin files, one `stockland-erp-app/` root, ZIP CRC passed.
   - Receipt says the preserved schema contract is 49 tables (29 Core/Operations + 16 Accounting/Procurement + 4 HR/Payroll), no schema change and no live data mutation by the builder. The receipt also explicitly says owner-provided health information was not directly queried by the build process.

2. **16.2.9 HR/payroll candidate**
   - Outer Actions artifact: `STOCKLAND_ERP_16.2.9_HR_PAYROLL_CANDIDATE_CI_ARTIFACT.zip`
   - Workflow `41146685514`, artifact `13020807863`
   - Outer artifact SHA-256: `f8271d150a4863edebab272ccfa03589519eb0ee1dd7dcaec17afc8634598553`
   - Inner candidate SHA-256: `c9f6459c71087575d8554e599a1ed5025a9e21655f24886c933232ac194d9c01`
   - 88 runtime files; ZIP CRC passed.
   - The artifact receipt reports a candidate schema contract of **86 tables** (29 Core/Operations + 16 Accounting/Procurement + 41 HR/Payroll), 37 new tables, schema change not approved, `production_ready=false`, and production DB not touched. Its PHPCS report records 16,364 errors and 690 warnings. Its Semgrep JSON records no findings in that scan; that result does not cancel the PHPCS or architecture/schema findings.

3. **16.3.0 HRX integration candidate**
   - Outer Actions artifact: `STOCKLAND_ERP_16.3.0_HRX_CANDIDATE_CI_ARTIFACT.zip`
   - Workflow `41733684055`, artifact `13276687926`
   - Outer artifact SHA-256: `215bd114c96ce21c3e9fc521172878a7a19c4fdb34b5a7cc842ff179c9927953`
   - Inner candidate: `STOCKLAND_ERP_16.3.0_HRX_WORDPRESS_PLUGIN.zip`
   - Inner candidate SHA-256: `f48993499e7664c45a079595af8efedbd5881728952cf019428f5db2d1872412`
   - 76 plugin files; ZIP CRC passed.
   - Receipt classifies it as `INTEGRATION_CANDIDATE`, based on 16.1.95, with `cumulative_core_update=false`, `production_ready=false`, 47 proposed HRX tables, schema changes present and legacy HR runtime disabled. It explicitly lists isolated full lifecycle E2E, current Ethiopian legal/tax/pension review, role/private-document acceptance, backup/restore/rollback, Owner/HR/Finance sign-off and source-parity/cutover as pending.

All three CI artifacts include source-side receipt material. Re-run every required gate on the exact final integrated source; historical artifact results do not certify a later commit.

## 4. Version-lineage and gap register — do not collapse these distinctions

| Version / line | Evidence and lineage known at handover | Required treatment |
|---|---|---|
| **16.1.95** | Protected operational baseline / rollback reference. Exact installer recovered and hash verified above. 49-table contract. | Preserve as a key comparison and rollback reference. Do not assume it is the currently installed package. |
| **16.1.98** | A separate side line, recorded as 79 files with source/package hash `1997b33326b45c7d0a32ba283dc7fb6ea8bd4a61d1392990944065add5c81f8b`. Not proven cumulative with 16.1.95. | Recover the exact source/package from Git refs or owner archive; compare separately. Do not describe it as .95 plus changes without proof. |
| **16.2.9** | Selected HR/payroll implementation from merged PR #39; merge commit `bd6c78f180e3bc6871317aa32c1f11d4fab8a427`; exact candidate artifact above. Candidate schema 86, 37 added tables, unapproved. | Preserve useful HR code and workflows as source material. Do not activate the proposed schema or replace live 49-table logic without an approved migration, data mapping, tests and Owner sign-off. |
| **16.2.10** | Library folder `/Stockland optimizatio/ERP 16.2.10 source` was checked and is empty. | Treat as missing evidence. Search repository history and ask owner for exact package only if a real local copy exists. Do not invent or reconstruct a package based on its version number. |
| **16.2.13** | Owner's most recent reported installed version. Exact installed ZIP/source SHA has not been obtained in this handover. | This is a critical owner intake. Request the exact currently installed plugin ZIP or a securely obtained source export. Hash it before inspecting/extracting it. Never replace the live package until its source and upgrade path are known. |
| **16.3.0** | HRX integration candidate based on 16.1.95, not on verified 16.1.98/16.2.13. Exact CI artifact recovered. PR #48 is closed/unmerged. `cumulative_core_update=false`. | Use as a comparison source for HRX and integration design only. Do not merge the whole branch or deploy its ZIP as the final ERP. Salvage code selectively after compatibility and behavior tests. |
| **16.3.1** | Local verification record: 85 files, 51 PHP files, 63 checks pass, 0 fail, 5 findings, `CONDITIONAL_PASS`; recorded ZIP hash `36b215da876f297a6d6948eda0b050e4d8b4d9d5ef2c7009e5b5120f3ca2faa5`. Earlier audit says the actual ZIP was unavailable for independent rehash and was not committed as a GitHub release. HRX remained disabled; restore/rollback, two-period payroll and Owner/HR/Finance acceptance remained open. | Do not claim package recovered. Search all refs/artifacts and request the exact local ZIP from owner if it still exists. Until then, treat this only as a verification report, not a source baseline or installable candidate. |
| **16.1.101** | PR #49 head `28b9308db879b5b298739170120338f139de7326`, closed/unmerged. Has a MariaDB `dbDelta` replay correction and a visible ERP SOP Library tab; its report describes a staging candidate derived from older 16.1.95/16.1.99 lineage, not the live 16.1.98 or 16.2.9 cumulative line. | Preserve the DDL correction and SOP navigation work as inputs. Rebase/transplant onto the reconciled canonical source and rerun all tests. Do not install its embedded ZIP as the final product. |

### Important 16.1.101 SOP resource correction

A 4 November tree audit recorded that PR #49 contains an acceptance register and installer archive but **no actual DOCX/PDF SOP documents or HR resource-pack ZIPs**. The three recovered installer archives checked in that audit also had zero DOCX and zero PDF files. The branch/QA record's claim of 24 downloads in a sandbox is not evidence that the actual 24 files ship in the installer. The owner previously stated that the SOPs already exist and include job descriptions, contracts and policy documents. Search the Library and ask the owner to supply the actual files. Hash each document, validate its format and content, classify its sensitivity, define role/location download authorization, and prove the authenticated download flow in the integrated application.

### Older Library history

The companion archive contains 16.1.79–16.1.84 packages/source bundles and 16.1.85–16.1.93 evidence. Use them to recover and compare useful product/catalog, Bootstrap 5.3.8 design, global search, responsive shell, wholesale surplus calculation, report explorer, inventory reconciliation, approvals, CSS modules, PWA cache markers and other incremental work. A QA note, checksum sidecar or release receipt is evidence only for its exact named source/package; it is not the binary itself.

## 5. Stockland business context and required operating model

The product is **one company: STOCKLAND ETHIOPIA**, with a central warehouse and four branches:

- `CENTRAL WAREHOUSE` — main inventory control and wholesale dispatch point
- `GORO BRANCH`
- `GERJI BRANCH`
- `MEXICO BRANCH`
- `MEGENAGNA BRANCH`

Central Warehouse is the inventory control origin. Management/Owner controls central allocation policy. Branch managers/users must have only their authorized location scope. Keep operational users in the front-end ERP/PWA; WordPress Administrator retains full platform-level WordPress access. Do not make routine operational staff dependent on the WP Dashboard or WP editor.

Business model: licensed export-surplus / export-quality apparel sourced from Ethiopian industrial parks and factories producing for foreign brands; retailer, distributor, wholesaler and reseller/influencer partner channels; women, men, children and newborn/baby segments; showroom plus warehouse and online sales. The ERP must support product/size/color/SKU variants, SKU-only legacy inventory records where valid, barcode fields when provided, retail and wholesale pricing, and stock at each location.

## 6. Complete functional scope — the end-to-end system, not a dashboard demo

### A. Command Center and identity/access

- Front-end-first ERP login and role-aware workspace.
- Owner, Management, Warehouse Manager, Branch Manager, Sales/POS, Finance/Accounting, HR/Payroll and other explicitly configured roles.
- Server-side role, capability, record ownership and location authorization on every REST/domain operation. A nonce alone is not authorization.
- Owner authority, maker-checker approval, and separation of duties for approval-sensitive operations.
- User management: create/edit/deactivate/reassign, branch/location scope, capability changes, protected Owner actions and audit trail.
- System Health, diagnostics, audit history and operational status. Never report a check as passing when it was not actually executed.

### B. Product Master and imports

- Product and brand master, category, department, gender/age group, unit, cost, retail price, wholesale price, reorder thresholds and active status.
- SKU-based variants with size and color. Preserve SKU-only legacy products/ledger records where the source history requires them.
- Excel import with dry run, schema/column mapping, SKU cross-reference, duplicate detection, validation errors and downloadable results. Do not manufacture barcodes when the owner wants them blank.
- Owner's existing product seed/workbook and 49-table operational contract are the starting evidence. Do not replace source workbook fields or reorder product sequence without authorization.

### C. Inventory / Central Warehouse / branches

- Central Warehouse and branch stock ledgers, on-hand, reserved, available, inbound, dispatched/in-transit, damaged and returned quantities.
- Purchase receiving / GRN; requisitions; reservations; transfers; branch receiving and variance; returns; damage; authorized adjustments; cycle counts and full physical counts.
- Central-to-branch request/approval/transfer/dispatch/receipt workflow. Avoid double deductions across reservations, picked/in-transit stock and dispatched inbound.
- If a request exceeds availability, show exact available/reserved quantities and a safe reserve/partial-fulfilment suggestion. Do not approve hidden negative stock.
- Physical count: branch/warehouse manager uploads an Excel file of actual brand/product/size/color/quantity found; validate and reconcile it into a proposed count; Management/Owner reviews variances; approved adjustments create ledger events. No direct destructive overwrite of inventory quantities.
- Central warehouse user management and per-location permissions are essential, not optional.

### D. POS, retail and wholesale

- Multi-line cart; SKU search/scan; size/color selection; quantities; line discount/authorized adjustments; totals; payment method; receipt/print; customer account and credit rules as authorized.
- Sale flow: authenticated UI -> REST -> policy validation -> transaction/locking/idempotency -> persisted sale -> inventory movement -> accounting journal/ledger -> immutable audit event -> UI displays success only after commit.
- Retail and wholesale pricing, bulk order, reseller/partner channel, and direct wholesale from Central Warehouse.
- Reservations and concurrency protection must prevent overselling. Test partial failures, duplicate submits, retries and simultaneous checkout/receiving.
- Returns/refunds must use compensating events and policy checks; never erase posted sale history.

### E. Procurement, vendors, finance and accounting

- Supplier/customer masters and balances, purchase requests/orders, approvals, receiving/GRN, supplier invoices, payments, AP, AR, expenses and cash/bank controls.
- PLEDGER, general ledger, journals, debit/credit balance, VAT/tax policy configuration, COGS, stock valuation, period close and reconciliation reports.
- PO -> receipt/GRN -> stock ledger -> supplier invoice/AP -> payment -> GL lifecycle. Test all quantity and ETB values against an independent expected result.
- Idempotency, row locks, transaction boundaries, approval separation and immutable posting history must be preserved.
- Do not make up tax, VAT or accounting rules. Confirm country/legal policy with the owner and qualified professional where necessary.

### F. HR, payroll, policies and resource library

- Employee records, employment lifecycle, job descriptions, contracts, attendance, schedules, leave, compensation components, payroll generation/review/approval, payslips, payout, remittance and offboarding.
- SOP / Policy center with download, view, edit/save workflows as designed, document versions, owners, effective dates and role access. The owner says the SOP material exists; actual files must be located and validated rather than replaced by an empty tab or acceptance register.
- Preserve legacy HR/payroll tables and historical posted/payroll data while designing any HRX migration. Do not silently change the system of record.
- Ethiopian pension/PAYE/labour/statutory rules, effective dates, exemption caps, overtime, leave and deductions must be reviewed against current official sources by qualified local payroll/tax professionals and accepted by Owner/HR/Finance. No guessed defaults and no seeding of synthetic statutory rates into production.
- Payroll needs at least two independent consecutive periods, repeat/replay checks, concurrent period tests, correct approval transitions, payout/remittance reconciliation and documented rollback/compensation paths.

### G. Reports and Management Intelligence

- Location-aware stock, sales, margin, wholesale, inventory valuation, reorder, purchase, receiving, transfer, variance, damage, returns, finance and HR reports.
- Dashboard alerts must use server-calculated sellable availability after reservations, not only raw physical stock.
- Report filters, date/time zone, export, print and worksheet-quality layout must agree with the data API. Preserve existing reports and aliases unless exact tests prove a correction.
- Any AI/management intelligence must be accurately described. The 16.1.95 receipt says the current behavior is deterministic/source-backed analytics and no external AI provider is configured. Do not claim connected cloud AI or send business data externally without an Owner-approved provider and data policy.

### H. UX, responsive frontend and PWA

- Keep a polished, consistent SaaS ERP design system with responsive desktop/tablet/mobile behavior; operational controls must stay usable at phone widths.
- Compare the best existing CSS/module designs, Bootstrap 5.3.8 integrations, global search toolbar, command palette, profile/menu handling, cart and POS, finance/HR screens and print styles from all version sources.
- Do not remove the POS/cart controller, CSS modules, report views, or HR/payroll style resources to make a smaller candidate. Fix style collisions at source and rebuild compiled CSS.
- Address known prior UI findings: duplicate Workspace/Command Center navigation, duplicate notifications, header/search hidden or overlaid by host theme, responsive cart, centered card text, mobile navigation and logo, HR/payroll icon CSS damage, and report/worksheet print layout.
- Maintain app CSS source-module ordering, deterministic build, minified parity, release/cache version alignment and service-worker/PWA cache invalidation. No stale service worker should keep an old bundle alive after release.
- Test desktop, tablet and mobile breakpoints, keyboard access, focus, labels, contrast, zoom and overflow.

## 7. Architecture, data integrity and security invariants

The complete critical path is:

**UI -> authenticated REST endpoint -> server authorization/location scope -> domain/service validation -> DB transaction and locks -> persisted business state -> inventory/accounting consequences -> immutable audit event -> response/UI confirmation.**

Mandatory rules:

1. Enforce authorization in backend controllers/services, not only by hiding buttons.
2. Validate actor, role, object state, company, location, approval policy, quantity, price and period on the server.
3. Use DB transactions, appropriate row-level locks (`FOR UPDATE` where applicable), unique/idempotency keys, duplicate protection and replay-safe operations.
4. Never display success before all required writes commit. On any partial failure, rollback or record an explicit compensating workflow.
5. Never delete/rewrite posted sales, inventory events, journals, payroll runs or audit history to “fix” totals. Use auditable reversals/compensating entries.
6. Migrations must be safe on clean install and repeated upgrade/re-activation. Validate `dbDelta` formatting, MariaDB/MySQL defaults/widths, foreign keys/indexes and version markers. Detect schema drift and stop rather than silently claim health.
7. Keep the 49-table operational contract unless an explicit, reviewed, owner-approved schema migration is designed and validated. The 16.2.9 candidate receipt proposes 86 total tables and the 16.3.0 candidate adds a separate 47-table HRX proposal; neither is an approved replacement for the existing contract. Map old/new tables, records, keys, status transitions, ownership and rollback before any migration.
8. Protect confidential employee documents, payroll values, supplier/customer information and credentials. No secret values in Git, artifacts, screenshots or CI logs. Gitleaks/secret scan must pass; private document access must be server-authorized and logged.
9. A hash is not encryption. If a vault stores sensitive source documents, implement and test actual encryption-at-rest, authorization and key handling; do not label a hash-integrity mechanism as encrypted storage.
10. All seed/demo/test data belongs only in isolated tests. Never write synthetic records into production.
11. No hardcoded deployment hostname/domain. Use the active WordPress site URL and trusted same-origin REST/PWA behavior.
12. Keep backwards-compatible APIs or document controlled deprecations with explicit migration and UI updates.

## 8. Source archaeology — required before feature implementation

Do not start code edits until the Source Archaeology and Reconciliation Report is completed and reviewed.

### Step 1 — preserve and enumerate all source refs

In Codespaces:

```bash
git status --short --branch
git remote -v
git fetch --all --tags --prune
git branch -a
git tag --list --sort=version:refname
git for-each-ref --format='%(refname) %(objectname) %(creatordate:iso8601) %(subject)' refs/heads refs/remotes refs/tags
git rev-list --all --count
git log --all --graph --decorate --date=iso --format='%H %ad %d %s'
```

Build a release-ref map and a commit-to-package map. Inspect both plugin series independently, every relevant branch and tag, PR #39, #48, #49, #55 and any release/CI candidate refs. Discover additional repository remotes or predecessor repositories from GitHub history rather than assuming this one is the only source.

### Step 2 — exact package intake

For every owner upload or retrieved artifact:

- Save the original read-only. Record exact filename, byte count, source, retrieval date, file ID / artifact ID / workflow run, commit/ref and SHA-256.
- Verify ZIP CRC, archive path safety, duplicate paths, root directory and file inventory before extraction.
- Never execute package scripts during intake. Extract into a fresh isolated directory only after safe-path validation.
- Record plugin header version, runtime version constant, release manifest, CSS module manifest, schema markers, migration list, tests/workflows and package build receipt.
- Distinguish outer Actions artifact SHA from the SHA of the inner WordPress installer. Record both.
- Do not “repair” the source ZIP during intake. Preserve the original, make a separate working copy and document all changes.

Suggested commands:

```bash
sha256sum INPUT.zip
unzip -t INPUT.zip
zipinfo -1 INPUT.zip
```

### Step 3 — compare sources at file and behavior level

Compare at least:

- plugin bootstrap/header, release manifests, DB/schema contract and activator/migrations;
- REST routes/controllers, authorization, roles, location scope, authority/approval services;
- inventory ledger, central warehouse, requisitions, reservation logic, transfers, receiving, returns, damage, physical counts and stock adjustment;
- POS sale/cart/checkout/payment/receipt, wholesale ordering and the controllers/services required by those screens;
- accounting, procurement, AP/AR, PLEDGER, journals, GL, COGS, reports and report query guards;
- legacy HR/payroll and HRX schemas/services/migrations/calculators/private vault/document storage;
- SOP files, policies, job descriptions and contract resources;
- CSS source modules, compiled CSS, JS, PWA/service worker, icons/logo and responsive shell;
- tests, CI workflows, scripts, composer/package manifests, dependencies, license and security scans.

Use both file hashes and semantic diffs. For each source/version, classify every capability as `present-and-tested`, `present-but-unverified`, `partial`, `missing`, `regressed`, `incompatible`, or `unknown`. Record which older source has the strongest implementation of each feature. Never infer “cumulative” from version number or changed-file count.

### Step 4 — owner-installed package and missing assets

The exact 16.2.13 installed package is a required input before any final upgrade decision. Ask the owner to upload that exact ZIP or a verified export. Hash it before extraction and compare it against both source series and the recovered artifacts.

Also request the actual 24 SOP/HR policy resources if they are stored separately from the plugin. The owner may additionally supply the latest 16.3.1 local package if it exists. Do not block the archaeological report from recording known gaps, but do not claim those packages/assets were recovered until they are actually present and verified.

### Required archaeology deliverable

Create `docs/audit/STOCKLAND_ERP_COMPLETE_SOURCE_ARCHAEOLOGY_AND_RECONCILIATION.md` with:

- a complete branch/tag/PR/version timeline;
- source/package/commit/artifact SHA map;
- per-version file inventory and schema/migration contract;
- per-feature capability matrix for both lines;
- list of fixes and best practices to preserve, with exact source refs;
- regressions and noncumulative conflicts (especially POS/cart, CSS modules, HR/HRX and DB/schema);
- missing artifacts/owner inputs;
- proposed canonical source baseline and explicit reasons;
- safe integration sequence, migration and rollback plan;
- findings ranked critical/high/medium/low with evidence links.

Do not proceed to destructive refactoring, branch rewrite or schema activation until this report identifies an approved baseline and the owner-installed package gap is resolved or formally accepted as a documented blocker.

## 9. Implementation sequence after archaeology

Create or continue a dedicated owner working branch from the approved base. Keep PRs reviewable and do not merge a whole historical candidate branch just because one component is good.

Suggested workstream order (adjust after archaeology evidence):

1. **Release/source baseline:** consolidate one canonical plugin tree; resolve version markers, manifest, asset build and package-root consistency. Preserve protected 49-table behavior initially.
2. **Security and authorization:** backend role/capability/location checks, owner authority, request validation, secrets, audit chain and private document access.
3. **Database/migrations:** clean install, repeat activation/dbDelta, upgrade from every recovered and supported prior baseline, schema contract checks, rollback and data-preservation proof.
4. **Inventory and warehouse:** receiving, central/branch stock, reservations, requisitions, transfers, physical count, returns, damages, adjustments and location scope.
5. **POS and wholesale:** restore and verify multi-line cart, sale lifecycle, payment/receipt, central direct wholesale, reservation/oversell protection and returns.
6. **Finance and procurement:** PO/GRN/AP/AR/payment/expenses/PLEDGER/GL/COGS/VAT and quantity/value reconciliation.
7. **HR/payroll and SOPs:** select legacy/HRX architecture only after schema and data mapping, preserve history, make statutory policy configurable and professionally reviewed, package real SOP files with policy-based access.
8. **Reports and Management Intelligence:** reconcile server data with cards, charts, filters, exports, print and location/date scope.
9. **Frontend/PWA:** merge the best design and responsive fixes without dropping modules or operational workflows; prove source-to-bundle parity and cache invalidation.
10. **Release engineering:** installer assembly, clean install/update paths, deterministic receipt, artifact inventory, SBOM/license/dependency scans, support and rollback notes.

Every target must result in an incremental commit, a focused test set, the full relevant cumulative regression, updated evidence and a visible status in the PR. Fix failures rather than weakening/removing checks to make CI green.

## 10. Required local and CI verification matrix

Run all tests against the exact candidate commit and again against the exact packaged installer. At minimum include:

### Static/build gates

- PHP syntax lint for every PHP file on supported target PHP versions (test PHP 8.3 and 8.4; confirm actual hosting runtime from the owner's current System Health rather than relying on old assumptions).
- WordPress Coding Standards / PHPCS with zero unapproved errors and warnings; document justified exclusions.
- JavaScript syntax, JSON manifest validity, CSS/PostCSS parsing, source CSS module deterministic rebuild, normalized AST parity of minified/unminified output, PWA manifest and service-worker version alignment.
- Semgrep, Gitleaks/secret scan, dependency vulnerability and license inventory.
- Release identity consistency across plugin header, runtime constant, API/cache markers, manifest, asset modules, PWA and installer filename.
- Installer integrity: exactly one `stockland-erp-app/` root, no duplicate paths, no development secrets, no QA/vendor/test artifacts unless explicitly intended, valid CRC and matching SHA-256/build receipt.

### WordPress/database lifecycle

- Isolated clean WordPress install and fresh database.
- Repeated activate/deactivate/reactivate and repeat `dbDelta`/schema setup on MariaDB; no spurious ALTER/replay drift or invalid defaults.
- At least MariaDB 10.11 and a compatible current MariaDB 11.x test; MySQL compatibility only if declared in product support.
- Test on the actual supported WordPress/PHP combinations, including current owner-reported production versions when independently confirmed.
- Upgrade paths from each supported, recovered version using sanitized database copies. In particular, test the actual installed 16.2.13 package once supplied. Do not test on the live production database.
- Exact 49-table schema contract or an explicitly approved new contract, with a complete table-by-table migration map and rollback proof.
- Repeated installation must not duplicate tables, migrations, users, default ledgers, SOP entries or data.

### End-to-end functional journeys

Use disposable, synthetic fixtures in isolated test DBs only. Test roles and location scope for Owner, Management, Warehouse, Branch, Sales/POS, Finance and HR/Payroll.

- Product create/edit/import -> SKU/size/color -> branch/central stock.
- PO creation -> independent approval -> receipt/GRN -> stock ledger -> invoice/AP -> payment/GL.
- Branch requisition -> reserve -> owner/management approval -> dispatch -> transfer/in-transit -> branch receipt -> variance and ledger reconciliation.
- Multi-line POS cart -> validation -> checkout/payment -> sale record -> stock movement -> journal -> printed receipt.
- Wholesale direct from Central Warehouse -> pricing/credit policy -> dispatch -> invoice/payment -> stock/GL reconciliation.
- Return/refund/damage/adjustment -> approval -> compensating stock/accounting event -> audit.
- Physical count upload -> data validation -> proposed variance -> management approval -> adjustment -> reports.
- Day close -> explicit valid business date -> unresolved transaction/ledger checks -> close report.
- HR onboarding/contract/job description -> attendance/leave/compensation -> two consecutive payroll periods -> review/approval -> payout/remittance -> payslip and ledger, with correct period totals and legal policy evidence.
- SOP/policy download under allowed and denied roles; tampered URL and cross-location access denied; download logged; actual document hashes match package manifest.
- Concurrency, duplicate requests, retry/idempotency, lock contention, partial writes, rollback and replay on sales, stock transfers, receiving, journals and payroll.

### Browser/UI acceptance

Run authenticated desktop/tablet/mobile browser checks at 320, 390, 768, 1024, 1280 and 1440 CSS px (plus any project-specific sizes). Assert no JS console errors, failed API requests, hidden critical controls, horizontal overflow, duplicated navigation or stale PWA bundles. Verify actual Owner and operational-role permissions in the browser, not only mock fetch tests.

### Operational evidence

- Full deep integrity scan completes and reports actionable results.
- Audit chain integrity and immutability checks pass.
- Reconciliation proves inventory quantity and accounting amounts from source transactions.
- Backup is created and restoration is demonstrated in isolated staging.
- Rollback procedure is rehearsed and verified.
- No unresolved critical/high severity findings; all open PR review threads resolved or explicitly accepted by Owner with rationale.
- Owner, Management, Warehouse, Sales, Finance and HR acceptance is captured for each workflow they own.
- Ethiopian payroll/tax/pension legal review is captured by a qualified reviewer. Do not mark payroll production-ready without it.

## 11. Incremental commit and CI discipline

For every coherent target:

1. State the baseline commit and source(s) used.
2. Make the smallest complete code change that implements the target; preserve unrelated files and existing best work.
3. Add/adjust automated tests at the actual failing layer.
4. Run target-specific tests locally.
5. Commit the target with a meaningful message and update changelog/evidence.
6. Run exact-head GitHub Actions, security and packaging gates on that commit.
7. Fix each failed check in a subsequent commit; rerun all relevant checks and cumulative regressions on the new exact head.
8. Attach logs, test counts, artifacts and SHA values to the PR/evidence pack.
9. Do not count an earlier passing run, a different commit, a mock browser run or a sibling branch's CI result as proof for the current head.
10. Never disable a failing check, delete tests or lower thresholds without an explicit technical explanation and owner approval.

Build the final WordPress ZIP from the exact source commit that has passed all required gates. After the ZIP is built, test the ZIP itself, compute SHA-256 and compare it with the receipt. If any source changes after that build, rebuild and rerun all package gates.

## 12. Production readiness and live-update rules

**A passing CI run is not the same as production acceptance.** A local mock test or clean staging install is also not proof that the live database can be safely upgraded.

Production GO is allowed only when all of these are documented:

- exact currently installed source/package recovered and compared (or owner explicitly accepts a documented gap and an independently tested migration strategy);
- final canonical branch/commit and PR reviewed, with no unresolved critical/high review issues;
- exact final ZIP, SHA-256, build receipt, manifest and artifact file inventory verified;
- complete fresh install and all supported upgrade paths pass on isolated WordPress/MariaDB environments;
- all operational journeys and role/location controls pass with independent quantity and monetary reconciliation;
- migration rehearsal, backup restoration and rollback pass;
- security, dependency, secrets, static code and browser/UI gates pass;
- actual HR/SOP resources and payroll legal requirements accepted;
- Owner/Management and relevant department acceptance recorded;
- a release plan states downtime/cache strategy, installation order, post-install health checks, rollback trigger and responsible operator.

Do not auto-deploy or run destructive SQL against the live site from Codespaces. Produce the one approved in-place WordPress update ZIP and a clear owner install procedure after all gates. The owner decides when to install it on production.

## 13. Owner inputs still required

The owner should not need to restate the business scope. The material missing inputs are:

1. **Exact currently installed 16.2.13 plugin ZIP/source export**, if that is still the installed release. Upload the original package as-is. Do not edit or rename files before uploading.
2. **Actual 24 SOP/HR policy document files** (if not already present in the Library separately), including job descriptions, contracts and policy forms the owner expects users to download/edit/save. The existing acceptance register is not a substitute.
3. **16.3.1 local ZIP**, only if the owner still has the exact candidate mentioned by its audit and wants it compared. The recorded SHA alone is not sufficient to reconstruct the binary.
4. Any owner-approved payroll/legal policy decisions and authorized reviewers, once the engineering team provides the exact questions and official-source evidence.

Everything else in this note, including business locations, workflows, design direction, schema history and engineering restrictions, should be treated as existing project context. Do not ask the owner to repeat those details.

## 14. Required final deliverables

The Codespaces agent must deliver:

1. Complete source archaeology and reconciliation report.
2. Per-version/source evidence index with SHA-256, commit/branch/PR/workflow and lineage.
3. Feature-preservation and regression matrix across both series.
4. Canonical architecture/schema decision, migration map and rollback plan.
5. A complete cumulative implementation using incremental commits on a controlled branch/PR.
6. Exact-head CI logs and test evidence for each committed target and the final commit.
7. One final production-candidate WordPress ZIP; a single plugin root, deterministic manifest/build receipt and SHA-256.
8. Installer inventory, SBOM/license/dependency/security results and release notes.
9. Staging acceptance report for all required roles, workflows, desktop/mobile layouts, backup restoration and rollback.
10. Owner release decision page/report with honest **GO / NO-GO** status, remaining risks and the precise procedure to update the live WordPress site.

Every status must distinguish `PASS`, `FAIL`, `BLOCKED`, `NOT RUN`, `OWNER INPUT REQUIRED` and `NOT APPLICABLE`. No “100% ready”, “fully tested”, “production safe”, “all CI passed” or “deployed” wording unless exact evidence supports it.

---

## Immediate instruction to the Codespaces agent

Start by reading the PR #55 directive documents and this handover. Do not edit application code yet. Fetch all refs/tags, build the complete history map, inspect every available package in the companion source archaeology ZIP, and compare the exact 16.1.95, 16.2.9 and 16.3.0 installers. Then recover the exact installed 16.2.13 package and the missing 16.3.1 / SOP assets where possible. Publish the archaeology report and an evidence-backed canonical-baseline recommendation first. Only after the source map and owner-package gap are resolved should you begin incremental implementation and exact-head CI closure.

**Owner's end goal:** one complete, stable, responsive, cumulative Stockland Ethiopia ERP WordPress/PWA that preserves the best work from the full project history, passes real isolated CI and end-to-end operational tests, can be safely upgraded in place, and is accompanied by verifiable release evidence. Do the engineering work; do not make the owner sort version conflicts or accept another unverified ZIP.
