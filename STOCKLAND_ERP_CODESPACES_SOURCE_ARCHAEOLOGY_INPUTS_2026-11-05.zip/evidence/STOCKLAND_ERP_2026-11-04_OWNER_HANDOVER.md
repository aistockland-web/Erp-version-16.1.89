# Stockland Ethiopia ERP — 4 November 2026 Owner Handover

**Purpose:** Carry forward the Owner's 4 November decisions and ChatGPT/engineering working rules across chats, tools, repositories and machines. This is a curated handover summary of the linked Notion and GitHub records, not a replacement for those source records.

## 1. Controlling 4 November records

1. **Notion — 16.1.95 Protected Master — HR/Payroll Integration Decision — 4 November 2026**  
   https://app.notion.com/p/40d6db0f767e8140b744d32a043269f9
2. **GitHub — Cross-Platform Project Work Directive — ratified 4 November 2026** (available on the PR branch)  
   https://github.com/aistockland-web/Erp-version-16.1.89/blob/63e1b29477bbde60ddbdec8615822b39308bebaa/docs/engineering/STOCKLAND_ERP_CROSS_PLATFORM_PROJECT_WORK_DIRECTIVE_2026-11-04.md
3. **GitHub — Release Restriction and Readiness Corrective Action Plan — 4 November 2026** (PR #48 branch)  
   https://github.com/aistockland-web/Erp-version-16.1.89/blob/55e24b735417d3455bf7a591a5344c4ea05354e0/audit/STOCKLAND_ERP_RELEASE_RESTRICTION_CORRECTIVE_ACTION_PLAN_2026-11-04.md
4. **GitHub — PR #54, documentation-only directive PR**  
   https://github.com/aistockland-web/Erp-version-16.1.89/pull/54
5. **GitHub — PR #48, HRX candidate and corrective-action thread**  
   https://github.com/aistockland-web/Erp-version-16.1.89/pull/48
6. **GitHub — PR #49, 16.1.101 staging candidate**  
   https://github.com/aistockland-web/Erp-version-16.1.89/pull/49
7. **Notion — 3 November production release decision**  
   https://app.notion.com/p/40d6db0f767e81eb9ed1d7ddb6525d10
8. **Notion — 3 November 16.3.0 consolidation evidence**  
   https://app.notion.com/p/40c6db0f767e8115b6e2fc0b437d4a0a
9. **Notion — canonical release audit and acceptance gates**  
   https://app.notion.com/p/3fc6db0f767e81f2a3bbe644048054f9

## 2. Rules agreed between the Owner and ChatGPT/engineering

### Owner authority and continuity

- The Owner's approved business plan and decisions across previous chats and versions remain the product authority. A new chat or engineer must review the existing plan, audit history and current handover before acting.
- Do not restart the project, narrow the agreed scope, substitute a different architecture or discard accepted functionality merely because work moves to another chat, platform or machine.
- The Owner controls business scope, priorities and acceptance. Assistants and tools may recommend engineering methods; they do not silently rewrite the Owner's decisions.

### Engineering freedom

- Engineering GO applies across chats, platforms, machines, editors, local environments, GitHub and other suitable tools. Work is not restricted to ChatGPT or one computer.
- Build/test/staging environments are engineering methods, not the intended product. Do not turn a test or candidate package into the product or permanently label the final deliverable as a staging-only product.

### One complete product

- End deliverable: one cumulative, integrated Stockland Ethiopia WordPress ERP plugin, one final installable ZIP, one canonical source commit, one manifest/inventory/build receipt and one independently recomputed inner-installer SHA-256.
- No partial feature packs, disconnected add-ons, demo releases or artificial version proliferation as a substitute for the complete system.
- Do not remove accepted functionality to make a smaller package appear complete. Legitimate business processes such as staged import review, draft approvals and temporary migration tables must be judged by their business purpose, not by searching for the word “stage”.
- No synthetic payroll runtime, fabricated employee compensation, fake sales/payroll, demo business records, test switches or QA artifacts in the installed product runtime. Keep test tooling and synthetic fixtures outside the product ZIP.

### Protect live behavior and data

- Preserve Owner authority, roles/capabilities, maker-checker controls, branch/location boundaries, approved SOP order, POS/cart, Product Master, inventory, Central Warehouse and branch workflows, stock ledger, accounting, AP/AR, GL/PLEDGER, finance, audit history and existing business data.
- Preserve posted history. Corrections, returns, refunds, reversals and adjustments must be traceable compensating events, not silent rewrites.
- Reuse existing Stockland identity, authorization, workflow, database, money, audit, notifications, accounting and ledger services. Do not build a competing accounting or stock ledger engine.
- Trace business actions end to end: UI → authenticated REST → server-side role/capability/profile/location/row authorization → domain service → database transaction → stock/accounting effect → persisted state → audit event → user-visible result.
- A nonce is CSRF protection, not authorization. Do not report success before the transaction is committed and verified. Failed writes must roll back safely.

### Evidence and truthfulness

- Every check is reported distinctly as **PASS, FAIL, BLOCKED or NOT RUN**. Unknown, skipped, incomplete, stale or different-version tests do not count as PASS.
- CI/static source tests, synthetic fixtures, owner-supplied screenshots, authenticated live WordPress/MariaDB tests, backup restore, and independent legal review are different evidence classes. One cannot substitute for another.
- Never invent restrictions, conceal failures, weaken safeguards without a reason, manufacture a green System Health result, or claim production-ready without exact-package evidence.
- Every final acceptance record must refer to the same exact final ZIP SHA and exact source commit.

### GitHub and Notion operating protocol

- GitHub is the implementation history/release artifact authority. Notion is the cross-project authority for Owner decisions, accepted scope, design, SOPs, audit findings and acceptance records.
- Keep both synchronized: accepted scope/source/release decisions in both; GitHub commits, PRs, workflows, artifacts and hashes linked in Notion; Notion implementation decisions represented by GitHub changes before code is accepted.
- Before editing, fetch current canonical `main` SHA and the controlling Notion decision. Branch from that SHA; do not work directly on `main` or overwrite the protected master.
- Use focused, reviewable commits and PRs. Keep incomplete work draft. Attach changed-path inventory, risks, data/schema impact, exact test results, manifest and checksums.
- Run exact-head CI against the exact ZIP: PHP 8.3/8.4, JS/Node 22, Python 3.12 build/receipt checks, ZIP/path/root integrity, CSS module order/parity/PostCSS/responsive checks, PHPCS/WPCS, Semgrep, applicable CodeQL/secret/dependency scans and functional/regression tests. A stale run, skipped required job or different artifact is not a pass.
- Do not force-push, rewrite protected history, merge unreviewed code or deploy automatically.

### Data safety and runtime

- Use a controlled isolated copy of authorized production data for destructive tests, synthetic fixtures, failure injection, migration, restore and rollback. Never add fictional staff, compensation, sales or payroll to the live company ledger.
- In production, execute only actual Owner-authorized events and approved migrations.
- Do not invent Ethiopian PAYE, pension, allowance, exemption or final-settlement rules or missing employee values. Map official provisions/effective dates and obtain qualified independent review.
- Encrypt private HR documents at rest with a site-managed key and encrypted backups; authenticate and scope downloads by role/location. Keep secrets out of source control and ZIPs.
- Production runtime is WordPress/PHP 8.3+, REST and MySQL/MariaDB over HTTPS. Python 3.12 and Node.js 22 are build/CI tools, not hidden runtime services.
- Keep Bootstrap 5.3.8 pinned and the ordered CSS-module build. PWA is online-first for transactions; do not cache salary, identity or private business data in the service worker.

## 3. Version and source-lineage register relevant to 4 November

| Version / line | 4 November role or finding | Exact identity / evidence | Decision |
|---|---|---|---|
| **16.1.95** | Protected operational master and rollback reference; 49-table contract, 75 files | SHA-256 `494e777247508d009dfdb216c9607bb1bc96717197e94a0e8ad3459b7cc81625`; GitHub Actions artifact `12536703884`; source/package workflow `40036018031` | Preserve byte-for-byte as the protected reference. Do not replace it wholesale with a later candidate. |
| **16.1.98** | Side line, 79 files | SHA-256 `1997b33326b45c7d0a32ba283dc7fb6ea8bd4a61d1392990944065add5c81f8b` | Pinned to 16.1.95; not proven to include intervening 16.1.97 work; not the final foundation. |
| **16.2.9** | Selected HR/Payroll source from merged PR #39 | Merge commit `bd6c78f180e3bc6871317aa32c1f11d4fab8a427`; exact artifact SHA-256 `c9f6459c71087575d8554e599a1ed5025a9e21655f24886c933232ac194d9c01`; 88 files; workflow `41146685514` | Use selectively as HR/payroll source, not as a wholesale replacement. It adds 37 HR tables, changes legacy HR schema behavior, has historical approval/rate defaults and a synthetic-only calculator path; full PHPCS/WPCS findings are substantial. |
| **16.2.13** | Reported currently installed product in the 4 November corrective-action audit, based on Owner-supplied System Health evidence | Exact installed ZIP/source SHA was not obtained in that audit | Must not be assumed identical to 16.1.95. Recover and compare the exact installed 16.2.13 source before a live replacement so later installed changes are not lost. |
| **16.3.0 HRX** | HRX integration/candidate line, built from 16.1.95 rather than merged 16.2.9 | 3 Nov report recorded current-review SHA `0bb23267d00d31125f49552b61be25756eacbf5261d6a14b5a88cd3010450cbe`; 4 Nov corrective-action report records a later exact artifact SHA `f48993499e7664c45a079595af8efedbd5881728952cf019428f5db2d1872412` from run `41733684055` / artifact `13276687926`; 76 files | Not cumulative and not a safe full-ERP replacement. HRX 47-table proposal stays unapproved/disabled. The 4 Nov corrective-action report says no global ERP shutdown flag was found; the HRX schema gate is module-scoped. Later commits after successful run `41734244180` were not CI-verified at the latest source head. |
| **16.3.1** | Local consolidated master receipt | SHA-256 `36b215da876f297a6d6948eda0b050e4d8b4d9d5ef2c7009e5b5120f3ca2faa5`; 85 files / 51 PHP; 63 assertions passed, 0 failed, 5 findings; status `CONDITIONAL_PASS` | Actual ZIP/source not available for independent rehash in the cited audit; not committed as the final GitHub release; not production-certified. |
| **16.1.101** | PR #49 staging candidate, 24 SOP DOCX tab; MariaDB setup fixes | PR #49: https://github.com/aistockland-web/Erp-version-16.1.89/pull/49 | Its reported test coverage includes setup 49/49, HRX 33/33, seven-batch deep scan, 24/24 downloads and desktop/mobile browser checks. But it says staging/not production-ready; deployed 16.1.98 package was not in repo; role/business flows, restore/rollback and payroll legal sign-off were not run. Not selected as final master. |
| **16.2.10** | Folder/reference mentioned in Library history | `/Stockland optimizatio/ERP 16.2.10 source` was found empty in the earlier Library inspection | No verified 16.2.10 complete installer/source was recovered as part of the 4 November controlling decision. Do not assign it baseline authority without the actual bytes and lineage. |

**Important:** more than one 16.3.0 artifact/hash appears in the dated records. They are different builds/receipts and must never be treated as interchangeable. The 16.3.1 SHA is a Notion local receipt, not a currently recovered ZIP. The 16.2.13 installed version is reported but not independently hashed.

## 4. Why the 16.2.9 and HRX lines cannot simply be overlaid

- 16.2.9 changes three legacy HR tables through ALTER behavior and adds many HR tables. It contains an `APPROVED` migration default where fresh DDL uses `DRAFT`, and carries 7%/11% pension defaults that require legal/source validation.
- It includes a synthetic-only calculator path that must be externalized to QA tooling before final product packaging.
- Its private HR vault integrity hashing is not encryption at rest.
- HRX 16.3.0 proposes a 47-table replacement schema that is not approved; the four legacy HR/payroll tables must be preserved until mapped migration, reconciliation, backup and rollback are approved.
- The exact 16.2.9→16.3.0 comparison found dropped POS cart and six CSS/runtime modules, among other removals/changes. That package is not a complete 16.2.9 superset.
- The 4 November note reports 40 PR #48 review threads with none resolved at the time of its review; overtime/holiday pay, unpaid-leave deduction and ONE_TIME/HOURLY/DAILY compensation remained unsupported and blocked payroll. It also identifies a remittance concurrency risk.
- The 24 Amharic-first SOP/JD/contract resource files were absent from 16.3.0/16.3.1 receipts. Their actual authorized files and hashes must be recovered and included or provided through an approved secure process.

## 5. Scope of the one final integrated ERP

Product Master/SKU/variant and Excel import; retail POS/cart and wholesale; Central Warehouse plus Goro, Gerji, Mexico and Megenagna; receiving/put-away, requisitions, reservations, transfers, returns, damage, adjustments, counts, replenishment and daily close; suppliers/customers/procurement; expenses, AP/AR, VAT, COGS, GL/PLEDGER and reconciliations; reports/print/export; full hiring-to-exit HR lifecycle; contracts/JDs, attendance/leave, effective-dated compensation, payroll preflight/approval, individual payee/creator/freelancer workflows, payouts, remittances, final settlement; private HR documents; 24 approved Amharic-first SOP/resource items; Management Intelligence/integrations only when actually configured; responsive SaaS-style UI/PWA.

## 6. Production GO checklist — same exact final SHA

- Exact source commit, final ZIP, manifest, inventory, build receipt and independently recomputed inner ZIP SHA agree.
- PHP 8.3/8.4, Node/JS, CSS/PostCSS, Python build, package/path, full PHPCS/WPCS, Semgrep, CodeQL/secret/dependency and functional/regression checks pass; no required job is skipped or stale.
- Authenticated WordPress/MariaDB install and update, REST, role and branch/location success/denial, private documents and exact deployed-source parity pass.
- Product Master/import, POS, stock ledger, receiving, requisitions, reservations, transfer, returns, adjustments, physical counts, daily close, procurement, AP/AR, VAT, COGS, GL/PLEDGER and reports reconcile.
- Full HR lifecycle, two complete payroll periods, verified authorized compensation, legally approved effective-dated rules, payout/remittance and final settlement reconcile.
- Idempotency, concurrency, retries, failure/rollback, migrations and historical-data preservation pass.
- Deep-integrity receipt, backup of files/database/private-document keyring, successful restore and rollback rehearsal are attached.
- Browser/device/PWA, accessibility, keyboard, responsive layout and print/export acceptance pass.
- Approved 24-file SOP/resource pack is included or provisioned by an approved secure method and each hash/render/download is verified.
- Owner, Operations, HR, Finance and qualified Ethiopian labour/tax/pension/data-protection sign-offs are tied to the exact final SHA.

## 7. Important status distinction: engineering GO vs production GO

**Engineering GO:** granted by the 4 November Owner directive. Full-scope implementation, correction, integration and optimization may continue across platforms and chats.

**Production GO:** not granted by the 4 November version records. No recovered 16.3.0/16.3.1/16.1.101 package was certified as the final production ZIP. The 3 November production decision remains NO-GO for the available packages because material blockers remain. The 4 November corrective-action note narrows the meaning of “NO-GO” so HRX candidate wording is not mistaken for a global ERP shutdown; it does not convert an unverified candidate to production-ready.

## 8. Record conflicts and unresolved points to carry forward

1. **16.1.95 protected baseline vs reported installed 16.2.13:** the formal protected-master directive selects 16.1.95 as the preservation/rollback reference, but the 4 November corrective-action note says 16.2.13 is the reported currently installed version and its exact ZIP/source hash is unavailable. Resolve the live-source parity and branch target before creating a replacement; do not confuse a rollback reference with proof of the current installed bytes.
2. **Notion vs GitHub PR #54 status:** Notion's ratification text labels PR #54 as a draft review record. GitHub's PR API currently reports PR #54 closed/unmerged, and the repository `main` branch still points to base SHA `a46214f6bd5e21a9948d5c896d2136d722d36f16`. A merge-commit object exists, but it is not the `main` tip. Therefore treat the directive as authoritative Owner/Notion working direction and the GitHub branch as an available copy, not as a verified merge into `main`.
3. **16.3.1:** conditional local receipt only; ZIP/source not independently recoverable in the cited audit. Do not ship from its receipt alone.
4. **16.3.0:** several distinct artifact hashes exist. Recompute and bind the exact source commit, workflow run and actual installer ZIP before any reuse.
5. **16.2.10:** no complete installer/source was recovered from the referenced Library folder.

## 9. Copy-ready instruction for the next ChatGPT conversation

> Continue Stockland Ethiopia ERP using the 4 November 2026 Owner handover. The Owner's approved plan across prior chats and versions controls. Engineering mandate is GO across chats, platforms, machines and tools; do not restart or narrow the scope. Deliver one complete cumulative WordPress ERP plugin ZIP, one canonical source commit and one independently verified SHA-256—not partial releases or demo/staging products. Preserve the exact 16.1.95 protected master as rollback reference and use merged PR #39 / exact 16.2.9 as selected HR/Payroll source for selective integration only. Do not overlay 16.2.9/16.3.0/16.3.1/16.1.101 wholesale. Preserve the 49-table baseline and four legacy HR/payroll tables/history until a mapped, approved additive migration and rollback are proven. Recover and reconcile the reported installed 16.2.13 exact source/hash before any in-place replacement. Preserve all existing Owner authority, role/location rules, maker-checker, SOPs, POS/cart, Product Master, inventory, warehouse, stock ledger, AP/AR, GL/PLEDGER and audit behavior. Reconcile every removed or changed path, especially POS cart and CSS modules. No synthetic payroll runtime or invented staff/pay data/statutory rates. Keep private HR documents encrypted at rest. Work on a dedicated branch from current main, use focused PR commits, test the exact ZIP on PHP 8.3/8.4 and WordPress/MariaDB, keep GitHub and Notion synchronized, and report PASS/FAIL/BLOCKED/NOT RUN honestly. Engineering GO does not mean production GO. Do not claim production-ready until the same final ZIP SHA has complete technical, live operational, reconciliation, backup/restore/rollback, SOP, Owner/Operations/HR/Finance and qualified Ethiopian statutory acceptance.

---

**Prepared from the 4 November Notion and GitHub records reviewed in this chat.** No application code, production database, plugin installation or deployment was changed while preparing this handover.
