# Stockland Ethiopia ERP 16.1.86 — WordPress Local Update Guide

## Before updating

1. **Check PHP.** This plugin declares `Requires PHP: 8.4`. Confirm the destination runs PHP 8.4+ before attempting installation. This ZIP should not be installed on PHP 8.3 without a separate, tested compatibility correction.
2. **Use staging first.** Clone the WordPress site if possible. This is especially important because the package's database and operational workflows have not been tested on your target host during this build.
3. **Back up files and database.** Make a database export and a copy of `wp-content/plugins/stockland-erp-app/` (or the actual plugin directory name). Confirm that you know where the backups are stored and can restore them.
4. Record the current plugin release, WordPress/PHP versions and whether all 49 ERP tables exist. Keep the previous working plugin ZIP for rollback.

## Install the ZIP

Installer: `STOCKLAND_ERP_16.1.86_LOCAL_WORDPRESS_UI_UPDATE.zip`

- Open **WordPress Admin → Plugins → Add New Plugin → Upload Plugin**.
- Select the ZIP and proceed with the WordPress update/replace flow if the screen offers that option for the existing plugin.
- If WordPress does not offer a safe replacement flow, do not delete the only working copy first. Use your hosting file manager or FTP to keep a backup copy of the existing plugin directory, then replace files only after the backup is verified. Avoid leaving two active copies of Stockland ERP.
- Do not deactivate/delete the existing plugin as a casual troubleshooting step; the ERP has activation, database and operational state to protect.
- After the update, confirm the plugin shows version **16.1.86**. If the version does not change, stop and verify which plugin directory WordPress loaded.

## Check after update

1. Log in as an authorized ERP user and open the actual `/stockland-erp-app/` entry page.
2. Hard-refresh the browser and clear the site/service-worker cache if the page appears to use old assets.
3. Check the global search on desktop, tablet and phone. Search for a known SKU/product and a permitted customer/order using two or more characters. Confirm results remain role/location-scoped.
4. Verify the search popover is closed before typing and closes with Escape/outside click as expected.
5. Open System Health and check for schema/version errors. Smoke-test login, POS, receiving, transfer/requisition, returns, inventory, reports, finance and HR/payroll using authorized test records and normal business procedures.
6. Inspect browser console and hosting PHP/error logs if any page stays blank, search is missing, API requests fail or the app reports schema trouble.
7. Do not process sensitive live transactions until the owner verifies that operational workflows and financial balances remain correct.

## Rollback

If the dashboard breaks or a critical regression appears:

1. Stop operational use; do not repeat a transaction that may already have committed.
2. Restore the previous plugin files from the saved copy/previous ZIP.
3. Restore the database backup only when necessary and only after determining whether this update changed data. A UI-only update is intended not to alter the schema or business data, so do not automatically restore/overwrite the live database for a CSS problem.
4. Verify the previous release, ERP login, dashboard, System Health and core operations before resuming work.

## What this update does not prove

Local code, ZIP, static and simulated CSS/browser layout checks passed. These checks are not a substitute for testing the exact ZIP on the real WordPress/PHP/MariaDB host. Live role-based search, REST responses, business transactions, all 49 tables, backups/restoration, rollback and exact-version GitHub CI/security scans remain acceptance gates.
