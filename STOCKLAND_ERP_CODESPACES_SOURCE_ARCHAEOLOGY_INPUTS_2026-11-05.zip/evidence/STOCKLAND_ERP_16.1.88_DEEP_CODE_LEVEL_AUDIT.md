# Stockland ERP 16.1.88 — Deep Code-Level Audit

**Disposition: staging candidate, not live-production certified.** The 16.1.88 WordPress installer is locally validated against the 16.1.87 package. It has not been installed on the live site, and no authenticated production database checks were executed here.

## Artifact
- File: `STOCKLAND_ERP_16.1.88_STAGING_CANDIDATE_WORDPRESS_UPDATE.zip`
- Size: 1,102,340 bytes
- SHA-256: `e7ce6ecb9ffdca987409dc07c6d15cfc0e150a988a84eb9d55d628a0f09c01a8`
- Baseline: `STOCKLAND_ERP_16.1.87_OWNER_WHOLESALE_SURPLUS_UPDATE.zip`
- Baseline SHA-256: `2cc7cbef17cc068b7c3d9a86569c0977ec39a06fc3676513f03c71e49adf5426`
- Archive integrity: PASS; 74 files; single `stockland-erp-app/` root.

## Preservation / scope
A byte comparison shows 74 baseline files and 74 candidate files, with no additions/removals and 14 changed existing files. Only `stockland-inventory.php` and `includes/class-stockland-frontend.php` change among PHP sources, solely for plugin release identity and frontend route/cache version. The accounting/procurement REST controller, wholesale REST controller, accounting, ledger, audit and authority services, and both Stockland brand logo assets are byte-identical to 16.1.87. The 49-table contract remains 29 + 16 + 4; DB version remains 16.1.1. No DDL, data migration or schema marker changes.

## Verified fix: Purchase Order form
The UI binder could append a default PO line on initial binding and again after asynchronous Finance bootstrap data refresh. The extra blank line has a required unit cost, which causes native HTML form validation to block create before a REST request. In 16.1.88 the initial line insertion is conditional on `#poFinanceLines` not already containing `.sl-fin-line`. A source invariant protects this behavior and a Chromium mock-API test now submits a PO after finance refresh, verifies the single SKU line and request key, and submits it to Owner.

## Logo / dropdown / mobile header
- Existing `assets/stockland-logo.jpg` and `assets/stockland-sidebar-brand.png` are preserved byte-for-byte.
- At <=390 px the top logo stays visible (28 px) instead of being hidden.
- Profile menu placement uses the live trigger rectangle, clamps to the viewport and updates on resize/orientation/scroll/VisualViewport events. Escape/outside-click and ARIA-expanded behavior were browser-tested.
- Header/search controls, mobile MENU, command palette, group expansion and profile-menu actions were exercised across 15 viewport widths (320–1920 px), with 50 assertions and no browser errors.

## Order / GRN / PLEDGER / GL / audit evidence
- Static source audit: 62/62 checks passed, including Management-only PO creation, unique request key/duplicate protection, Draft-only creation, submit/independent Owner approval, row locks, `FOR UPDATE`, transactional GRN posting, stock ledger record, `post_journal`, audit event and rollback semantics.
- Chromium mock browser: Management creates/submits PO; Owner approves; Owner invoice/payment queue actions invoke protected routes; Warehouse Manager receives accepted quantities with an idempotency key. All four scenarios passed with in-page mock fetch; no network request reached the live ERP and no business record was written.
- Existing order/accounting/PLEDGER/GL/audit/authority service source is unchanged. This is stronger evidence that the workflow hooks and call paths remain present, but a browser mock does not validate actual database balances, audit chain hashes, deadlock behavior or posting results in the live runtime.

## Regression suite
- PHP lint 47/47.
- Payroll/System Health policy 22/22, including the pension-first ET-PAYE v3 ETB 30,000 regression.
- Notification renderer 15/15.
- Payroll preview 6 assertions.
- Release invariants 15/15.
- PostCSS validates app.css/app.min.css/Bootstrap; six-module source build and minified-token parity pass; app.js/pwa.js and JSON syntax pass.
- Final ZIP extracted and the full local regression runner was re-executed against the extracted tree; pass results include 47/47 PHP lint, payroll/Health 22/22, notification renderer 15/15, payroll preview 6 assertions, release invariants 15/15, CSS/PostCSS and minified parity. The extracted tree remained byte-identical to the packaged source.

## Live System Health boundary
The user's screenshot from live v16.1.87 reports audit-chain passed and supplemental integrity counts clean, but a payroll-compensation readiness gate fails for five active employees whose current compensation record is missing. 16.1.88 does not bypass that gate and does not edit employee records. The screen is not a fresh check from this session.

## Required before production
1. GitHub exact-version CI/Semgrep is still pending. The connected GitHub integration reports `push:false`; no commit/PR was created.
2. Back up the site and database, then prove restoration on staging.
3. Install candidate in staging; run System Health → Deep Integrity Audit and retain the result.
4. Exercise role-separated PO creation, submission, independent Owner approval, receiving, supplier invoice/AP, payment, PLEDGER/GL, audit chain and rollback using controlled staging fixtures; verify balanced GL, inventory ledger delta and audit chain after the transactions.
5. Resolve the five missing compensation records through the existing HR/payroll SOP; do not weaken readiness checks or fabricate compensation values.

Until those gates are evidenced, **do not treat this ZIP as a verified live-production release**.
