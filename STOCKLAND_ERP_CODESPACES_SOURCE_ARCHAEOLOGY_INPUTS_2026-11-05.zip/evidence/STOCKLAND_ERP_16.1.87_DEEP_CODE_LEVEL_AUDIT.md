# Stockland Ethiopia ERP 16.1.87 — Deep Code-Level Audit

**Disposition:** Complete installable plugin ZIP assembled and locally validated. The dashboard is tuned to the supplied 1280×1169 sample; live WordPress host acceptance remains pending.

## Exact package

- File: `STOCKLAND_ERP_16.1.87_CANONICAL_WORDPRESS_UPDATE.zip`
- Size: 1,057,415 bytes
- SHA-256: `ffefdec277a9a3fa817de20137a6cb299bc875de2259cfa979ba53773874608b`
- Base: `STOCKLAND_ERP_16.1.84_CANONICAL_WORDPRESS_UPDATE.zip`
- Base SHA-256: `9f0295af89311e7a1c4f861ec3f7bc54db071fd143390462942d6488e9f464bf`
- ZIP integrity: PASS; 72 unique files; one `stockland-erp-app/` root; no test/dev files packed.

## Sample visual alignment

The implementation follows the screenshot’s key geometry and hierarchy: 228px navy sidebar; 56px white toolbar; search/K keyboard hint, notification, location and profile; welcome/date line; 4 KPI cards; paired sales/category charts; 6 Quick Action cards; compact right-hand low-stock, branch and recent activity panels; recent transaction grid; branded apparel footer. The desktop preview at 1280px records the main cards near the same positions as the sample. The mobile preview uses stacked charts/cards and a compact toolbar. The latest desktop/mobile image files linked with this release are synthetic QA previews, not screenshots of the live database.

The old Workspace duplicate remains absent. The global search, command palette, profile menu, WordPress Dashboard route, role-filtered grouped navigation, real bootstrap/insight/notification requests, branch/location data and action routes remain available. Sample values are not hardcoded in production dashboard rendering.

## Changed-file/preservation proof

Compared byte-for-byte with the canonical 16.1.84 installer:

- Same 72-file inventory: no additions/removals.
- 14 changed files: `README.md, RELEASE_MANIFEST.json, assets/app.css, assets/app.js, assets/app.min.css, assets/css/01-foundation.css, assets/css/02-shell-navigation.css, assets/css/03-content-data-components.css, assets/css/04-overlays-workflows.css, assets/css/05-responsive-layout.css, assets/css/06-operational-guards.css, assets/css/modules.json, includes/class-stockland-frontend.php, stockland-inventory.php`.
- Only changed PHP files are `stockland-inventory.php` (version header/constant) and `includes/class-stockland-frontend.php` (route/cache version plus optional current user avatar URL, with fallback). The other 45 PHP files match the 16.1.84 base byte-for-byte.
- Database contract remains 29 + 16 + 4 = 49 tables; DB/core 16.1.1, Accounting 16.1.15 and HR 16.1.3 remain unchanged.
- Existing payroll v3 logic/ETB 30,000 regression, notification action hooks, backend REST authority, stock/ledger posting and SOP transitions passed their regression checks or are byte-identical to the base PHP implementation.

## Local validation

- PHP syntax: 47/47 pass.
- Payroll/System Health policy: 22/22 pass, including ETB 30,000 → taxable base 27,900, PAYE 7,715, pension 2,100, net 20,185.
- Notification renderer: 15/15 pass.
- Payroll preview: 6 assertions pass.
- Release invariants: 14/14 pass.
- Six CSS modules rebuild deterministically; PostCSS parses app.css, app.min.css and Bootstrap; minified output equals normalized source.
- JavaScript and JSON syntax checks pass.
- Chromium synthetic-dashboard smoke: 14 widths from 320 to 1920px; no page/console errors, no document-level horizontal overflow, 15/15 dashboard checks passed; print emulation remained valid.
- ZIP bytes match all 72 source files exactly; SHA-256 sidecar verified.

## Release boundary

The dashboard preview uses mock API values only; no live sales, stock, purchases, payroll, finance or ledger entries were created. Exact 16.1.87 GitHub Actions/PHPCS/WPCS/Semgrep is not run because the connected GitHub integration is read-only. The live WordPress/MariaDB instance was not changed. Authenticated live workflows, the actual deep System Health scan, backup restoration and rollback remain pending.

Install only after verifying a backup; confirm version 16.1.87, run System Health → Deep Integrity Audit, and validate role-based workflows on staging/approved production window. Do not interpret local passes as 100% production certification.
