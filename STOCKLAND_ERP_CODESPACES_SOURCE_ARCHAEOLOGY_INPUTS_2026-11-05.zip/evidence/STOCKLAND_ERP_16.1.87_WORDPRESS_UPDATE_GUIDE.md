# Stockland ERP 16.1.87 — WordPress Update Guide

**Installer:** `STOCKLAND_ERP_16.1.87_CANONICAL_WORDPRESS_UPDATE.zip`  
**SHA-256:** `ffefdec277a9a3fa817de20137a6cb299bc875de2259cfa979ba53773874608b`  
**Current live installation noted by the user:** 16.1.83. This package identifies itself as 16.1.87.

## Before update

1. Back up both WordPress files and the database; verify you can restore the backup or use a staging clone.
2. Verify the downloaded ZIP with the companion `.sha256` file.
3. Confirm PHP 8.4+ (the plugin header declares PHP 8.4 as the minimum).

## Install

1. WordPress Admin → Plugins → Add New Plugin → Upload Plugin.
2. Upload the ZIP. When WordPress offers replacement of the existing Stockland Ethiopia ERP, choose the replace/update option. Do not delete the installed plugin first.
3. Confirm the installed plugin reports 16.1.87 and the command center loads.
4. Hard reload and clear any site/CDN/service-worker caches if old CSS persists.
5. Verify existing global search, notifications, branch/location profile, role-filtered navigation, POS and dashboard reports. Confirm Product Master/Inventory/report tables still print cleanly.
6. Open System Health and run **RUN DEEP INTEGRITY AUDIT** after the backup. The quick check alone does not prove ledger/audit-chain/AP/AR/GL/stock integrity.
7. On a staging copy, run representative role-separated POS, receiving, transfer, requisition, inventory-count, finance, payroll and report workflows; test restore/rollback.

## Scope

This is a dashboard visual refinement. It keeps the sample layout (navy sidebar, slim toolbar, KPI row, paired analytics, quick actions, low-stock/branch/activity rail, transaction grid, apparel banner) but keeps figures and records from the live ERP APIs. No sample screenshot numbers are written into production code. The 49-table contract and database-version markers are unchanged.

## Acceptance note

The package is locally validated. Exact-version GitHub CI/security scanning, authenticated target-host checks, full live deep-integrity results, backup restore and rollback must be completed before declaring production certification. This package was not deployed by this session.
