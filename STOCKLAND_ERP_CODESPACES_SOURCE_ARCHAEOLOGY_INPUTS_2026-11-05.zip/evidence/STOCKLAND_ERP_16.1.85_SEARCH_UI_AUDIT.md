# Stockland Ethiopia ERP 16.1.85 — Search UI / Bootstrap Compatibility Audit

**Status:** Locally validated candidate package; not deployed and not production-certified.

## User-reported symptom

The WordPress-hosted ERP page reportedly loses or hides the global search bar, with Bootstrap 5.3.8 styling not visibly reflected and the dashboard not feeling like a cohesive SaaS workspace.

## Evidence and diagnosis

- The provided live page URL (`https://stocklandet.gamer.gd/stockland-erp-app/`) was not accessible from this review session. The web opener returned an inaccessible-page error and the container could not resolve the hostname. Therefore the currently deployed markup, CSS cascade, HTTP asset responses, and live installed version could not be inspected directly.
- The saved 16.1.84 package and its audit are available in the user's Library. That audit explicitly says the 16.1.84 package was not deployed and that authenticated live-site acceptance remained pending.
- The connected public GitHub `main` source was observed at 16.1.78, not 16.1.84. The source repository connection is read-only in this session. This discrepancy makes a stale deployed build a plausible cause, but it does **not** prove which version the live host currently runs.
- In the saved 16.1.84 source, `assets/bootstrap.min.css` is the official bundled Bootstrap **5.3.8** file, enqueued before the Stockland app stylesheet. The application UI primarily uses its own `.sl-*` component CSS, so Bootstrap is a base/framework dependency rather than the main dashboard skin. Previously generated synthetic QA screenshots for 16.1.84 show the search visibly rendered on desktop and mobile.
- The global search is authored in `assets/app.js` as `#slGlobalSearch` with results panel `#slGlobalSearchResults`, and calls the existing `/app/global-search?q=...` route. Its role/authorized-location behavior, event handlers, IDs and ARIA state were left intact. The likely CSS vulnerability is that some `.sl-top`/`.sl-global-search` rules were not consistently scoped under `#stockland-app`, making them easier for broad theme/Elementor selectors to override. Because the live HTML was unavailable, this remains a source-based hypothesis, not a confirmed live root cause.

## Changes in 16.1.85

1. Increase selector specificity for the ERP top toolbar, global-search wrapper, label and input, scoped under `#stockland-app`.
2. Make toolbar/search visibility, input sizing and light background resilient to generic WordPress, Elementor and theme CSS. Preserve `[hidden]` semantics so search results remain hidden until the application opens them.
3. Define explicit search grid placement: its own toolbar column on desktop and its own row at tablet/mobile widths.
4. Add `data-bs-theme="light"` to both ERP root render paths and bridge Bootstrap body/text/background, primary, border, link, font, focus-ring and button tokens to the existing Stockland navy/blue/teal/emerald SaaS palette.
5. Bump the WordPress plugin and frontend route/cache version to 16.1.85 so the modified stylesheet is fingerprinted and refreshed.

## Scope protection

No business controller, REST endpoint, permission callback, role definition, workflow/SOP, sales or stock posting, inventory ledger, AP/AR/GL, payroll calculation, database/schema version or table contract was changed. The plugin retains 49 business tables (29 Core/Operations + 16 Accounting/Procurement + 4 HR/Payroll); no new table is declared. The `assets/app.js` and `assets/pwa.js` are unchanged from the 16.1.84 baseline.

## Local validation results

- ZIP packaging comparison against the exact 16.1.84 source: 72 files before and after; no file added or removed; 13 changed files total; only 2 of them are PHP files (`stockland-inventory.php` release marker and `includes/class-stockland-frontend.php` route marker plus root `data-bs-theme` attributes).
- PHP syntax: 47/47 pass.
- JavaScript syntax: `assets/app.js` and `assets/pwa.js` pass.
- JSON parse: release manifest, PWA manifest and CSS module manifest pass.
- PostCSS parse: `app.css`, `app.min.css` and `bootstrap.min.css` pass.
- The six source CSS modules rebuild `app.css` deterministically; normalized source token comparison matches `app.min.css`.
- Targeted release/UI invariants: pass, including version/cache identity, search IDs and route, Bootstrap 5.3.8 theme bridge, and preservation of the 49-table/schema markers.
- Existing regressions rerun: payroll/System Health 22/22 passed; notification renderer 15/15 passed; payroll browser preview 6 assertions passed.
- A fresh Chromium search-layout smoke was attempted with broad simulated host CSS but timed out in the local browser environment before returning DOM results. It is **not counted as passing**.

## Pending acceptance — do not overstate

- Live URL remains inaccessible from this session; live CSS, computed styles, installed plugin version and authenticated search results were not verified.
- Exact-version GitHub Actions/security scan did not run because the available repository integration is read-only.
- No package deployment, authenticated WordPress/MariaDB operations, live sales/warehouse test, backup restoration, or rollback was performed.

Before updating production, make and verify a database plus plugin-file backup, verify the actual installed version, apply the candidate package on staging if available, and test global search at desktop/tablet/mobile sizes with at least one authorized product/SKU query. Confirm that unauthorized branches and restricted fields do not appear in search results.
