# Stockland Ethiopia ERP 16.1.86 — Local WordPress UI Update Audit

**Disposition:** local candidate prepared; source and CSS checks passed; live-host acceptance remains pending.

## Provenance and package identity

- Update installer: `STOCKLAND_ERP_16.1.86_LOCAL_WORDPRESS_UI_UPDATE.zip`
- Base installer: saved Library file `STOCKLAND_ERP_16.1.84_CANONICAL_WORDPRESS_UPDATE.zip`
- Base SHA-256: `9f0295af89311e7a1c4f861ec3f7bc54db071fd143390462942d6488e9f464bf`
- Update size: 1,043,199 bytes
- Update SHA-256: `35a6562407fc76c4f49aa48897f692478847c7545b71b7e8f2ada02aae370a26`
- Archive: 72 files in one `stockland-erp-app/` directory; no added/removed paths; ZIP CRC verified.
- Release/cache identity: 16.1.86.

This package is not built from the connected GitHub repository's current `main` branch. The checked branch was at release 16.1.78, while this local candidate intentionally uses the saved 16.1.84 installer to retain that package's newer code line. The connected GitHub account has read-only access to the canonical source repository; no commit was pushed and no deployment occurred. Do not merge or replace sources across these lines without first reconciling the code baseline.

## Root-cause hypothesis addressed

The base package already contained Bootstrap 5.3.8, the global-search DOM markup and handler, the server-side REST route, and the compiled search CSS. The likely front-end weakness was the low specificity of some header/search rules in a WordPress/Elementor host environment plus missing explicit Bootstrap semantic token integration. Live computed styles were unavailable, so this was a source-based diagnosis, not a confirmed inspection of the deployed DOM.

## Change summary

The update changes 13 existing files only:

- `README.md`
- `RELEASE_MANIFEST.json`
- `assets/app.css`
- `assets/app.min.css`
- `assets/css/01-foundation.css`
- `assets/css/02-shell-navigation.css`
- `assets/css/03-content-data-components.css`
- `assets/css/04-overlays-workflows.css`
- `assets/css/05-responsive-layout.css`
- `assets/css/06-operational-guards.css`
- `assets/css/modules.json`
- `includes/class-stockland-frontend.php`
- `stockland-inventory.php`

### CSS and Bootstrap

- Scoped critical toolbar/search rules under `#stockland-app` with more resilient selector specificity and sizing/visibility declarations.
- Explicit desktop search placement; a dedicated row at tablet/mobile breakpoints.
- Kept results panel `[hidden]` semantics so no result panel appears before a search opens it.
- Added `data-bs-theme="light"` to both WordPress and standalone output paths.
- Added a semantic variable bridge from Bootstrap body, text, primary, border, link, typography, focus and button tokens to the existing Stockland SaaS palette.
- Rebuilt `app.css` from the six ordered source modules and maintained normalized CSS AST parity between `app.css` and `app.min.css`.

### Preserved application behavior

- The `#slGlobalSearch` and `#slGlobalSearchResults` IDs are retained.
- Existing endpoint `/app/global-search?q=...` and its frontend handler are unchanged.
- REST callbacks, role/capability/location authorization, business workflows and schema version markers are unchanged.
- Core business schema contract remains 49 tables (29 Core/Operations + 16 Accounting/Procurement + 4 HR/Payroll); no table was added.
- Critical business PHP source hashes (REST application, accounting, HR, accounting service, HR service, ledger and activator) match the base package.
- No added files: this remains an update ZIP for an existing plugin, not a second plugin.

## Validation evidence

The companion `STOCKLAND_ERP_16.1.86_LOCAL_QA_RESULTS.txt` records 47/47 PHP syntax passes, JavaScript syntax passes, JSON parsing, PostCSS parsing, deterministic six-module source output, normalized stylesheet AST parity, release identity alignment, protected-source comparison, ZIP CRC/inventory, SHA-256 verification and Chromium search-visibility smoke at 1440/1280/1024/768/390/320 px with generic host-theme hiding rules simulated.

## Remaining closeout gates

This is not fully closed until tests run on the actual destination host:

1. Verify PHP is 8.4 or newer; the plugin header specifically requires PHP 8.4. PHP 8.3 is not currently supported by this package's declared requirement.
2. Back up plugin files and database; verify a restore point or clone before updating.
3. Install the exact ZIP on staging, confirm the loaded release is 16.1.86, and hard-reload/clear host and service-worker cache.
4. Use an authenticated browser to verify search visibility and returned results under Owner, Manager, Warehouse and Branch/Sales roles, including location scope and denied results.
5. Run target-host smoke checks for POS, receiving/transfers/requisitions, returns, finance/ledger/AP/AR/GL, HR/payroll, permissions and System Health; check PHP/server/browser console logs.
6. Verify backup restore and rollback; run the GitHub CI/security workflow against a reconciled source branch.

The live website did not load from this session, GitHub access to the canonical repository is read-only, no deployment was run, and full target-host business/database acceptance has not been evidenced. Therefore the package is described as a **local update candidate**, not production-certified.
