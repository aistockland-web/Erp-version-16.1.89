# Stockland Ethiopia ERP 16.1.84 — Deep Code-Level Audit

**Disposition:** Locally validated cumulative WordPress installer. Exact-version GitHub CI and authenticated production acceptance remain pending; this release was not deployed.

## Package identity

- Installer: `STOCKLAND_ERP_16.1.84_CANONICAL_WORDPRESS_UPDATE.zip`
- Size: 1,038,399 bytes
- SHA-256: `9f0295af89311e7a1c4f861ec3f7bc54db071fd143390462942d6488e9f464bf`
- Canonical 16.1.83 baseline: `STOCKLAND_ERP_16.1.83_CANONICAL_WORDPRESS_UPDATE.zip`
- Baseline SHA-256: `9def43e31f9db0dc85638dc7727c184a3db0c8dec968bd29327a3afca6855f1a`
- ZIP CRC integrity: pass; one root `stockland-erp-app/`, 72 files.

## Dashboard update

The supplied screenshot was used as visual direction for the command center. The rebuilt dashboard groups existing ERP data into a welcome/date row, four KPI cards, posted sales trend/category mix, role-scoped quick actions, low-stock alerts, authorized-location stock summary, workflow activity, operational queue, recent transactions and an apparel banner. It uses existing data-binding targets for dashboard bootstrap/insights/notifications; sample design numbers were used only by the synthetic browser harness and are not hardcoded into production rendering.

The tablet breakpoint now switches the analytics workspace to one column at <=1100px; Chromium previously measured a compressed ~426px chart column next to a 275px rail at 1024px. The header controls also now compact at 1400–1600px and switch to icon-only labels on narrow mobile widths to avoid search/action overlap while keeping buttons and aria labels in place.

## Files changed

The release compared byte-for-byte to the canonical 16.1.83 installer has the same 72-file inventory. Exactly 14 files differ:

- `README.md`
- `RELEASE_MANIFEST.json`
- `assets/app.css`
- `assets/app.js`
- `assets/app.min.css`
- `assets/css/01-foundation.css`
- `assets/css/02-shell-navigation.css`
- `assets/css/03-content-data-components.css`
- `assets/css/04-overlays-workflows.css`
- `assets/css/05-responsive-layout.css`
- `assets/css/06-operational-guards.css`
- `assets/css/modules.json`
- `includes/class-stockland-frontend.php`
- `stockland-inventory.php`

Only the plugin main file and `includes/class-stockland-frontend.php` changed among PHP files; changes are limited to plugin release identity and route/cache version. The other 45 PHP files remain byte-identical. Schema markers remain Core `16.1.1`, Accounting `16.1.15`, HR `16.1.3`, DB `16.1.1`; table contract remains 29 + 16 + 4 = 49, no new table.

## Local test evidence

- PHP syntax: 47/47 pass.
- Payroll/System Health: 22/22 assertions pass; v3 PAYE policy/regression preserved.
- Notification renderer: 15/15 pass.
- Payroll preview: 6 assertions pass.
- Release invariants: 16/16 pass.
- PostCSS parses app.css, app.min.css and Bootstrap CSS; six CSS modules compile deterministically; minified CSS matches normalized source.
- JavaScript syntax: `assets/app.js` and `assets/pwa.js` pass.
- ZIP contains exactly the released source-tree bytes under one plugin root; no QA scripts, `.git`, vendor or node_modules included.
- Chromium synthetic-data smoke: 12 viewport widths from 320 to 1920px; zero document overflow, zero page/console errors, 10/10 dashboard binding/navigation checks passed, and print media retained transaction rows. QA screenshots use mocked API values and are previews only.

## Preserved behavior and data contract

All backend PHP business logic outside release/cache markers is unchanged. The release does not modify roles/capabilities, POS calculation/posting, stock ledger, receiving, requisitions/transfers, accounting/AP/AR/GL, payroll formula, audit log semantics, REST route permissions or SOP transitions. No data migration, demo records, historical transaction rewrite or live write was performed. Existing Workspace removal, non-sticky headings, spreadsheet-style product/inventory/report CSS and responsive print corrections from 16.1.82/16.1.83 remain.

## Acceptance boundary

Exact 16.1.84 GitHub Actions/security scans have not run because the connected canonical GitHub integration is read-only. The live WordPress/MariaDB host was not accessed or changed; no live deep-integrity scan, authenticated role E2E, backup restore or rollback was executed. Production acceptance remains pending. Before upload, back up plugin files and the database and verify restore. Install in-place, verify the installed version/checksum, run System Health → Deep Integrity Audit, and then test representative role workflows on staging or during an approved maintenance window.
