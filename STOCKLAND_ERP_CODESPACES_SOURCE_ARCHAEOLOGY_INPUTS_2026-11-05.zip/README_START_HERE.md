# Stockland ERP source archaeology input bundle — 5 Nov 2026

This is a comparison/intake archive for the Codespaces agent. It is **not** a production installer and must not be uploaded to WordPress as a plugin.

## Main recovered CI installers

- 16.1.95: inner installer `recovered-ci-installers/STOCKLAND_ERP_16.1.95_CANONICAL_WORDPRESS_UPDATE.zip`; SHA-256 `494e777247508d009dfdb216c9607bb1bc96717197e94a0e8ad3459b7cc81625`.
- 16.2.9: inner candidate `recovered-ci-installers/STOCKLAND_ERP_16.2.9_HR_PAYROLL_CANDIDATE.zip`; SHA-256 `c9f6459c71087575d8554e599a1ed5025a9e21655f24886c933232ac194d9c01`.
- 16.3.0: inner candidate `recovered-ci-installers/STOCKLAND_ERP_16.3.0_HRX_WORDPRESS_PLUGIN.zip`; SHA-256 `f48993499e7664c45a079595af8efedbd5881728952cf019428f5db2d1872412`.

Each inner installer was extracted from its named GitHub Actions artifact, SHA-256 checked against its embedded sidecar, and tested for ZIP CRC integrity and one `stockland-erp-app/` root.

## Historical Library material

`library-packages/` contains the recovered 16.1.79–16.1.84 source and installer ZIPs. `evidence/` contains selected 16.1.84–16.1.93 audits/QA/build receipts. `ci-artifacts/` preserves the original outer Actions artifact ZIPs and their included receipts/test outputs.

## Not present / not independently verified

- 16.2.13 installed package: exact binary was not present in the current Library intake. Owner upload required.
- 16.3.1 local ZIP: its previous QA record and claimed SHA exist in project history, but the exact ZIP was not recoverable for independent hashing.
- 16.1.101 ZIP/resource package: the PR #49 source branch is still available on GitHub, closed/unmerged; do not treat it as cumulative or assume it contains the real 24 SOP documents. The PR branch tree audit found no DOCX/PDF resource files.
- `/Stockland optimizatio/ERP 16.2.10 source/` was checked and is empty.

See the companion master handover Markdown for source lineage, risks, operating requirements, CI gates and owner actions. `SHA256SUMS.txt` inventories every file in this archive other than the checksum file itself.
