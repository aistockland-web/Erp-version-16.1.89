<?php
/**
 * Additive HR/payroll replacement domain for Stockland ERP.
 *
 * This module deliberately does not mutate the legacy four HR/payroll tables.
 * Its normalized, versioned tables are authoritative only after the replacement
 * has been reviewed and cut over. Statutory rules are fail-closed by default.
 *
 * @package Stockland_ERP
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_HRX {
	const SCHEMA_VERSION = '0.9.4-review-candidate';
	const TABLE_PREFIX = 'stock_hrx_';

	/** Return the complete, additive table contract. */
	public static function schema() {
		global $wpdb;
		$p = $wpdb->prefix . self::TABLE_PREFIX;
		$c = $wpdb->get_charset_collate();
		$base = "id bigint(20) unsigned NOT NULL AUTO_INCREMENT, status varchar(32) NOT NULL DEFAULT 'DRAFT', row_version bigint(20) unsigned NOT NULL DEFAULT 1, created_by bigint(20) unsigned NOT NULL DEFAULT 0, updated_by bigint(20) unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY  (id), KEY status (status), KEY created_at (created_at)";
		$defs = array(
			'org_units' => "code varchar(40) NOT NULL, name varchar(190) NOT NULL, parent_id bigint(20) unsigned NULL, unit_type varchar(32) NOT NULL DEFAULT 'DEPARTMENT', location_id bigint(20) unsigned NULL, cost_centre_code varchar(40) NULL, effective_from date NULL, effective_to date NULL, $base, UNIQUE KEY code (code), KEY parent_id (parent_id), KEY location_id (location_id)",
			'positions' => "code varchar(40) NOT NULL, title varchar(190) NOT NULL, org_unit_id bigint(20) unsigned NULL, grade_code varchar(40) NULL, manager_position_id bigint(20) unsigned NULL, location_id bigint(20) unsigned NULL, headcount integer NOT NULL DEFAULT 1, effective_from date NULL, effective_to date NULL, $base, UNIQUE KEY code (code), KEY org_unit_id (org_unit_id), KEY location_id (location_id)",
			'workforce_plans' => "plan_year smallint NOT NULL, org_unit_id bigint(20) unsigned NULL, approved_headcount integer NOT NULL DEFAULT 0, requested_headcount integer NOT NULL DEFAULT 0, cost_budget decimal(16,2) NOT NULL DEFAULT 0.00, currency char(3) NOT NULL DEFAULT 'ETB', approval_note text NULL, submitted_at datetime NULL, approved_at datetime NULL, approved_by bigint(20) unsigned NULL, $base, KEY plan_year (plan_year), KEY org_unit_id (org_unit_id)",
			'vacancies' => "vacancy_code varchar(48) NOT NULL, title varchar(190) NOT NULL, position_id bigint(20) unsigned NULL, workforce_plan_id bigint(20) unsigned NULL, location_id bigint(20) unsigned NULL, headcount integer NOT NULL DEFAULT 1, opened_on date NULL, close_on date NULL, budget_reference varchar(120) NULL, approval_note text NULL, approved_by bigint(20) unsigned NULL, $base, UNIQUE KEY vacancy_code (vacancy_code), KEY position_id (position_id), KEY location_id (location_id)",
			'persons' => "person_code varchar(48) NOT NULL, given_name varchar(100) NOT NULL, family_name varchar(100) NOT NULL, email varchar(190) NULL, phone varchar(60) NULL, country_code char(2) NULL, birth_date date NULL, privacy_notice_version varchar(48) NULL, lawful_purpose varchar(120) NULL, retention_until date NULL, pii_access_class varchar(24) NOT NULL DEFAULT 'RESTRICTED', $base, UNIQUE KEY person_code (person_code), KEY email (email), KEY retention_until (retention_until)",
			'applications' => "application_code varchar(48) NOT NULL, person_id bigint(20) unsigned NOT NULL, vacancy_id bigint(20) unsigned NOT NULL, stage varchar(32) NOT NULL DEFAULT 'SUBMITTED', applied_at datetime NOT NULL, disposition_reason text NULL, human_recommendation varchar(24) NULL, human_recommendation_by bigint(20) unsigned NULL, decision_by bigint(20) unsigned NULL, decision_at datetime NULL, $base, UNIQUE KEY application_code (application_code), KEY person_id (person_id), KEY vacancy_id (vacancy_id), KEY stage (stage)",
			'interviews' => "application_id bigint(20) unsigned NOT NULL, interview_stage varchar(64) NOT NULL, interviewer_user_id bigint(20) unsigned NOT NULL, scorecard_version varchar(48) NOT NULL, score decimal(7,2) NULL, recommendation varchar(24) NULL, notes text NULL, held_at datetime NULL, $base, KEY application_id (application_id), KEY interviewer_user_id (interviewer_user_id)",
			'offers' => "offer_code varchar(48) NOT NULL, application_id bigint(20) unsigned NOT NULL, offer_version smallint NOT NULL DEFAULT 1, position_id bigint(20) unsigned NULL, proposed_start date NULL, expires_on date NULL, compensation_reference varchar(120) NULL, terms_hash char(64) NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, accepted_at datetime NULL, declined_at datetime NULL, $base, UNIQUE KEY offer_code (offer_code), KEY application_id (application_id)",
			'employments' => "employment_code varchar(48) NOT NULL, person_id bigint(20) unsigned NOT NULL, employee_no varchar(48) NOT NULL, position_id bigint(20) unsigned NULL, org_unit_id bigint(20) unsigned NULL, location_id bigint(20) unsigned NULL, manager_user_id bigint(20) unsigned NULL, employment_type varchar(32) NOT NULL DEFAULT 'EMPLOYEE', start_date date NULL, end_date date NULL, probation_end_date date NULL, payroll_group varchar(48) NULL, legal_employer_code varchar(48) NULL, $base, UNIQUE KEY employment_code (employment_code), UNIQUE KEY employee_no (employee_no), KEY person_id (person_id), KEY location_id (location_id), KEY start_date (start_date)",
			'contracts' => "employment_id bigint(20) unsigned NOT NULL, version_no integer NOT NULL DEFAULT 1, contract_type varchar(48) NOT NULL, start_date date NULL, end_date date NULL, terms_hash char(64) NULL, private_document_ref varchar(255) NULL, document_sha256 char(64) NULL, verification_status varchar(24) NOT NULL DEFAULT 'PENDING', signed_at datetime NULL, verified_by bigint(20) unsigned NULL, verified_at datetime NULL, $base, UNIQUE KEY employment_version (employment_id,version_no), KEY employment_id (employment_id)",
			'onboarding_tasks' => "employment_id bigint(20) unsigned NOT NULL, task_code varchar(48) NOT NULL, title varchar(190) NOT NULL, mandatory tinyint(1) NOT NULL DEFAULT 1, due_date date NULL, completed_at datetime NULL, evidence_ref varchar(255) NULL, completed_by bigint(20) unsigned NULL, $base, UNIQUE KEY employment_task (employment_id,task_code), KEY due_date (due_date)",
			'employee_events' => "employment_id bigint(20) unsigned NOT NULL, event_type varchar(48) NOT NULL, effective_date date NOT NULL, from_value varchar(255) NULL, to_value varchar(255) NULL, reason text NULL, evidence_ref varchar(255) NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, $base, KEY employment_date (employment_id,effective_date), KEY event_type (event_type)",
			'shift_assignments' => "employment_id bigint(20) unsigned NOT NULL, shift_code varchar(48) NOT NULL, start_date date NOT NULL, end_date date NULL, scheduled_weekly_minutes integer NOT NULL DEFAULT 0, timezone varchar(64) NOT NULL DEFAULT 'Africa/Addis_Ababa', published_by bigint(20) unsigned NULL, published_at datetime NULL, $base, KEY employment_dates (employment_id,start_date,end_date), KEY shift_code (shift_code)",
			'time_events' => "employment_id bigint(20) unsigned NOT NULL, event_date date NOT NULL, event_type varchar(32) NOT NULL, start_at datetime NULL, end_at datetime NULL, minutes integer NOT NULL DEFAULT 0, source_reference varchar(190) NULL, correction_of_id bigint(20) unsigned NULL, correction_reason text NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, $base, KEY employment_date (employment_id,event_date), KEY event_type (event_type)",
			'leave_policies' => "leave_code varchar(48) NOT NULL, title varchar(190) NOT NULL, accrual_method varchar(48) NOT NULL, annual_entitlement decimal(10,3) NOT NULL DEFAULT 0, carry_forward_cap decimal(10,3) NULL, minimum_service_days integer NOT NULL DEFAULT 0, effective_from date NOT NULL, effective_to date NULL, legal_rule_id bigint(20) unsigned NULL, $base, UNIQUE KEY leave_code (leave_code), KEY effective_dates (effective_from,effective_to)",
			'leave_requests' => "employment_id bigint(20) unsigned NOT NULL, leave_policy_id bigint(20) unsigned NOT NULL, start_date date NOT NULL, end_date date NOT NULL, quantity_days decimal(10,3) NOT NULL DEFAULT 0, reason text NULL, evidence_ref varchar(255) NULL, decision_by bigint(20) unsigned NULL, decision_at datetime NULL, decision_note text NULL, $base, KEY employment_dates (employment_id,start_date,end_date), KEY leave_policy_id (leave_policy_id)",
			'leave_movements' => "employment_id bigint(20) unsigned NOT NULL, leave_policy_id bigint(20) unsigned NOT NULL, effective_date date NOT NULL, movement_type varchar(24) NOT NULL, quantity_days decimal(10,3) NOT NULL, source_type varchar(48) NOT NULL, source_id bigint(20) unsigned NOT NULL, balance_after decimal(10,3) NULL, approved_by bigint(20) unsigned NULL, $base, KEY balance_index (employment_id,leave_policy_id,effective_date), KEY source (source_type,source_id)",
			'compensation_assignments' => "employment_id bigint(20) unsigned NOT NULL, effective_from date NOT NULL, effective_to date NULL, base_salary decimal(16,2) NOT NULL DEFAULT 0.00, pay_frequency varchar(24) NOT NULL DEFAULT 'MONTHLY', currency char(3) NOT NULL DEFAULT 'ETB', base_tax_status varchar(24) NOT NULL DEFAULT 'REVIEW_REQUIRED', base_pension_status varchar(24) NOT NULL DEFAULT 'REVIEW_REQUIRED', source_contract_id bigint(20) unsigned NULL, reason text NULL, submitted_at datetime NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, $base, KEY employment_effective (employment_id,effective_from,effective_to), KEY status_effective (status,effective_from,effective_to)",
			'compensation_items' => "assignment_id bigint(20) unsigned NOT NULL, component_code varchar(48) NOT NULL, label varchar(190) NOT NULL, component_type varchar(24) NOT NULL DEFAULT 'EARNING', amount decimal(16,2) NOT NULL DEFAULT 0.00, frequency varchar(24) NOT NULL DEFAULT 'MONTHLY', tax_status varchar(24) NOT NULL DEFAULT 'REVIEW_REQUIRED', pension_status varchar(24) NOT NULL DEFAULT 'REVIEW_REQUIRED', legal_rule_id bigint(20) unsigned NULL, evidence_reference varchar(255) NULL, $base, KEY assignment_id (assignment_id), KEY component_code (component_code)",
			'statutory_rules' => "rule_code varchar(64) NOT NULL, title varchar(190) NOT NULL, jurisdiction varchar(64) NOT NULL DEFAULT 'ET', instrument_title varchar(190) NOT NULL, article_clause varchar(190) NOT NULL, source_url varchar(500) NOT NULL, source_attachment_id bigint(20) unsigned NOT NULL DEFAULT 0, source_sha256 char(64) NOT NULL, publication_date date NULL, effective_from date NOT NULL, effective_to date NULL, rule_kind varchar(32) NOT NULL, calculation_method varchar(48) NOT NULL, rule_parameters_json longtext NOT NULL, legal_reviewer_id bigint(20) unsigned NULL, legal_reviewed_at datetime NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, $base, UNIQUE KEY rule_version (rule_code,effective_from), KEY rule_effective (rule_kind,status,effective_from,effective_to)",
			'payroll_runs' => "run_code varchar(48) NOT NULL, period_key char(7) NOT NULL, start_date date NOT NULL, end_date date NOT NULL, cutoff_at datetime NULL, input_snapshot_hash char(64) NULL, rule_snapshot_hash char(64) NULL, employee_count integer NOT NULL DEFAULT 0, gross_total decimal(16,2) NOT NULL DEFAULT 0.00, taxable_total decimal(16,2) NOT NULL DEFAULT 0.00, paye_total decimal(16,2) NOT NULL DEFAULT 0.00, employee_pension_total decimal(16,2) NOT NULL DEFAULT 0.00, employer_pension_total decimal(16,2) NOT NULL DEFAULT 0.00, other_deduction_total decimal(16,2) NOT NULL DEFAULT 0.00, net_total decimal(16,2) NOT NULL DEFAULT 0.00, employer_cost_total decimal(16,2) NOT NULL DEFAULT 0.00, prepared_by bigint(20) unsigned NOT NULL, reviewer_id bigint(20) unsigned NULL, reviewed_at datetime NULL, review_note text NULL, owner_approved_by bigint(20) unsigned NULL, owner_approved_at datetime NULL, journal_id bigint(20) unsigned NULL, posted_at datetime NULL, payment_status varchar(32) NOT NULL DEFAULT 'NOT_STARTED', notes text NULL, $base, UNIQUE KEY run_code (run_code), UNIQUE KEY period_key (period_key), KEY status_period (status,period_key)",
			'payroll_lines' => "payroll_run_id bigint(20) unsigned NOT NULL, employment_id bigint(20) unsigned NOT NULL, employee_no varchar(48) NOT NULL, employee_name_snapshot varchar(220) NOT NULL, source_snapshot_hash char(64) NOT NULL, gross_pay decimal(16,2) NOT NULL DEFAULT 0.00, taxable_income decimal(16,2) NOT NULL DEFAULT 0.00, pensionable_income decimal(16,2) NOT NULL DEFAULT 0.00, paye decimal(16,2) NOT NULL DEFAULT 0.00, employee_pension decimal(16,2) NOT NULL DEFAULT 0.00, employer_pension decimal(16,2) NOT NULL DEFAULT 0.00, other_deductions decimal(16,2) NOT NULL DEFAULT 0.00, net_pay decimal(16,2) NOT NULL DEFAULT 0.00, employer_cost decimal(16,2) NOT NULL DEFAULT 0.00, calculation_trace longtext NOT NULL, $base, UNIQUE KEY run_employment (payroll_run_id,employment_id), KEY employment_id (employment_id)",
			'payroll_line_items' => "payroll_line_id bigint(20) unsigned NOT NULL, component_code varchar(48) NOT NULL, label varchar(190) NOT NULL, item_type varchar(24) NOT NULL, amount decimal(16,2) NOT NULL DEFAULT 0.00, tax_classification varchar(24) NOT NULL, pension_classification varchar(24) NOT NULL, rule_id bigint(20) unsigned NULL, source_type varchar(48) NULL, source_id bigint(20) unsigned NULL, calculation_trace longtext NULL, $base, KEY payroll_line_id (payroll_line_id), KEY component_code (component_code)",
			'payout_batches' => "batch_code varchar(48) NOT NULL, payroll_run_id bigint(20) unsigned NOT NULL, channel varchar(24) NOT NULL, currency char(3) NOT NULL DEFAULT 'ETB', amount_total decimal(16,2) NOT NULL DEFAULT 0.00, external_reference varchar(190) NULL, journal_id bigint(20) unsigned NULL, submitted_at datetime NULL, reconciled_at datetime NULL, reconciled_by bigint(20) unsigned NULL, $base, UNIQUE KEY batch_code (batch_code), KEY payroll_run_id (payroll_run_id)",
			'payout_results' => "payout_batch_id bigint(20) unsigned NOT NULL, payroll_line_id bigint(20) unsigned NOT NULL, employment_id bigint(20) unsigned NOT NULL, amount decimal(16,2) NOT NULL DEFAULT 0.00, external_reference varchar(190) NULL, paid_at datetime NULL, failure_reason text NULL, $base, UNIQUE KEY batch_line (payout_batch_id,payroll_line_id), KEY result_status (status), KEY employment_id (employment_id)",
			'remittances' => "remittance_type varchar(32) NOT NULL, period_key char(7) NOT NULL, legal_rule_id bigint(20) unsigned NULL, amount_due decimal(16,2) NOT NULL DEFAULT 0.00, amount_paid decimal(16,2) NOT NULL DEFAULT 0.00, due_date date NULL, submitted_at datetime NULL, paid_at datetime NULL, official_receipt_ref varchar(190) NULL, journal_id bigint(20) unsigned NULL, reconciled_at datetime NULL, reconciled_by bigint(20) unsigned NULL, reconciliation_note text NULL, $base, KEY type_period (remittance_type,period_key), KEY due_date (due_date)",
			'separation_cases' => "case_code varchar(48) NOT NULL, employment_id bigint(20) unsigned NOT NULL, separation_type varchar(32) NOT NULL, reason text NOT NULL, notice_date date NULL, last_worked_date date NULL, effective_date date NOT NULL, hold_reason text NULL, clearance_status varchar(32) NOT NULL DEFAULT 'PENDING', final_payroll_run_id bigint(20) unsigned NULL, final_statement_ref varchar(255) NULL, approved_by bigint(20) unsigned NULL, approved_at datetime NULL, settled_at datetime NULL, $base, UNIQUE KEY case_code (case_code), KEY employment_id (employment_id), KEY effective_date (effective_date)",
			'individual_payees' => "payee_code varchar(48) NOT NULL, payee_type varchar(32) NOT NULL, legal_name varchar(220) NOT NULL, country_code char(2) NULL, tin_reference varchar(100) NULL, licence_reference varchar(100) NULL, residency_status varchar(32) NULL, category_review_status varchar(24) NOT NULL DEFAULT 'REVIEW_REQUIRED', reviewed_by bigint(20) unsigned NULL, reviewed_at datetime NULL, evidence_reference varchar(255) NULL, $base, UNIQUE KEY payee_code (payee_code), KEY payee_type (payee_type)",
			'payee_engagements' => "engagement_code varchar(48) NOT NULL, payee_id bigint(20) unsigned NOT NULL, engagement_type varchar(32) NOT NULL, campaign_reference varchar(100) NULL, description text NOT NULL, start_date date NULL, end_date date NULL, deliverable_status varchar(24) NOT NULL DEFAULT 'PENDING', accepted_by bigint(20) unsigned NULL, accepted_at datetime NULL, cash_amount decimal(16,2) NOT NULL DEFAULT 0.00, in_kind_amount decimal(16,2) NOT NULL DEFAULT 0.00, withholding_decision varchar(32) NOT NULL DEFAULT 'REVIEW_REQUIRED', statutory_rule_id bigint(20) unsigned NULL, finance_reference varchar(190) NULL, $base, UNIQUE KEY engagement_code (engagement_code), KEY payee_id (payee_id)",
			'resource_documents' => "doc_code varchar(48) NOT NULL, title varchar(190) NOT NULL, document_version varchar(48) NOT NULL, language_code char(5) NOT NULL DEFAULT 'en', access_class varchar(24) NOT NULL DEFAULT 'HR_ONLY', private_file_ref varchar(255) NOT NULL, file_sha256 char(64) NOT NULL, mime_type varchar(120) NOT NULL, published_at datetime NULL, approved_by bigint(20) unsigned NULL, $base, UNIQUE KEY doc_version (doc_code,document_version), KEY access_status (access_class,status)",
			'social_snapshots' => "platform varchar(32) NOT NULL, account_label varchar(190) NOT NULL, as_of_date date NOT NULL, metric_name varchar(80) NOT NULL, metric_value decimal(18,3) NOT NULL DEFAULT 0, source_reference varchar(255) NOT NULL, evidence_sha256 char(64) NULL, captured_by bigint(20) unsigned NOT NULL, notes text NULL, $base, KEY account_date (platform,account_label,as_of_date), KEY metric_name (metric_name)",
			'audit_events' => "entity_type varchar(48) NOT NULL, entity_id bigint(20) unsigned NOT NULL, action varchar(48) NOT NULL, from_status varchar(32) NULL, to_status varchar(32) NULL, actor_id bigint(20) unsigned NOT NULL, correlation_id varchar(80) NULL, before_sha256 char(64) NULL, after_sha256 char(64) NULL, metadata_json text NULL, $base, KEY entity (entity_type,entity_id), KEY actor_id (actor_id)",
			'idempotency_requests' => "request_key varchar(100) NOT NULL, actor_id bigint(20) unsigned NOT NULL, route_key varchar(190) NOT NULL, entity_type varchar(48) NOT NULL, entity_id bigint(20) unsigned NOT NULL DEFAULT 0, request_sha256 char(64) NOT NULL, response_sha256 char(64) NULL, $base, UNIQUE KEY idempotency_actor_route (request_key,actor_id,route_key)"
		);
		$out = array();
		foreach ( $defs as $key => $columns ) {
			// dbDelta parses one column/key per line. A single-line definition is read as
			// one column on replay and corrupts defaults (e.g. DEFAULT 'ETB' on plan_year),
			// so split on top-level commas and normalize integer widths to the MariaDB reported form so replays are no-ops.
			$columns      = preg_replace( array( '/\b(?:integer|int)\b(?!\()/i', '/\bsmallint\b(?!\()/i', '/\btinyint\b(?!\()/i' ), array( 'int(11)', 'smallint(6)', 'tinyint(4)' ), $columns );
			$parts        = array();
			$depth        = 0;
			$in_quote     = false;
			$buffer       = '';
			$column_len   = strlen( $columns );
			for ( $i = 0; $i < $column_len; $i++ ) {
				$ch = $columns[ $i ];
				if ( "'" === $ch ) {
					$in_quote = ! $in_quote;
				} elseif ( ! $in_quote && '(' === $ch ) {
					++$depth;
				} elseif ( ! $in_quote && ')' === $ch ) {
					--$depth;
				}
				if ( ',' === $ch && 0 === $depth && ! $in_quote ) {
					$parts[] = trim( $buffer );
					$buffer  = '';
					continue;
				}
				$buffer .= $ch;
			}
			if ( '' !== trim( $buffer ) ) {
				$parts[] = trim( $buffer );
			}
			$out[ $key ] = "CREATE TABLE {$p}{$key} (\n" . implode( ",\n", $parts ) . "\n) {$c};";
		}
		return $out;
	}

	/** Return expected fully-prefixed names. */
	public static function table_names() {
		global $wpdb;
		$out = array();
		foreach ( array_keys( self::schema() ) as $key ) { $out[] = $wpdb->prefix . self::TABLE_PREFIX . $key; }
		return $out;
	}

	/** Idempotent, additive-only installation. Legacy HR tables are never touched. */
	public static function install() {
		global $wpdb;
		if ( ! current_user_can( 'stockland_install_schema' ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'hrx_forbidden', 'Only an authorized schema administrator may install the HR replacement schema.', array( 'status' => 403 ) );
		}
		if ( ! function_exists( 'dbDelta' ) ) { require_once ABSPATH . 'wp-admin/includes/upgrade.php'; }
		foreach ( self::schema() as $key => $sql ) {
			$wpdb->last_error = '';
			dbDelta( $sql );
			if ( ! empty( $wpdb->last_error ) || ! self::table_exists( $key ) ) {
				return new WP_Error( 'hrx_schema_install_failed', 'HR replacement schema could not verify table: ' . $key . ( $wpdb->last_error ? ' — ' . $wpdb->last_error : '' ), array( 'status' => 500 ) );
			}
		}
		update_option( 'stockland_hrx_schema_version', self::SCHEMA_VERSION, false );
		return array( 'installed' => true, 'version' => self::SCHEMA_VERSION, 'tables' => count( self::schema() ), 'verified' => self::ready(), 'legacy_tables_changed' => false );
	}

	/** Validate schema using physical database table presence. */
	public static function ready() {
		if ( ! function_exists( 'get_option' ) || get_option( 'stockland_hrx_schema_version', '' ) !== self::SCHEMA_VERSION ) { return false; }
		foreach ( array_keys( self::schema() ) as $key ) { if ( ! self::table_exists( $key ) ) { return false; } }
		return true;
	}

	public static function table_exists( $key ) {
		global $wpdb;
		if ( ! array_key_exists( $key, self::schema() ) ) { return false; }
		$name = $wpdb->prefix . self::TABLE_PREFIX . $key;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) );
	}

	public static function table( $key ) {
		global $wpdb;
		if ( ! array_key_exists( $key, self::schema() ) ) { throw new InvalidArgumentException( 'Unknown HR replacement table.' ); }
		return $wpdb->prefix . self::TABLE_PREFIX . $key;
	}

	/** Safe UTC-ish WordPress timestamp; storage conventions follow the host. */
	public static function now() { return current_time( 'mysql', true ); }

	/** Append a privacy-minimized audit event with before/after hashes. */
	public static function audit( $entity_type, $entity_id, $action, $from, $to, $before = null, $after = null, $metadata = array(), $correlation = null ) {
		global $wpdb;
		$table = self::table( 'audit_events' );
		$row = array(
			'entity_type' => sanitize_key( $entity_type ), 'entity_id' => absint( $entity_id ),
			'action' => sanitize_key( $action ), 'from_status' => $from ? sanitize_text_field( $from ) : null,
			'to_status' => $to ? sanitize_text_field( $to ) : null, 'actor_id' => get_current_user_id(),
			'correlation_id' => $correlation ? sanitize_text_field( $correlation ) : null,
			'before_sha256' => null === $before ? null : hash( 'sha256', wp_json_encode( $before ) ),
			'after_sha256' => null === $after ? null : hash( 'sha256', wp_json_encode( $after ) ),
			'metadata_json' => wp_json_encode( $metadata ), 'status' => 'RECORDED', 'row_version' => 1,
			'created_by' => get_current_user_id(), 'updated_by' => get_current_user_id(),
			'created_at' => self::now(), 'updated_at' => self::now(),
		);
		return false !== $wpdb->insert( $table, $row );
	}

	/** Return whether a money value is a non-negative decimal. */
	public static function valid_money( $value ) {
		try { return Stockland_Money::minor( $value ) >= 0; } catch ( Throwable $e ) { return false; }
	}

	/** Exact progressive marginal tax; thresholds and rates come only from an approved rule. */
	public static function progressive_tax_minor( $taxable_minor, $bands ) {
		$income = max( 0, (int) $taxable_minor );
		$lower = 0;
		$tax_numerator = 0;
		if ( ! is_array( $bands ) || empty( $bands ) ) { throw new InvalidArgumentException( 'An approved progressive tax band set is required.' ); }
		$last_index = count( $bands ) - 1;
		$last_band = $bands[$last_index];
		if ( ! is_array( $last_band ) || ! array_key_exists( 'up_to_minor', $last_band ) || null !== $last_band['up_to_minor'] ) { throw new InvalidArgumentException( 'Tax rule must have an open-ended final band.' ); }
		foreach ( $bands as $index => $band ) {
			if ( ! is_array( $band ) || ! array_key_exists( 'rate_bps', $band ) || ! is_numeric( $band['rate_bps'] ) || (int) $band['rate_bps'] < 0 || (int) $band['rate_bps'] > 10000 ) {
				throw new InvalidArgumentException( 'Tax rule contains an invalid band.' );
			}
			if ( ! array_key_exists( 'up_to_minor', $band ) ) { throw new InvalidArgumentException( 'Every tax band must declare its upper boundary or explicitly be open-ended.' ); }
			$upper = null !== $band['up_to_minor'] ? (int) $band['up_to_minor'] : null;
			if ( null === $upper && $index !== $last_index ) { throw new InvalidArgumentException( 'Only the final tax band may be open-ended.' ); }
			if ( null !== $upper && ( $upper <= $lower || $upper < 0 ) ) { throw new InvalidArgumentException( 'Tax bands must be strictly increasing.' ); }
			$portion = null === $upper ? max( 0, $income - $lower ) : max( 0, min( $income, $upper ) - $lower );
			if ( $portion > 0 ) { $tax_numerator += $portion * (int) $band['rate_bps']; }
			if ( null === $upper ) { break; }
			$lower = $upper;
		}
		if ( $income > 0 && ! array_key_exists( 'up_to_minor', $last_band ) ) { throw new InvalidArgumentException( 'Tax rule has no open-ended final band.' ); }
		// Accumulate every marginal slice first, then round once to minor currency units.
		return self::rounded_ratio( $tax_numerator, 10000 );
	}

	/** Exact half-up integer ratio used for percentage calculations. */
	public static function rounded_ratio( $numerator, $denominator ) {
		if ( $denominator <= 0 ) { throw new InvalidArgumentException( 'Rate denominator must be positive.' ); }
		return intdiv( (int) $numerator + intdiv( (int) $denominator, 2 ), (int) $denominator );
	}

	/** Pure transition guard. More specific resource actions additionally enforce role/evidence. */
	public static function transition_allowed( $resource, $from, $to ) {
		$flows = array(
			'workforce-plans' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'REJECTED' => array( 'DRAFT' ), 'APPROVED' => array() ),
			'vacancies' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array( 'OPEN' ), 'OPEN' => array( 'ON_HOLD', 'CLOSED' ), 'ON_HOLD' => array( 'OPEN', 'CLOSED' ), 'REJECTED' => array( 'DRAFT' ), 'CLOSED' => array() ),
			'time-events' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array(), 'REJECTED' => array( 'DRAFT' ) ),
			'shift-assignments' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'PUBLISHED', 'REJECTED' ), 'PUBLISHED' => array( 'CLOSED' ), 'REJECTED' => array( 'DRAFT' ), 'CLOSED' => array() ),
			'applications' => array( 'SUBMITTED' => array( 'SCREENING', 'WITHDRAWN' ), 'SCREENING' => array( 'INTERVIEW', 'RECOMMENDED', 'REJECTED', 'WITHDRAWN' ), 'INTERVIEW' => array( 'RECOMMENDED', 'REJECTED', 'WITHDRAWN' ), 'RECOMMENDED' => array( 'SELECTED', 'REJECTED' ), 'SELECTED' => array(), 'REJECTED' => array(), 'WITHDRAWN' => array() ),
			'offers' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array( 'SENT' ), 'SENT' => array( 'ACCEPTED', 'DECLINED', 'EXPIRED' ), 'ACCEPTED' => array(), 'DECLINED' => array(), 'EXPIRED' => array(), 'REJECTED' => array() ),
			'employments' => array( 'PENDING_ONBOARDING' => array( 'ACTIVE', 'WITHDRAWN' ), 'ACTIVE' => array( 'SUSPENDED', 'ON_LEAVE', 'EXIT_PENDING' ), 'SUSPENDED' => array( 'ACTIVE', 'EXIT_PENDING' ), 'ON_LEAVE' => array( 'ACTIVE', 'EXIT_PENDING' ), 'EXIT_PENDING' => array( 'ENDED', 'ACTIVE' ), 'ENDED' => array(), 'WITHDRAWN' => array() ),
			'contracts' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'VERIFIED', 'REJECTED' ), 'VERIFIED' => array( 'SIGNED' ), 'SIGNED' => array(), 'REJECTED' => array( 'DRAFT' ) ),
			'compensation-items' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array(), 'REJECTED' => array( 'DRAFT' ) ),
			'onboarding-tasks' => array( 'PENDING' => array( 'IN_PROGRESS', 'WAIVED' ), 'IN_PROGRESS' => array( 'COMPLETED', 'PENDING' ), 'COMPLETED' => array(), 'WAIVED' => array() ),
			'leave-requests' => array( 'DRAFT' => array( 'SUBMITTED', 'CANCELLED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED', 'CANCELLED' ), 'APPROVED' => array( 'CANCELLED' ), 'REJECTED' => array(), 'CANCELLED' => array() ),
			'compensation-assignments' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array(), 'REJECTED' => array( 'DRAFT' ) ),
			'statutory-rules' => array( 'DRAFT' => array( 'LEGAL_REVIEW', 'REJECTED' ), 'LEGAL_REVIEW' => array( 'APPROVED', 'REJECTED' ), 'APPROVED' => array( 'RETIRED' ), 'REJECTED' => array( 'DRAFT' ), 'RETIRED' => array() ),
			'payroll-runs' => array( 'DRAFT' => array( 'INPUTS_FROZEN' ), 'INPUTS_FROZEN' => array( 'CALCULATED', 'EXCEPTIONS_PENDING' ), 'CALCULATED' => array( 'REVIEWED', 'EXCEPTIONS_PENDING' ), 'REVIEWED' => array( 'SUBMITTED' ), 'EXCEPTIONS_PENDING' => array( 'INPUTS_FROZEN' ), 'SUBMITTED' => array( 'OWNER_APPROVED', 'REJECTED' ), 'REJECTED' => array( 'DRAFT' ), 'OWNER_APPROVED' => array( 'POSTED' ), 'POSTED' => array( 'PAYMENT_IN_PROGRESS' ), 'PAYMENT_IN_PROGRESS' => array( 'SETTLED', 'PARTIALLY_FAILED' ), 'PARTIALLY_FAILED' => array( 'PAYMENT_IN_PROGRESS', 'SETTLED' ), 'SETTLED' => array( 'CLOSED' ), 'CLOSED' => array() ),
			'payout-batches' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'PARTIALLY_PAID', 'PAID', 'FAILED' ), 'PARTIALLY_PAID' => array( 'PAID', 'FAILED' ), 'FAILED' => array(), 'PAID' => array( 'RECONCILED' ), 'RECONCILED' => array() ),
			'remittances' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'PAID', 'FAILED' ), 'FAILED' => array( 'SUBMITTED' ), 'PAID' => array( 'RECONCILED' ), 'RECONCILED' => array() ),
			'separation-cases' => array( 'DRAFT' => array( 'REVIEW', 'HELD' ), 'REVIEW' => array( 'APPROVED', 'REJECTED', 'HELD' ), 'HELD' => array( 'REVIEW', 'REJECTED' ), 'APPROVED' => array(), 'REJECTED' => array() ),
			'payee-engagements' => array( 'DRAFT' => array( 'SUBMITTED' ), 'SUBMITTED' => array( 'DELIVERABLE_ACCEPTED', 'REJECTED' ), 'DELIVERABLE_ACCEPTED' => array( 'FINANCE_REVIEW' ), 'FINANCE_REVIEW' => array( 'APPROVED', 'HELD' ), 'HELD' => array( 'FINANCE_REVIEW' ), 'APPROVED' => array() ),
		);
		return isset( $flows[ $resource ][ $from ] ) && in_array( $to, $flows[ $resource ][ $from ], true );
	}
}
