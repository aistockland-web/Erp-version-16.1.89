<?php
/** Additive HR/payroll replacement REST surface. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_REST_HRX extends Stockland_REST_Base {
	private $map = array(
		'org-units'=>'org_units','positions'=>'positions','workforce-plans'=>'workforce_plans','vacancies'=>'vacancies',
		'persons'=>'persons','applications'=>'applications','interviews'=>'interviews','offers'=>'offers','employments'=>'employments',
		'contracts'=>'contracts','onboarding-tasks'=>'onboarding_tasks','employee-events'=>'employee_events','shift-assignments'=>'shift_assignments',
		'time-events'=>'time_events','leave-policies'=>'leave_policies','leave-requests'=>'leave_requests','leave-movements'=>'leave_movements',
		'compensation-assignments'=>'compensation_assignments','compensation-items'=>'compensation_items','statutory-rules'=>'statutory_rules',
		'payroll-runs'=>'payroll_runs','payroll-lines'=>'payroll_lines','payroll-line-items'=>'payroll_line_items','payout-batches'=>'payout_batches','payout-results'=>'payout_results','remittances'=>'remittances','separation-cases'=>'separation_cases','individual-payees'=>'individual_payees',
		'payee-engagements'=>'payee_engagements','resource-documents'=>'resource_documents','social-snapshots'=>'social_snapshots',
	);
	private $payroll = array('payroll-runs','payroll-lines','payroll-line-items','payout-batches','payout-results','remittances');
	private $server_fields = array(
		'id','status','row_version','created_by','updated_by','created_at','updated_at','approved_by','approved_at','submitted_at',
		'owner_approved_by','owner_approved_at','reviewer_id','decision_by','decision_at','human_recommendation_by','signed_at',
		'verified_by','verified_at','completed_by','completed_at','published_by','published_at','accepted_by','accepted_at',
		'legal_reviewer_id','legal_reviewed_at','approved_at','status','verification_status','stage','retention_deleted_at','actor_id','reconciled_by','reconciled_at',
		'paid_at','posted_at','journal_id','reconciled_at','reconciled_by','input_snapshot_hash','rule_snapshot_hash','employee_count','gross_total','taxable_total',
		'amount_paid','official_receipt_ref','paye_total','employee_pension_total','employer_pension_total','other_deduction_total','net_total','employer_cost_total',
		'run_code','employee_no','employee_name_snapshot','source_snapshot_hash','calculation_trace','payroll_run_id','payroll_line_id',
		'payroll_period_id','stage','payment_status','disposition_reason','decision_note','from_status','to_status','before_sha256','after_sha256'
	);

	public function __construct() { add_action( 'stockland_register_rest_routes', array( $this, 'register_routes' ) ); }

	public function register_routes() {
		register_rest_route( self::NAMESPACE_V1, '/hrx/bootstrap', array('methods'=>'GET','callback'=>array($this,'bootstrap'),'permission_callback'=>array($this,'can_view_hrx')) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/install', array('methods'=>'POST','callback'=>array($this,'install_schema'),'permission_callback'=>array($this,'can_install_schema')) );
		// General ERP SOPs are separate from personal employee documents and are served only from an explicit, hash-verified allowlist.
		register_rest_route( self::NAMESPACE_V1, '/hrx/sops', array('methods'=>'GET','callback'=>array($this,'list_sops'),'permission_callback'=>array($this,'can_view_hrx')) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/sops/(?P<code>[A-Za-z0-9\-]+)/download', array('methods'=>'GET','callback'=>array($this,'download_sop'),'permission_callback'=>array($this,'can_view_hrx')) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/(?P<resource>[a-z\-]+)', array(
			array('methods'=>'GET','callback'=>array($this,'list_resource'),'permission_callback'=>array($this,'can_read_resource')),
			array('methods'=>'POST','callback'=>array($this,'create_resource'),'permission_callback'=>array($this,'can_create_resource')),
		) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/(?P<resource>[a-z\-]+)/(?P<id>\d+)', array('methods'=>'GET','callback'=>array($this,'get_resource'),'permission_callback'=>array($this,'can_read_resource')) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/(?P<resource>[a-z\-]+)/(?P<id>\d+)/transition', array('methods'=>'POST','callback'=>array($this,'transition_resource'),'permission_callback'=>array($this,'can_transition_resource')) );
		register_rest_route( self::NAMESPACE_V1, '/hrx/statutory-rules/(?P<id>\d+)/review', array('methods'=>'POST','callback'=>array($this,'review_statutory_rule'),'permission_callback'=>function(){ return current_user_can('stockland_hr_legal_review') ?: new WP_Error('hrx_legal_reviewer_required','Qualified reviewer capability required.',array('status'=>403)); }));
		register_rest_route( self::NAMESPACE_V1, '/hrx/payout-results/(?P<id>\d+)/settle', array('methods'=>'POST','callback'=>array($this,'settle_payout_result'),'permission_callback'=>array($this,'can_payroll_action')));
		register_rest_route( self::NAMESPACE_V1, '/hrx/payout-batches/(?P<id>\d+)/reconcile', array('methods'=>'POST','callback'=>array($this,'reconcile_payout_batch'),'permission_callback'=>array($this,'can_payroll_action')));
		register_rest_route( self::NAMESPACE_V1, '/hrx/remittances/(?P<id>\d+)/settle', array('methods'=>'POST','callback'=>array($this,'settle_remittance'),'permission_callback'=>array($this,'can_payroll_action')));
		register_rest_route( self::NAMESPACE_V1, '/hrx/remittances/(?P<id>\d+)/reconcile', array('methods'=>'POST','callback'=>array($this,'reconcile_remittance'),'permission_callback'=>array($this,'can_payroll_action')));
		register_rest_route( self::NAMESPACE_V1, '/hrx/statutory-rules/(?P<id>\d+)/approve', array('methods'=>'POST','callback'=>array($this,'approve_statutory_rule'),'permission_callback'=>function(){ return Stockland_Authority::can_approve_payroll() ?: new WP_Error('hrx_owner_only','Owner payroll approval capability required.',array('status'=>403)); }));
		foreach ( array('freeze','calculate','review','submit','approve','post') as $action ) {
			register_rest_route( self::NAMESPACE_V1, '/hrx/payroll-runs/(?P<id>\d+)/'.$action, array('methods'=>'POST','callback'=>array($this,'payroll_'.$action),'permission_callback'=>array($this,'can_payroll_action')) );
		}
	}


	/** Read the fixed SOP manifest. Only plugin-bundled general operating procedures are served here. */
	private function sop_manifest() {
		$path = trailingslashit( STOCKLAND_PLUGIN_DIR ) . 'resources/erp-sops/manifest.json';
		if ( ! is_file( $path ) || ! is_readable( $path ) ) { return new WP_Error( 'sop_manifest_unavailable', 'The controlled SOP manifest is not installed.', array( 'status' => 503 ) ); }
		$data = json_decode( file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads a bundled, read-only plugin manifest.
		if ( ! is_array( $data ) || empty( $data['documents'] ) || ! is_array( $data['documents'] ) ) { return new WP_Error( 'sop_manifest_invalid', 'The controlled SOP manifest could not be verified.', array( 'status' => 503 ) ); }
		return $data;
	}

	/** Return the controlled document catalogue, including a live on-disk hash check. */
	public function list_sops() {
		$data = $this->sop_manifest();
		if ( is_wp_error( $data ) ) { return $data; }
		$items = array();
		$root = realpath( trailingslashit( STOCKLAND_PLUGIN_DIR ) . 'resources/erp-sops/files' );
		if ( ! $root ) { return new WP_Error( 'sop_files_unavailable', 'The controlled SOP files are not installed.', array( 'status' => 503 ) ); }
		foreach ( $data['documents'] as $doc ) {
			$filename = isset( $doc['file'] ) ? basename( (string) $doc['file'] ) : '';
			if ( '' === $filename || '.docx' !== strtolower( substr( $filename, -5 ) ) || empty( $doc['id'] ) || empty( $doc['sha256'] ) ) { continue; }
			$file = realpath( $root . DIRECTORY_SEPARATOR . $filename );
			$verified = $file && 0 === strpos( $file, $root . DIRECTORY_SEPARATOR ) && is_file( $file ) && is_readable( $file ) && hash_equals( (string) $doc['sha256'], hash_file( 'sha256', $file ) );
			$items[] = array(
				'id' => sanitize_text_field( $doc['id'] ),
				'filename' => $verified ? sanitize_file_name( $filename ) : '',
				'title' => sanitize_text_field( $doc['title'] ?? $doc['id'] ),
				'owner' => sanitize_text_field( $doc['owner'] ?? '' ),
				'version' => sanitize_text_field( $doc['document_version'] ?? 'v1.0-DRAFT' ),
				'status' => sanitize_text_field( $doc['status'] ?? 'DRAFT_NOT_APPROVED' ),
				'language' => sanitize_text_field( $doc['language'] ?? 'am-ET' ),
				'summary' => sanitize_text_field( $doc['summary'] ?? '' ),
				'downloadable' => (bool) $verified,
				'sha256' => $verified ? (string) $doc['sha256'] : '',
				'bytes' => $verified ? (int) filesize( $file ) : 0,
			);
		}
		return rest_ensure_response( array( 'items' => $items, 'count' => count( $items ), 'status' => sanitize_text_field( $data['status'] ?? 'DRAFT_NOT_APPROVED' ), 'personal_documents' => 'Separate private vault required; not part of this catalogue.' ) );
	}

	/** Serve one approved-path SOP after hash verification and successful append-only download audit. */
	public function download_sop( $request ) {
		$data = $this->sop_manifest();
		if ( is_wp_error( $data ) ) { return $data; }
		$code = sanitize_text_field( (string) $request->get_param( 'code' ) );
		$doc = null;
		foreach ( $data['documents'] as $candidate ) { if ( isset( $candidate['id'] ) && hash_equals( (string) $candidate['id'], $code ) ) { $doc = $candidate; break; } }
		if ( ! is_array( $doc ) ) { return new WP_Error( 'sop_not_found', 'This controlled SOP does not exist.', array( 'status' => 404 ) ); }
		$filename = isset( $doc['file'] ) ? basename( (string) $doc['file'] ) : '';
		if ( '' === $filename || '.docx' !== strtolower( substr( $filename, -5 ) ) ) { return new WP_Error( 'sop_filename_invalid', 'The SOP filename is not in the allowed format.', array( 'status' => 503 ) ); }
		$root = realpath( trailingslashit( STOCKLAND_PLUGIN_DIR ) . 'resources/erp-sops/files' );
		$file = $root ? realpath( $root . DIRECTORY_SEPARATOR . $filename ) : false;
		if ( ! $root || ! $file || 0 !== strpos( $file, $root . DIRECTORY_SEPARATOR ) || ! is_file( $file ) || ! is_readable( $file ) ) { return new WP_Error( 'sop_file_missing', 'The controlled SOP file is not available.', array( 'status' => 404 ) ); }
		$actual_hash = hash_file( 'sha256', $file );
		if ( empty( $doc['sha256'] ) || ! hash_equals( (string) $doc['sha256'], (string) $actual_hash ) ) { return new WP_Error( 'sop_hash_mismatch', 'The SOP file does not match its document-control hash; download blocked.', array( 'status' => 409 ) ); }
		if ( ! class_exists( 'Stockland_Audit' ) || ! Stockland_DB::table_exists( Stockland_DB::table( 'audit_logs' ) ) ) { return new WP_Error( 'sop_audit_unavailable', 'The ERP audit log is not available; secure download is blocked.', array( 'status' => 503 ) ); }
		$logged = Stockland_Audit::log( get_current_user_id(), null, 'ERP_SOP_DOWNLOAD', $code, 1, null, $actual_hash, 'Controlled ERP SOP downloaded', $code, null );
		if ( ! $logged ) { return new WP_Error( 'sop_audit_failed', 'The download audit event could not be written; the file was not served.', array( 'status' => 503 ) ); }
		$contents = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Serves only a manifest-allowlisted, hash-verified plugin-bundled DOCX.
		if ( false === $contents || '' === $contents ) { return new WP_Error( 'sop_file_read_failed', 'The controlled SOP could not be read.', array( 'status' => 500 ) ); }
		if ( headers_sent() ) { return new WP_Error( 'sop_headers_sent', 'The download response headers could not be prepared.', array( 'status' => 500 ) ); }
		nocache_headers();
		status_header( 200 );
		header( 'Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		header( 'Content-Length: ' . strlen( $contents ) );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex, nofollow', true );
		echo $contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary DOCX bytes must not be HTML-escaped.
		exit;
	}

	public function can_view_hrx() { return Stockland_Authority::can_view_hr() || Stockland_Authority::can_view_payroll(); }
	public function can_install_schema() { return current_user_can('stockland_install_schema') || current_user_can('manage_options'); }
	public function can_payroll_action() { return Stockland_Authority::can_manage_payroll() || Stockland_Authority::can_approve_payroll(); }
	private function resource_key( $slug ) { return isset($this->map[$slug]) ? $this->map[$slug] : ''; }
	private function is_payroll( $slug ) { return in_array($slug, $this->payroll, true); }
	private function valid_resource_request( $r ) { return $this->resource_key((string)$r->get_param('resource')) !== ''; }
	public function can_read_resource( $r ) {
		if ( ! $this->valid_resource_request($r) ) return new WP_Error('hrx_resource_invalid','Unknown HR replacement resource.',array('status'=>404));
		return $this->is_payroll((string)$r->get_param('resource')) ? ( Stockland_Authority::can_view_payroll() ?: new WP_Error('hrx_forbidden','Payroll access required.',array('status'=>403)) ) : ( Stockland_Authority::can_view_hr() ?: new WP_Error('hrx_forbidden','HR access required.',array('status'=>403)) );
	}
	public function can_create_resource( $r ) {
		if ( ! $this->valid_resource_request($r) ) return new WP_Error('hrx_resource_invalid','Unknown HR replacement resource.',array('status'=>404));
		$slug=(string)$r->get_param('resource');
		if ($slug==='statutory-rules') return current_user_can('stockland_hr_legal_review') ? true : new WP_Error('hrx_legal_reviewer_required','A separately authorized legal/payroll reviewer is required to draft legal rules.',array('status'=>403));
		if ($this->is_payroll($slug)) return Stockland_Authority::can_manage_payroll() ? true : new WP_Error('hrx_forbidden','Management payroll preparation authority is required.',array('status'=>403));
		return Stockland_Authority::can_prepare_hr() || Stockland_Authority::can_manage_hr() ? true : new WP_Error('hrx_forbidden','HR preparation authority is required.',array('status'=>403));
	}
	public function can_transition_resource( $r ) {
		$base=$this->can_create_resource($r); if ( is_wp_error($base) ) return $base;
		return true;
	}

	public function bootstrap() {
		$counts=array(); $ready=Stockland_HRX::ready();
		if ($ready) foreach ($this->map as $slug=>$key) { $counts[$slug]=(int) $this->count($key); }
		return rest_ensure_response(array(
			'schema_ready'=>$ready,'schema_version'=>get_option('stockland_hrx_schema_version',''),'table_count'=>count(Stockland_HRX::schema()),
			'legacy_tables_changed'=>false,'counts'=>$counts,'roles'=>array(
				'hr_view'=>Stockland_Authority::can_view_hr(),'hr_prepare'=>Stockland_Authority::can_prepare_hr()||Stockland_Authority::can_manage_hr(),
				'payroll_view'=>Stockland_Authority::can_view_payroll(),'payroll_prepare'=>Stockland_Authority::can_manage_payroll(),
				'payroll_approve'=>Stockland_Authority::can_approve_payroll(),'schema_install'=>$this->can_install_schema(),
				'legal_review'=>current_user_can('stockland_hr_legal_review')
			),'modules'=>array('people','recruitment','contracts','onboarding','time','leave','compensation','statutory-rules','payroll','payouts','remittances','separation','individual-payees','resources','social-reporting'),
			'payroll_activation'=>'BLOCKED_UNTIL_APPROVED_RULES_AND_FULL_VALIDATION'
		));
	}
	public function install_schema() {
		$r=Stockland_HRX::install(); if (is_wp_error($r)) return $r;
		if (!Stockland_HRX::audit('schema',0,'INSTALL',null,'READY',null,$r,array('legacy_tables_changed'=>false))) return new WP_Error('hrx_install_audit_failed','The additive schema exists but its install receipt could not be saved. Repeat the idempotent install after checking database/audit health; legacy tables were not changed.',array('status'=>500));
		return rest_ensure_response($r);
	}
	private function count($key) { global $wpdb; $table=Stockland_HRX::table($key); return (int)$wpdb->get_var("SELECT COUNT(*) FROM {$table}"); }
	private function require_ready() { return Stockland_HRX::ready() ? true : new WP_Error('hrx_schema_not_ready','The additive HR replacement schema has not been installed. Legacy HR data was not changed.',array('status'=>409)); }
	private function safe_row($slug,$row) {
		unset($row['row_version']);
		if (in_array($slug,array('contracts','resource-documents'),true)) { unset($row['private_document_ref'],$row['private_file_ref'],$row['document_sha256'],$row['file_sha256']); }
		if (!current_user_can('stockland_hr_sensitive_view') && !current_user_can('manage_options')) {
			if ($slug==='persons') unset($row['email'],$row['phone'],$row['birth_date']);
			if ($slug==='individual-payees') unset($row['tin_reference'],$row['licence_reference']);
		}
		if (isset($row['rule_parameters_json']) && is_string($row['rule_parameters_json'])) { $decoded=json_decode($row['rule_parameters_json'],true); $row['rule_parameters_json']=is_array($decoded)?$decoded:array(); }
		return $row;
	}
	public function list_resource( $r ) {
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$slug=(string)$r->get_param('resource'); $table=Stockland_HRX::table($this->resource_key($slug));
		$limit=max(1,min(100,absint($r->get_param('limit')?:50)));
		$rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} ORDER BY id DESC LIMIT %d",$limit),ARRAY_A);
		if (!is_array($rows)) return new WP_Error('hrx_read_failed','Could not load this HR resource.',array('status'=>500));
		return rest_ensure_response(array('items'=>array_map(function($row)use($slug){return $this->safe_row($slug,$row);},$rows),'count'=>count($rows)));
	}
	public function get_resource( $r ) {
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$slug=(string)$r->get_param('resource'); $table=Stockland_HRX::table($this->resource_key($slug));
		$row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1",absint($r['id'])),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','The HR record was not found.',array('status'=>404));
		return rest_ensure_response($this->safe_row($slug,$row));
	}
	private function columns($table) { $out=array(); foreach ((array)$GLOBALS['wpdb']->get_results("SHOW COLUMNS FROM {$table}",ARRAY_A) as $col) { $out[$col['Field']]=$col; } return $out; }
	private function canonicalize_value($value) {
		if (!is_array($value)) return $value;
		$is_list = function_exists('array_is_list') ? array_is_list($value) : (array_keys($value) === range(0, count($value) - 1));
		if (!$is_list) ksort($value, SORT_STRING);
		foreach ($value as $key => $item) $value[$key] = $this->canonicalize_value($item);
		return $value;
	}
	private function canonical_json($value) {
		$json = wp_json_encode($this->canonicalize_value($value));
		if (!is_string($json)) throw new InvalidArgumentException('Request payload cannot be canonicalized for idempotency.');
		return $json;
	}
	private function idempotency_context($request,$slug,$body) {
		$key=(string)$request->get_header('X-Idempotency-Key');
		if ($key==='') $key=(string)($body['idempotency_key']??'');
		if ($key==='') return null;
		if (!preg_match('/^[A-Za-z0-9._:-]{16,100}$/',$key)) return new WP_Error('hrx_idempotency_key','Idempotency key must be 16–100 characters using letters, digits, dot, underscore, colon or hyphen.',array('status'=>400));
		$payload=$body; unset($payload['idempotency_key']);
		try { $hash = hash('sha256', $this->canonical_json($payload)); }
		catch (Throwable $e) { return new WP_Error('hrx_idempotency_payload','Request payload could not be safely canonicalized.',array('status'=>400)); }
		return array('request_key'=>$key,'actor_id'=>get_current_user_id(),'route_key'=>'create:'.$slug,'request_sha256'=>$hash);
	}
	private function find_idempotency($ctx) {
		if (!$ctx) return null;
		$t=Stockland_HRX::table('idempotency_requests');
		return $GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE request_key=%s AND actor_id=%d AND route_key=%s LIMIT 1",$ctx['request_key'],$ctx['actor_id'],$ctx['route_key']),ARRAY_A);
	}
	private function idempotent_replay($ctx,$table,$slug) {
		if (!$ctx) return null;
		$prior=$this->find_idempotency($ctx); if (!$prior) return null;
		if (!hash_equals((string)$prior['request_sha256'],(string)$ctx['request_sha256'])) return new WP_Error('hrx_idempotency_conflict','That idempotency key was already used for a different request. Use a new key for a new operation.',array('status'=>409));
		if ((int)$prior['entity_id']<1) return new WP_Error('hrx_idempotency_pending','An operation with this key is already being committed. Refresh the record before retrying.',array('status'=>409));
		$row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT id,status FROM {$table} WHERE id=%d",(int)$prior['entity_id']),ARRAY_A);
		if (!$row) return new WP_Error('hrx_idempotency_orphan','Idempotency receipt exists but its target record is missing; investigate the audit trail.',array('status'=>409));
		return new WP_REST_Response(array('id'=>(int)$row['id'],'resource'=>$slug,'status'=>$row['status']??'DRAFT','saved'=>true,'deduplicated'=>true),200);
	}
	private function validate_statutory_source($row) {
		$url=(string)($row['source_url']??''); $host=strtolower((string)parse_url($url,PHP_URL_HOST));
		if (stripos($url,'https://')!==0 || !($host==='gov.et' || str_ends_with($host,'.gov.et'))) return new WP_Error('hrx_rule_source_url','Only HTTPS URLs on an official *.gov.et domain can support a statutory rule.',array('status'=>409));
		$attachment_id=absint($row['source_attachment_id']??0);
		if (!$attachment_id || !function_exists('get_attached_file') || get_post_type($attachment_id)!=='attachment') return new WP_Error('hrx_rule_source_file','Attach the actual official legal PDF in WordPress Media and record its attachment ID.',array('status'=>409));
		$file=get_attached_file($attachment_id); $real_file=$file?realpath($file):false; $uploads=wp_upload_dir(); $upload_root=realpath($uploads['basedir']??'');
		if (!$real_file || !$upload_root || strpos($real_file,$upload_root.DIRECTORY_SEPARATOR)!==0 || !is_file($real_file) || !is_readable($real_file)) return new WP_Error('hrx_rule_source_file','The official source attachment must be a readable file inside the configured WordPress uploads directory.',array('status'=>409));
		$handle=fopen($real_file,'rb'); $signature=$handle?fread($handle,5):''; if ($handle) fclose($handle);
		if ($signature!=='%PDF-') return new WP_Error('hrx_rule_source_file','Only an actual PDF source file is accepted for statutory-rule evidence.',array('status'=>409));
		$actual=strtolower((string)hash_file('sha256',$real_file)); $claimed=strtolower((string)($row['source_sha256']??''));
		if (!preg_match('/^[a-f0-9]{64}$/',$claimed) || !hash_equals($actual,$claimed)) return new WP_Error('hrx_rule_source_hash','The recorded SHA-256 does not match the attached official PDF bytes.',array('status'=>409));
		return array('attachment_id'=>$attachment_id,'sha256'=>$actual,'source_url'=>$url);
	}
	private function clean_value($field,$value,$column) {
		if (is_array($value) || is_object($value)) {
			if ($field==='rule_parameters_json') return wp_json_encode($value);
			throw new InvalidArgumentException('Only rule parameters may be supplied as structured JSON.');
		}
		$value=is_scalar($value)?(string)$value:'';
		if (in_array($field,array('source_url'),true)) { $v=esc_url_raw($value); if (!$v || !preg_match('#^https?://#i',$v)) throw new InvalidArgumentException('A valid official source URL is required.'); return $v; }
		if (preg_match('/(^|_)(amount|salary|budget|entitlement|quantity|score|days|minutes|headcount|year|version|id|bps)$/i',$field) || preg_match('/_id$/',$field) || in_array($field,array('rate_bps','up_to_minor'),true)) {
			if ($value!=='' && !is_numeric($value)) throw new InvalidArgumentException('Numeric field is invalid: '.$field);
			if (preg_match('/(amount|salary|budget|cash_amount|in_kind_amount|entitlement)$/i',$field) && !Stockland_HRX::valid_money($value)) throw new InvalidArgumentException('Money field is invalid: '.$field);
			return $value===''?null:$value;
		}
		if (in_array($field,array('birth_date','retention_until','effective_from','effective_to','opened_on','close_on','proposed_start','expires_on','start_date','end_date','due_date','event_date','applied_at','held_at'),true) && $value!=='') {
			if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$value) && checkdate((int)substr($value,5,2),(int)substr($value,8,2),(int)substr($value,0,4))) return $value;
			if (in_array($field,array('applied_at','held_at'),true) && strtotime($value)!==false) return gmdate('Y-m-d H:i:s',strtotime($value));
			throw new InvalidArgumentException('Date field is invalid: '.$field);
		}
		if (preg_match('/json$/',$field)) { json_decode($value,true); if (json_last_error()!==JSON_ERROR_NONE) throw new InvalidArgumentException('Invalid JSON: '.$field); return $value; }
		if (stripos((string)$column['Type'],'text')!==false) return sanitize_textarea_field($value);
		return sanitize_text_field($value);
	}
	public function create_resource( $r ) {
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$slug=(string)$r->get_param('resource'); $key=$this->resource_key($slug); $table=Stockland_HRX::table($key); $body=$r->get_json_params();
		if (in_array($slug,array('payroll-lines','payroll-line-items','payout-results','leave-movements'),true)) return new WP_Error('hrx_derived_record','This record is generated or settled only by a dedicated workflow endpoint.',array('status'=>405));
		if (!is_array($body)) return new WP_Error('hrx_input_invalid','Expected a JSON object.',array('status'=>400));
		$idem=$this->idempotency_context($r,$slug,$body); if (is_wp_error($idem)) return $idem; $replay=$this->idempotent_replay($idem,$table,$slug); if (is_wp_error($replay)) return $replay; if ($replay instanceof WP_REST_Response) return $replay;
		$cols=$this->columns($table); $data=array();
		if ($slug==='payout-batches') { $posted=isset($body['payroll_run_id'])?(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare('SELECT id FROM '.Stockland_HRX::table('payroll_runs')." WHERE id=%d AND status='POSTED'",(int)$body['payroll_run_id'])):0; if (!$posted) return new WP_Error('hrx_payout_gate','A payout batch can only be created for a posted payroll run.',array('status'=>409)); }
		if ($slug==='remittances' && (!empty($body['amount_paid']) || !empty($body['paid_at']) || !empty($body['official_receipt_ref']))) return new WP_Error('hrx_remittance_gate','Payment evidence must be recorded through the remittance settlement workflow; direct paid-state entry is blocked.',array('status'=>400));
		try {
			foreach ($body as $field=>$value) {
				if (!isset($cols[$field]) || in_array($field,$this->server_fields,true) || in_array($field,array('private_document_ref','private_file_ref','document_sha256','file_sha256'),true)) continue;
				$data[$field]=$this->clean_value($field,$value,$cols[$field]);
			}
			if ($slug==='statutory-rules') {
				if (empty($data['source_attachment_id']) || empty($data['source_sha256'])) throw new InvalidArgumentException('A real official PDF attachment ID and its SHA-256 are mandatory.');
				if (empty($data['article_clause']) || empty($data['effective_from']) || empty($data['rule_parameters_json'])) throw new InvalidArgumentException('Legal clause, effective date, and rule parameters are required.');
			}
		} catch (Throwable $e) { return new WP_Error('hrx_validation',$e->getMessage(),array('status'=>400)); }
		if ($slug==='statutory-rules') { $src=$this->validate_statutory_source($data); if (is_wp_error($src)) return $src; $data['source_sha256']=$src['sha256']; }
		if ($slug==='payout-batches') {
			$run_id=(int)($data['payroll_run_id']??0); $run=$run_id?$this->payroll_run($run_id):null;
			if (!$run || $run['status']!=='POSTED') return new WP_Error('hrx_payout_gate','A payout batch can only be created for a payroll run that is posted to GL.',array('status'=>409));
			if (Stockland_Money::minor($run['net_total'])<=0) return new WP_Error('hrx_payout_empty','A zero or negative payroll net total cannot create a payment batch.',array('status'=>409));
			$channel=strtoupper((string)($data['channel']??'')); if (!in_array($channel,array('BANK','CASH'),true)) return new WP_Error('hrx_payment_channel','Only BANK or CASH with a supported Stockland GL account can be reconciled.',array('status'=>400));
			$data['amount_total']=$run['net_total']; $data['currency']='ETB'; $data['batch_code']='HRX-PAYOUT-'.$run_id.'-'.substr(str_replace('-','',wp_generate_uuid4()),0,12);
		}
		if ($slug==='remittances') {
			$kind=strtoupper((string)($data['remittance_type']??'')); $period=(string)($data['period_key']??'');
			$run=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM ".Stockland_HRX::table('payroll_runs')." WHERE period_key=%s AND status IN ('POSTED','PAYMENT_IN_PROGRESS','SETTLED','CLOSED') ORDER BY id DESC LIMIT 1",$period),ARRAY_A);
			if (!$run) return new WP_Error('hrx_remittance_gate','A statutory remittance requires a posted payroll run for the same period.',array('status'=>409));
			$amount_field=array('PAYE'=>'paye_total','EMPLOYEE_PENSION'=>'employee_pension_total','EMPLOYER_PENSION'=>'employer_pension_total');
			if (!isset($amount_field[$kind])) return new WP_Error('hrx_remittance_type','Only PAYE and the separately reviewed employee/employer pension remittances are enabled in this candidate.',array('status'=>409));
			$rules=$this->approved_rules($run['end_date']); if (is_wp_error($rules)) return $rules;
			$rule_kind=$kind==='PAYE'?'PAYE':$kind; $data['legal_rule_id']=(int)$rules[$rule_kind]['id']; $data['amount_due']=$run[$amount_field[$kind]]; $data['amount_paid']='0.00'; $data['journal_id']=null;
		}
		$data['status']='DRAFT';
		if ($slug==='applications' && isset($data['stage'])) { return new WP_Error('hrx_field_locked','Application stage must be changed through the transition API.',array('status'=>400)); }
		if ($slug==='social-snapshots') $data['captured_by']=get_current_user_id();
		if ($slug==='interviews') $data['interviewer_user_id']=get_current_user_id();
		if ($slug==='employments') $data['status']='PENDING_ONBOARDING';
		if ($slug==='onboarding-tasks') $data['status']='PENDING';
		if ($slug==='payroll-runs') {
			$data['status']='DRAFT'; $data['prepared_by']=get_current_user_id();
			if (empty($data['period_key']) || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/',$data['period_key'])) return new WP_Error('hrx_period_invalid','Payroll period must be YYYY-MM.',array('status'=>400));
			$parts=explode('-',$data['period_key']); $begin=$data['period_key'].'-01'; $end=$data['period_key'].'-'.gmdate('t',strtotime($begin));
			if (($data['start_date']??'')!==$begin || ($data['end_date']??'')!==$end) return new WP_Error('hrx_period_invalid','Payroll periods must cover the full calendar month. Partial periods are blocked pending approved proration rules.',array('status'=>400));
			$data['run_code']='HRX-'.str_replace('-','',$data['period_key']);
		}
		$data['created_by']=get_current_user_id(); $data['updated_by']=get_current_user_id(); $data['created_at']=Stockland_HRX::now(); $data['updated_at']=Stockland_HRX::now();
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start record transaction.',array('status'=>500));
		$idem_id=0;
		if ($idem) { $it=Stockland_HRX::table('idempotency_requests'); $ir=array('request_key'=>$idem['request_key'],'actor_id'=>$idem['actor_id'],'route_key'=>$idem['route_key'],'entity_type'=>$key,'entity_id'=>0,'request_sha256'=>$idem['request_sha256'],'response_sha256'=>null,'status'=>'IN_PROGRESS','row_version'=>1,'created_by'=>get_current_user_id(),'updated_by'=>get_current_user_id(),'created_at'=>Stockland_HRX::now(),'updated_at'=>Stockland_HRX::now()); if (!$GLOBALS['wpdb']->insert($it,$ir)) { $GLOBALS['wpdb']->query('ROLLBACK'); $replay=$this->idempotent_replay($idem,$table,$slug); if ($replay instanceof WP_REST_Response) return $replay; if (is_wp_error($replay)) return $replay; return new WP_Error('hrx_idempotency_race','A request with this idempotency key is already being processed.',array('status'=>409)); } $idem_id=(int)$GLOBALS['wpdb']->insert_id; }
		if ($slug==='payout-batches') {
			$run_id=(int)$data['payroll_run_id']; $existing=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT id,status FROM {$table} WHERE payroll_run_id=%d ORDER BY id DESC LIMIT 1 FOR UPDATE",$run_id),ARRAY_A);
			if ($existing && $existing['status']!=='FAILED') { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payout_duplicate','A payout batch for this payroll is already in progress, paid, or reconciled. Only a fully failed batch can be replaced; this prevents double payment.',array('status'=>409)); }
		}
		if ($slug==='remittances') {
			$kind=strtoupper((string)($data['remittance_type']??'')); $period=(string)($data['period_key']??'');
			$existing=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT id,status FROM {$table} WHERE remittance_type=%s AND period_key=%s ORDER BY id DESC LIMIT 1 FOR UPDATE",$kind,$period),ARRAY_A);
			if ($existing) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_remittance_duplicate','A remittance already exists for this type and period. Reconcile or correct that record instead of creating a possible duplicate payment.',array('status'=>409)); }
		}
		$ok=$GLOBALS['wpdb']->insert($table,$data);
		if (!$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_create_failed','Record was not saved. Check required fields and duplicate codes. '.(current_user_can('manage_options')?$GLOBALS['wpdb']->last_error:''),array('status'=>409)); }
		$id=(int)$GLOBALS['wpdb']->insert_id;
		$audit_after=array_diff_key($data,array_flip(array('given_name','family_name','email','phone','birth_date','tin_reference','licence_reference','notes','reason')));
		if (!Stockland_HRX::audit($key,$id,'CREATE',null,$data['status']??'DRAFT',null,$audit_after)) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','The create audit could not be recorded; the new record was not committed.',array('status'=>500)); }
		$payload=array('id'=>$id,'resource'=>$slug,'status'=>$data['status']??'DRAFT','saved'=>true);
		if ($idem_id) { $it=Stockland_HRX::table('idempotency_requests'); $receipt_ok=$GLOBALS['wpdb']->update($it,array('entity_id'=>$id,'response_sha256'=>hash('sha256',wp_json_encode($payload)),'status'=>'COMPLETED','updated_by'=>get_current_user_id(),'updated_at'=>Stockland_HRX::now()),array('id'=>$idem_id,'entity_id'=>0,'status'=>'IN_PROGRESS')); if (1!==$receipt_ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_idempotency_receipt','Could not commit the idempotency receipt; the create operation was rolled back.',array('status'=>500)); } }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Record transaction could not be committed.',array('status'=>500)); }
		return new WP_REST_Response($payload,201);
	}
	public function transition_resource( $r ) {
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$slug=(string)$r->get_param('resource'); $key=$this->resource_key($slug); $table=Stockland_HRX::table($key); $body=$r->get_json_params();
		if ($slug==='payroll-runs') return new WP_Error('hrx_dedicated_workflow','Payroll lifecycle changes must use freeze, calculate, submit, approve, or post endpoints.',array('status'=>409));
		if ($slug==='statutory-rules') return new WP_Error('hrx_dedicated_workflow','Statutory rules must use the qualified-review and independent-approval endpoints.',array('status'=>409));
		$to=strtoupper(sanitize_text_field((string)($body['to_status']??''))); $id=absint($r['id']);
		if (!$to) return new WP_Error('hrx_transition_invalid','Target status is required.',array('status'=>400));
		$row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Record was not found.',array('status'=>404));
		$state_col = $slug==='applications' ? 'stage' : 'status';
		$from=(string)$row[$state_col];
		if ($slug==='separation-cases' && in_array($to,array('CALCULATED','SETTLEMENT_APPROVED','PAYMENT_IN_PROGRESS','SETTLED','CLOSED'),true)) return new WP_Error('hrx_exit_settlement_unavailable','Exit case review can be recorded, but final calculation, settlement approval and payment are blocked until the dedicated legally approved final-settlement workflow is implemented.',array('status'=>409));
		if ($slug==='payee-engagements' && in_array($to,array('PAYMENT_IN_PROGRESS','PAID','FAILED'),true)) return new WP_Error('hrx_payee_ap_unavailable','Individual-payee engagement cannot be marked paid through a generic transition. The dedicated Finance/AP withholding and payment workflow is not yet enabled.',array('status'=>409));
		if (!Stockland_HRX::transition_allowed($slug,$from,$to)) return new WP_Error('hrx_transition_blocked','This status transition is not allowed.',array('status'=>409,'from'=>$from,'to'=>$to));
		if ($slug==='payout-batches' && $from==='FAILED' && $to==='SUBMITTED') return new WP_Error('hrx_payout_retry','Recipient rows in a failed batch are immutable. Create a new batch after verifying all recipients in the prior batch failed.',array('status'=>409));
		$user=get_current_user_id();
		if (in_array($to,array('APPROVED','OWNER_APPROVED','POSTED','ACTIVE','SIGNED','VERIFIED','SETTLED','CLOSED'),true) && (int)$row['updated_by']===$user) return new WP_Error('hrx_maker_checker','The creator cannot approve or finalize their own record.',array('status'=>403));
		if ($slug==='payout-batches' && in_array($to,array('PAID','PARTIALLY_PAID','FAILED','RECONCILED'),true)) return new WP_Error('hrx_payment_evidence_required','Payout status is derived from per-recipient payment evidence; use the dedicated payment and reconciliation workflow.',array('status'=>409));
		if ($slug==='remittances' && in_array($to,array('PAID','RECONCILED'),true)) return new WP_Error('hrx_payment_evidence_required','Remittance paid/reconciled status requires payment reference and GL posting.',array('status'=>409));
		if ($slug==='contracts' && $to==='VERIFIED') return new WP_Error('hrx_private_vault_unavailable','Contract verification is blocked until a private storage provider returns a durable non-public access and SHA-256 verification receipt.',array('status'=>409));
		if ($slug==='statutory-rules' && $to==='APPROVED') return new WP_Error('hrx_legal_gate','Legal rule approval must use the dedicated qualified-review flow and independent approver; generic status changes cannot activate legal rules.',array('status'=>409));
		if ($slug==='employments' && $to==='ACTIVE') {
			$contract=Stockland_HRX::table('contracts'); $tasks=Stockland_HRX::table('onboarding_tasks');
			$has=$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$contract} WHERE employment_id=%d AND status='SIGNED' AND verification_status='VERIFIED'",$id));
			$pending=$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$tasks} WHERE employment_id=%d AND mandatory=1 AND status NOT IN ('COMPLETED','WAIVED')",$id));
			if ((int)$has<1 || (int)$pending>0) return new WP_Error('hrx_onboarding_gate','Activation requires a verified signed contract and all mandatory onboarding tasks completed or properly waived.',array('status'=>409));
		}
		$now=Stockland_HRX::now(); $payout_tx=false;
		if ($slug==='payout-batches' && $to==='SUBMITTED') {
			$run=$this->payroll_run((int)$row['payroll_run_id']); if (!$run || $run['status']!=='POSTED' || Stockland_Money::minor($row['amount_total'])!==Stockland_Money::minor($run['net_total'])) return new WP_Error('hrx_payout_total','Payout total must equal the posted payroll net total.',array('status'=>409));
			$run_lines=Stockland_HRX::table('payroll_lines'); $result_table=Stockland_HRX::table('payout_results'); $line_rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT id,employment_id,net_pay FROM {$run_lines} WHERE payroll_run_id=%d ORDER BY id",(int)$run['id']),ARRAY_A);
			if (!$line_rows) return new WP_Error('hrx_payout_empty','No payroll employee lines exist for this payout batch.',array('status'=>409));
			if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payout submission transaction.',array('status'=>500)); $payout_tx=true;
			$recipient_count=0;
		foreach ($line_rows as $line) {
			$minor=Stockland_Money::minor($line['net_pay']);
			if ($minor<0) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payout_negative','Negative net pay must be corrected through a reviewed adjustment; no payment batch was submitted.',array('status'=>409)); }
			if ($minor===0) continue;
			$entry=array('payout_batch_id'=>(int)$row['id'],'payroll_line_id'=>(int)$line['id'],'employment_id'=>(int)$line['employment_id'],'amount'=>$line['net_pay'],'status'=>'PENDING','created_by'=>get_current_user_id(),'updated_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now);
			if (!$GLOBALS['wpdb']->insert($result_table,$entry)) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payout_results','Could not stage each recipient payment; nothing was submitted.',array('status'=>409)); }
			$recipient_count++;
		}
		if ($recipient_count<1) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payout_empty','No positive-net recipient exists for this payout batch.',array('status'=>409)); }
		}
		$fields=array('status'=>$to,'row_version'=>(int)$row['row_version']+1,'updated_by'=>$user,'updated_at'=>$now);
		if (in_array('approved_by',array_keys($row),true) && in_array($to,array('APPROVED','OWNER_APPROVED','SETTLEMENT_APPROVED'),true)) { $fields['approved_by']=$user; $fields['approved_at']=$now; }
		if (!$payout_tx) { if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start HR transition transaction.',array('status'=>500)); $payout_tx=true; }
		$sets="{$state_col}=%s,row_version=row_version+1,updated_by=%d,updated_at=%s"; $args=array($to,$user,$now); if ($slug==='payout-batches' && $to==='SUBMITTED') { $sets.=',submitted_at=%s'; $args[]=$now; } if (isset($fields['approved_by'])) { $sets.=',approved_by=%d,approved_at=%s'; $args[]=$user; $args[]=$now; }
		$args[]=$id; $args[]=$from; $args[]=(int)$row['row_version']; $sql="UPDATE {$table} SET {$sets} WHERE id=%d AND {$state_col}=%s AND row_version=%d";
		$updated=$GLOBALS['wpdb']->query($GLOBALS['wpdb']->prepare($sql,...$args));
		if (1!==$updated) { if($payout_tx)$GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Record changed concurrently. Refresh and retry.',array('status'=>409)); }
		if (!Stockland_HRX::audit($key,$id,'TRANSITION',$from,$to,$row,array($state_col=>$to,'row_version'=>(int)$row['row_version']+1))) { if($payout_tx)$GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','State transition audit could not be saved; no state change committed.',array('status'=>500)); } if($payout_tx && false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Workflow transition transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'from'=>$from,'status'=>$to,'row_version'=>(int)$row['row_version']+1));
	}

	public function settle_payout_result($r) {
		if (!Stockland_Authority::can_approve_payroll()) return new WP_Error('hrx_owner_only','Only the Owner may record actual recipient payment confirmations.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$id=absint($r['id']); $payout_results=Stockland_HRX::table('payout_results'); $batches=Stockland_HRX::table('payout_batches');
		$body=$r->get_json_params(); $outcome=strtoupper(sanitize_text_field((string)($body['outcome']??'')));
		if (!in_array($outcome,array('PAID','FAILED'),true)) return new WP_Error('hrx_payment_outcome','Outcome must be PAID or FAILED.',array('status'=>400));
		$row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$payout_results} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Recipient payment row was not found.',array('status'=>404));
		$batch=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$batches} WHERE id=%d",(int)$row['payout_batch_id']),ARRAY_A);
		if (!$batch || !in_array($batch['status'],array('SUBMITTED','PARTIALLY_PAID'),true)) return new WP_Error('hrx_payout_state','Only a submitted, unsettled payout batch can record recipient results.',array('status'=>409));
		if ($row['status']!=='PENDING') return new WP_Error('hrx_payout_immutable','Recipient payment result is already recorded. Use a new approved payout batch for any retry.',array('status'=>409));
		$reference=sanitize_text_field((string)($body['external_reference']??'')); $failure=sanitize_textarea_field((string)($body['failure_reason']??''));
		if ($outcome==='PAID' && $reference==='') return new WP_Error('hrx_payment_reference','An external bank/cash reference is required for each paid recipient.',array('status'=>400));
		if ($outcome==='FAILED' && $failure==='') return new WP_Error('hrx_payment_failure_reason','A reason is required when a recipient payment fails.',array('status'=>400));
		$now=Stockland_HRX::now();
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start recipient settlement transaction.',array('status'=>500));
		$ok=$GLOBALS['wpdb']->update($payout_results,array('status'=>$outcome,'external_reference'=>$outcome==='PAID'?$reference:null,'failure_reason'=>$outcome==='FAILED'?$failure:null,'paid_at'=>$outcome==='PAID'?$now:null,'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>'PENDING','row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Recipient payment changed concurrently.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payout_results',$id,'SETTLE','PENDING',$outcome,$row,array('status'=>$outcome,'external_reference'=>$reference,'failure_reason'=>$failure))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Payment settlement audit could not be saved.',array('status'=>500)); }
		$all=(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$payout_results} WHERE payout_batch_id=%d",(int)$batch['id']));
		$paid=(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$payout_results} WHERE payout_batch_id=%d AND status='PAID'",(int)$batch['id']));
		$failed=(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$payout_results} WHERE payout_batch_id=%d AND status='FAILED'",(int)$batch['id']));
		$new_status=$paid===$all?'PAID':(($failed===$all)?'FAILED':(($paid+$failed)>0?'PARTIALLY_PAID':'SUBMITTED'));
		if ($new_status!==$batch['status']) { $batch_ok=$GLOBALS['wpdb']->update($batches,array('status'=>$new_status,'row_version'=>(int)$batch['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>(int)$batch['id'],'row_version'=>(int)$batch['row_version'])); if (1!==$batch_ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Payout batch changed concurrently; recipient outcome rolled back.',array('status'=>409)); } }
		if (!Stockland_HRX::audit('payout_batches',(int)$batch['id'],'PAYMENT_PROGRESS',$batch['status'],$new_status,$batch,array('total'=>$all,'paid'=>$paid,'failed'=>$failed))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Batch progress audit failed; recipient outcome rolled back.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Could not commit recipient payment result.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'status'=>$outcome,'batch_id'=>(int)$batch['id'],'batch_status'=>$new_status,'recipients_total'=>$all,'paid'=>$paid,'failed'=>$failed,'reconcile_ready'=>$new_status==='PAID'));
	}

	public function reconcile_payout_batch($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','Management independently reconciles payment evidence.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$id=absint($r['id']); $table=Stockland_HRX::table('payout_batches'); $row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Payout batch not found.',array('status'=>404));
		if ($row['status']!=='PAID') return new WP_Error('hrx_payout_state','Every recipient must be confirmed paid before reconciliation.',array('status'=>409));
		if ((int)$row['updated_by']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The actor who recorded the last payment cannot also reconcile the payout batch.',array('status'=>403));
		$body=$r->get_json_params(); $reference=sanitize_text_field((string)($body['external_reference']??''));
		if ($reference==='') return new WP_Error('hrx_bank_reference','A bank statement or cashbook reconciliation reference is required.',array('status'=>400));
		$results=Stockland_HRX::table('payout_results'); $count=(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$results} WHERE payout_batch_id=%d",$id));
		$sum=$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COALESCE(SUM(amount),0) FROM {$results} WHERE payout_batch_id=%d AND status='PAID'",$id));
		if ($count<1 || Stockland_Money::minor($sum)!==Stockland_Money::minor($row['amount_total'])) return new WP_Error('hrx_payout_mismatch','Recipient-level paid total does not match the payout batch amount.',array('status'=>409));
		$account=$row['channel']==='BANK'?'1010':'1000'; if (!Stockland_Accounting::account_exists('2020') || !Stockland_Accounting::account_exists($account)) return new WP_Error('hrx_payout_gl','Payroll payable or approved bank/cash account is not active.',array('status'=>409));
		$now=Stockland_HRX::now(); if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payout reconciliation transaction.',array('status'=>500));
		$jid=Stockland_Accounting::post_journal(gmdate('Y-m-d'), 'HRX_PAYOUT', $id, 'HRX payout batch '.$row['batch_code'].' '.$reference, array(array('account_code'=>'2020','debit'=>$row['amount_total'],'credit'=>'0.00'),array('account_code'=>$account,'debit'=>'0.00','credit'=>$row['amount_total'])), get_current_user_id());
		if (!$jid) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payout_gl_failed','Payment reconciliation journal failed; batch remains unreconciled.',array('status'=>409)); }
		$ok=$GLOBALS['wpdb']->update($table,array('status'=>'RECONCILED','journal_id'=>(int)$jid,'external_reference'=>$reference,'reconciled_at'=>$now,'reconciled_by'=>get_current_user_id(),'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>'PAID','row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Payout batch changed during reconciliation.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payout_batches',$id,'RECONCILE','PAID','RECONCILED',$row,array('journal_id'=>(int)$jid,'external_reference'=>$reference))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Reconciliation audit could not be saved.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Payout reconciliation transaction failed to commit.',array('status'=>500)); } return rest_ensure_response(array('id'=>$id,'status'=>'RECONCILED','journal_id'=>(int)$jid,'external_reference'=>$reference));
	}

	public function settle_remittance($r) {
		if (!Stockland_Authority::can_approve_payroll()) return new WP_Error('hrx_owner_only','Only the Owner may record an executed tax/pension payment.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$id=absint($r['id']); $table=Stockland_HRX::table('remittances'); $row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Remittance not found.',array('status'=>404));
		if ($row['status']!=='SUBMITTED') return new WP_Error('hrx_remittance_state','Only a submitted remittance may be settled.',array('status'=>409));
		if (Stockland_Money::minor($row['amount_due'])<=0) return new WP_Error('hrx_remittance_amount','Remittance due must be greater than zero.',array('status'=>409));
		$body=$r->get_json_params(); $method=strtoupper(sanitize_text_field((string)($body['method']??'BANK'))); $reference=sanitize_text_field((string)($body['official_receipt_ref']??'')); $entered=isset($body['amount_paid'])?(string)$body['amount_paid']:'';
		if (!in_array($method,array('BANK','CASH'),true) || $reference==='' || !Stockland_HRX::valid_money($entered) || Stockland_Money::minor($entered)!==Stockland_Money::minor($row['amount_due'])) return new WP_Error('hrx_remittance_evidence','Select BANK/CASH, enter the official payment receipt/reference and confirm an amount exactly equal to the approved amount due.',array('status'=>400));
		if ((int)$row['created_by']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The remittance preparer cannot execute and record their own payment.',array('status'=>403));
		$liability=array('PAYE'=>'2031','EMPLOYEE_PENSION'=>'2030','EMPLOYER_PENSION'=>'2032'); if (!isset($liability[$row['remittance_type']])) return new WP_Error('hrx_remittance_type','No approved liability mapping exists for this remittance type.',array('status'=>409));
		if (!Stockland_Accounting::ensure_payroll_statutory_accounts()) return new WP_Error('hrx_remittance_gl','Payroll statutory liability accounts are not valid.',array('status'=>409));
		$bank=$method==='BANK'?'1010':'1000'; if (!Stockland_Accounting::account_exists($bank)) return new WP_Error('hrx_bank_account','Stockland bank/cash control account is not active.',array('status'=>409));
		$now=Stockland_HRX::now(); if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start remittance settlement transaction.',array('status'=>500));
		$jid=Stockland_Accounting::post_journal(gmdate('Y-m-d'),'HRX_REMITTANCE',$id,'Statutory remittance '.$row['remittance_type'].' '.$row['period_key'].' '.$reference,array(array('account_code'=>$liability[$row['remittance_type']],'debit'=>$row['amount_due'],'credit'=>'0.00'),array('account_code'=>$bank,'debit'=>'0.00','credit'=>$row['amount_due'])),get_current_user_id());
		if (!$jid) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_remittance_gl_failed','Remittance GL posting failed; no paid status was saved.',array('status'=>409)); }
		$ok=$GLOBALS['wpdb']->update($table,array('status'=>'PAID','amount_paid'=>$row['amount_due'],'paid_at'=>$now,'official_receipt_ref'=>$reference,'journal_id'=>(int)$jid,'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>'SUBMITTED','row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Remittance changed during settlement.',array('status'=>409)); }
		if (!Stockland_HRX::audit('remittances',$id,'SETTLE','SUBMITTED','PAID',$row,array('amount_paid'=>$row['amount_due'],'official_receipt_ref'=>$reference,'journal_id'=>(int)$jid))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Remittance payment audit could not be saved.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Remittance settlement transaction failed to commit.',array('status'=>500)); } return rest_ensure_response(array('id'=>$id,'status'=>'PAID','amount_paid'=>$row['amount_due'],'journal_id'=>(int)$jid,'official_receipt_ref'=>$reference));
	}

	public function reconcile_remittance($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','Management independently reconciles the remittance.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$id=absint($r['id']); $table=Stockland_HRX::table('remittances'); $row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Remittance not found.',array('status'=>404));
		if ($row['status']!=='PAID' || empty($row['journal_id']) || empty($row['official_receipt_ref']) || Stockland_Money::minor($row['amount_paid'])!==Stockland_Money::minor($row['amount_due'])) return new WP_Error('hrx_remittance_state','Reconciliation requires a fully paid remittance, GL journal and official receipt reference.',array('status'=>409));
		if ((int)$row['updated_by']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The payment actor cannot reconcile the same remittance.',array('status'=>403));
		$body=$r->get_json_params(); $note=sanitize_textarea_field((string)($body['reconciliation_note']??'')); if ($note==='') return new WP_Error('hrx_reconciliation_note','Reconciliation evidence/note is required.',array('status'=>400));
		$now=Stockland_HRX::now(); if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start remittance reconciliation transaction.',array('status'=>500));
		$ok=$GLOBALS['wpdb']->update($table,array('status'=>'RECONCILED','reconciled_at'=>$now,'reconciled_by'=>get_current_user_id(),'reconciliation_note'=>$note,'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>'PAID','row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Remittance changed during reconciliation.',array('status'=>409)); }
		if (!Stockland_HRX::audit('remittances',$id,'RECONCILE','PAID','RECONCILED',$row,array('journal_id'=>(int)$row['journal_id'],'reconciliation_note_sha256'=>hash('sha256',$note)))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Remittance reconciliation audit could not be saved.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Remittance reconciliation transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'status'=>'RECONCILED','journal_id'=>(int)$row['journal_id'],'reconciled_by'=>get_current_user_id(),'reconciled_at'=>$now));
	}

	public function review_statutory_rule($r) {
		if (!current_user_can('stockland_hr_legal_review')) return new WP_Error('hrx_legal_reviewer_required','Qualified reviewer capability required.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$t=Stockland_HRX::table('statutory_rules'); $id=absint($r['id']); $row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Statutory rule not found.',array('status'=>404));
		if ((int)$row['created_by']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The rule preparer cannot also perform the qualified legal review.',array('status'=>403));
		if (!in_array($row['status'],array('DRAFT','REJECTED'),true)) return new WP_Error('hrx_rule_state','Only a draft or rejected rule can enter legal review.',array('status'=>409));
		if (empty($row['article_clause']) || empty($row['effective_from'])) return new WP_Error('hrx_rule_incomplete','Source checksum, clause, and effective date are required.',array('status'=>409));
		$source=$this->validate_statutory_source($row); if (is_wp_error($source)) return $source;
		$now=Stockland_HRX::now(); if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start legal review transaction.',array('status'=>500));
		$ok=$GLOBALS['wpdb']->update($t,array('status'=>'LEGAL_REVIEW','legal_reviewer_id'=>get_current_user_id(),'legal_reviewed_at'=>$now,'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>$row['status'],'row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Statutory rule changed concurrently.',array('status'=>409)); }
		if (!Stockland_HRX::audit('statutory_rules',$id,'LEGAL_REVIEW',$row['status'],'LEGAL_REVIEW',$row,array('source_sha256'=>$row['source_sha256'],'reviewer_id'=>get_current_user_id()))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Legal review audit failed; status was not changed.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Legal review transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'status'=>'LEGAL_REVIEW','reviewer_id'=>get_current_user_id(),'reviewed_at'=>$now));
	}
	public function approve_statutory_rule($r) {
		if (!Stockland_Authority::can_approve_payroll()) return new WP_Error('hrx_owner_only','Owner approval capability required.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$t=Stockland_HRX::table('statutory_rules'); $id=absint($r['id']); $row=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE id=%d",$id),ARRAY_A);
		if (!$row) return new WP_Error('hrx_not_found','Statutory rule not found.',array('status'=>404));
		if ($row['status']!=='LEGAL_REVIEW' || empty($row['legal_reviewer_id']) || empty($row['legal_reviewed_at'])) return new WP_Error('hrx_rule_state','A qualified legal review must be recorded first.',array('status'=>409));
		$source=$this->validate_statutory_source($row); if (is_wp_error($source)) return $source;
		if ((int)$row['legal_reviewer_id']===get_current_user_id() || (int)$row['created_by']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The rule preparer and legal reviewer must both be different from the Owner approver.',array('status'=>403));
		$params=json_decode((string)$row['rule_parameters_json'],true); if (!is_array($params)) return new WP_Error('hrx_rule_invalid','Rule parameters are invalid JSON.',array('status'=>409));
		$kind=strtoupper((string)$row['rule_kind']); $method=strtoupper((string)$row['calculation_method']);
		if ($row['effective_to']!==null && $row['effective_to']!=='' && $row['effective_to']<$row['effective_from']) return new WP_Error('hrx_rule_dates','Rule end date precedes its effective start date.',array('status'=>409));
		if ($kind==='PAYE') { if ($method!=='PROGRESSIVE_BANDS' || empty($params['bands']) || !is_array($params['bands'])) return new WP_Error('hrx_rule_invalid','PAYE requires progressive marginal bands with explicit thresholds in minor currency units and an open-ended final band.',array('status'=>409)); try { Stockland_HRX::progressive_tax_minor(0,$params['bands']); } catch (Throwable $e) { return new WP_Error('hrx_rule_invalid',$e->getMessage(),array('status'=>409)); } }
		elseif (in_array($kind,array('EMPLOYEE_PENSION','EMPLOYER_PENSION'),true)) { if ($method!=='RATE_BPS' || !isset($params['rate_bps']) || !is_numeric($params['rate_bps']) || (int)$params['rate_bps']<0 || (int)$params['rate_bps']>10000) return new WP_Error('hrx_rule_invalid','Pension rule requires a separately reviewed rate_bps value from 0 to 10000.',array('status'=>409)); }
		elseif ($method!=='EFFECTIVE_POLICY') return new WP_Error('hrx_rule_invalid','Non-tax statutory rules must use the EFFECTIVE_POLICY method in this candidate.',array('status'=>409));
		$now=Stockland_HRX::now(); if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start rule approval transaction.',array('status'=>500));
		$ok=$GLOBALS['wpdb']->update($t,array('status'=>'APPROVED','approved_by'=>get_current_user_id(),'approved_at'=>$now,'row_version'=>(int)$row['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>$id,'status'=>'LEGAL_REVIEW','row_version'=>(int)$row['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Statutory rule changed concurrently.',array('status'=>409)); }
		if (!Stockland_HRX::audit('statutory_rules',$id,'RULE_APPROVED','LEGAL_REVIEW','APPROVED',$row,array('source_sha256'=>$row['source_sha256'],'approver_id'=>get_current_user_id()))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Rule approval audit failed; status was not changed.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Rule approval transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'status'=>'APPROVED','approved_by'=>get_current_user_id(),'approved_at'=>$now,'legal_compliance_certified'=>false));
	}

	private function payroll_run($id) {
		$t=Stockland_HRX::table('payroll_runs');
		return $GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE id=%d",absint($id)),ARRAY_A);
	}
	private function approved_rules($date) {
		$t=Stockland_HRX::table('statutory_rules'); $out=array();
		$rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE status='APPROVED' AND effective_from<=%s AND (effective_to IS NULL OR effective_to>=%s) ORDER BY effective_from DESC FOR UPDATE",$date,$date),ARRAY_A);
		foreach ((array)$rows as $row) { if (!isset($out[$row['rule_kind']])) $out[$row['rule_kind']]=$row; else return new WP_Error('hrx_rule_overlap','More than one approved statutory rule applies to this date for '.$row['rule_kind'].'. Payroll is blocked until the overlapping effective dates are corrected.',array('status'=>409)); }
		foreach (array('PAYE','EMPLOYEE_PENSION','EMPLOYER_PENSION') as $kind) {
			if (empty($out[$kind]) || empty($out[$kind]['legal_reviewer_id']) || empty($out[$kind]['legal_reviewed_at']) || empty($out[$kind]['approved_by']) || empty($out[$kind]['approved_at']) || (int)$out[$kind]['legal_reviewer_id']===(int)$out[$kind]['approved_by'] || !preg_match('/^[a-f0-9]{64}$/i',(string)$out[$kind]['source_sha256'])) return new WP_Error('hrx_rule_missing','Missing independently reviewed, effective-dated, approved rule: '.$kind.'. PAYE and pension cannot be guessed or activated.',array('status'=>409));
			$source=$this->validate_statutory_source($out[$kind]); if (is_wp_error($source)) return new WP_Error('hrx_rule_source_invalid','Approved '.$kind.' source evidence no longer verifies. Payroll is blocked until the official source file and checksum are corrected through governed rule review.',array('status'=>409));
		}
		return $out;
	}
	private function payroll_snapshot($run) {
		$emp=Stockland_HRX::table('employments'); $comp=Stockland_HRX::table('compensation_assignments'); $items=Stockland_HRX::table('compensation_items');
		$partial_rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT id FROM {$emp} WHERE employment_type='EMPLOYEE' AND ((status='EXIT_PENDING') OR (start_date>%s AND start_date<=%s) OR (end_date IS NOT NULL AND end_date>=%s AND end_date<=%s)) FOR UPDATE",$run['start_date'],$run['end_date'],$run['start_date'],$run['end_date']),ARRAY_A);
		if (!is_array($partial_rows)) return new WP_Error('hrx_input_read_failed','Employment records could not be read; payroll is blocked.',array('status'=>500));
		if (count($partial_rows)>0) return new WP_Error('hrx_proration_unapproved','This period contains a joiner, leaver, or exit-pending employee. Proration/final-pay rules are not legally approved, so calculation is blocked.',array('status'=>409));
		$sql="SELECT e.id,e.employee_no,e.person_id,e.start_date,e.end_date,e.status,e.employment_type,e.location_id,c.id AS assignment_id,c.effective_from,c.effective_to,c.base_salary,c.base_tax_status,c.base_pension_status,c.currency,c.status AS compensation_status FROM {$emp} e LEFT JOIN {$comp} c ON c.employment_id=e.id AND c.effective_from<=%s AND (c.effective_to IS NULL OR c.effective_to>=%s) AND c.status='APPROVED' WHERE e.status='ACTIVE' AND e.employment_type='EMPLOYEE' AND e.start_date<=%s AND (e.end_date IS NULL OR e.end_date>=%s) ORDER BY e.id FOR UPDATE";
		$rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare($sql,$run['end_date'],$run['start_date'],$run['start_date'],$run['end_date']),ARRAY_A);
		if (!is_array($rows)||!$rows) return new WP_Error('hrx_no_eligible_employees','No active employee with a full-period employment relationship is available to calculate.',array('status'=>409));
		$out=array(); $seen_employment=array();
		foreach ($rows as $e) {
			if (isset($seen_employment[(int)$e['id']])) return new WP_Error('hrx_compensation_overlap','More than one approved compensation assignment overlaps the pay period for '.$e['employee_no'].'.',array('status'=>409));
			$seen_employment[(int)$e['id']]=true;
			if (substr((string)$e['start_date'],0,7)!==$run['period_key'] && $e['start_date']>$run['start_date']) return new WP_Error('hrx_proration_unapproved','Joiner proration needs an approved, effective-dated rule. Payroll is blocked for '.$e['employee_no'].'.',array('status'=>409));
			if (!empty($e['end_date']) && substr((string)$e['end_date'],0,7)===$run['period_key']) return new WP_Error('hrx_proration_unapproved','Leaver proration/final pay needs approved rules. Payroll is blocked for '.$e['employee_no'].'.',array('status'=>409));
			if (empty($e['assignment_id']) || $e['base_salary']==='' || !Stockland_HRX::valid_money($e['base_salary']) || !in_array($e['base_tax_status'],array('TAXABLE','EXEMPT'),true) || !in_array($e['base_pension_status'],array('PENSIONABLE','NON_PENSIONABLE'),true) || $e['currency']!=='ETB') return new WP_Error('hrx_compensation_review','An employee is missing approved pay or has unresolved tax/pension classification: '.$e['employee_no'].'.',array('status'=>409));
			$it=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT * FROM {$items} WHERE assignment_id=%d ORDER BY id",(int)$e['assignment_id']),ARRAY_A);
			if (!is_array($it)) return new WP_Error('hrx_compensation_read_failed','Could not read compensation items.',array('status'=>500));
			foreach ($it as $item) {
				if (!in_array($item['status'],array('APPROVED'),true) || !in_array($item['tax_status'],array('TAXABLE','EXEMPT'),true) || !in_array($item['pension_status'],array('PENSIONABLE','NON_PENSIONABLE'),true) || !in_array($item['component_type'],array('EARNING','DEDUCTION'),true) || !Stockland_HRX::valid_money($item['amount'])) return new WP_Error('hrx_component_review','A compensation item has an unapproved amount/type/tax/pension classification: '.$e['employee_no'].'.',array('status'=>409));
				if (($item['frequency']??'MONTHLY')!=='MONTHLY') return new WP_Error('hrx_component_frequency','Non-monthly component '.$item['component_code'].' requires a dated earning/adjustment schedule. It cannot be repeated as a monthly amount.',array('status'=>409));
			}
			$time=Stockland_HRX::table('time_events'); $leave=Stockland_HRX::table('leave_requests'); $separations=Stockland_HRX::table('separation_cases');
			$time_rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT id FROM {$time} WHERE employment_id=%d AND event_date BETWEEN %s AND %s AND status NOT IN ('REJECTED','CANCELLED','VOID') FOR UPDATE",(int)$e['id'],$run['start_date'],$run['end_date']),ARRAY_A);
			$leave_rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT id FROM {$leave} WHERE employment_id=%d AND status IN ('SUBMITTED','APPROVED') AND start_date<=%s AND end_date>=%s FOR UPDATE",(int)$e['id'],$run['end_date'],$run['start_date']),ARRAY_A);
			$exit_rows=$GLOBALS['wpdb']->get_results($GLOBALS['wpdb']->prepare("SELECT id,status FROM {$separations} WHERE employment_id=%d AND effective_date BETWEEN %s AND %s AND status NOT IN ('REJECTED','CLOSED') FOR UPDATE",(int)$e['id'],$run['start_date'],$run['end_date']),ARRAY_A);
			if (!is_array($time_rows)||!is_array($leave_rows)||!is_array($exit_rows)) return new WP_Error('hrx_input_read_failed','Attendance/leave/separation evidence could not be read; payroll is blocked.',array('status'=>500));
			if (count($time_rows)>0 || count($leave_rows)>0 || count($exit_rows)>0) return new WP_Error('hrx_time_leave_gate','Attendance, leave or separation records exist for '.$e['employee_no'].'. This candidate has no validated earnings/accrual/proration/final-settlement engine for those inputs, so payroll is blocked.',array('status'=>409));
			$e['items']=$it; $out[]=$e;
		}
		return $out;
	}
	public function payroll_freeze($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','Management prepares and freezes payroll inputs.',array('status'=>403));
		$t=Stockland_HRX::table('payroll_runs');
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payroll freeze transaction.',array('status'=>500));
		$run=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$t} WHERE id=%d FOR UPDATE",absint($r['id'])),ARRAY_A);
		if (!$run) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404)); }
		if ($run['status']!=='DRAFT') { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payroll_state','Only a draft payroll run can be frozen.',array('status'=>409)); }
		$rules=$this->approved_rules($run['end_date']); if (is_wp_error($rules)) { $GLOBALS['wpdb']->query('ROLLBACK'); return $rules; }
		$snapshot=$this->payroll_snapshot($run); if (is_wp_error($snapshot)) { $GLOBALS['wpdb']->query('ROLLBACK'); return $snapshot; }
		$hash=hash('sha256',wp_json_encode($snapshot)); $rules_hash=hash('sha256',wp_json_encode(array_map(function($x){return array('id'=>$x['id'],'rule_code'=>$x['rule_code'],'source_sha256'=>$x['source_sha256'],'effective_from'=>$x['effective_from'],'effective_to'=>$x['effective_to']);},$rules)));
		$now=Stockland_HRX::now();
		$ok=$GLOBALS['wpdb']->query($GLOBALS['wpdb']->prepare("UPDATE {$t} SET status='INPUTS_FROZEN',input_snapshot_hash=%s,rule_snapshot_hash=%s,cutoff_at=%s,row_version=row_version+1,updated_by=%d,updated_at=%s WHERE id=%d AND status='DRAFT' AND row_version=%d",$hash,$rules_hash,$now,get_current_user_id(),$now,(int)$run['id'],(int)$run['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Payroll run changed concurrently. Refresh and retry.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payroll_runs',(int)$run['id'],'INPUTS_FROZEN','DRAFT','INPUTS_FROZEN',array('hash'=>$run['input_snapshot_hash']),array('input_snapshot_hash'=>$hash,'rule_snapshot_hash'=>$rules_hash,'employee_count'=>count($snapshot)))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Freeze audit failed; the payroll run was not frozen.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Payroll freeze transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>(int)$run['id'],'status'=>'INPUTS_FROZEN','employee_count'=>count($snapshot),'snapshot_sha256'=>$hash,'rule_snapshot_sha256'=>$rules_hash));
	}

	public function payroll_calculate($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','Management calculates payroll for independent review.',array('status'=>403));
		$run_table=Stockland_HRX::table('payroll_runs');
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payroll calculation transaction.',array('status'=>500));
		$run=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$run_table} WHERE id=%d FOR UPDATE",absint($r['id'])),ARRAY_A);
		if (!$run) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404)); }
		if ($run['status']!=='INPUTS_FROZEN') { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payroll_state','Only a frozen-input run can be calculated.',array('status'=>409)); }
		$rules=$this->approved_rules($run['end_date']); if (is_wp_error($rules)) { $GLOBALS['wpdb']->query('ROLLBACK'); return $rules; }
		$snapshot=$this->payroll_snapshot($run); if (is_wp_error($snapshot)) { $GLOBALS['wpdb']->query('ROLLBACK'); return $snapshot; }
		if (!hash_equals((string)$run['input_snapshot_hash'],hash('sha256',wp_json_encode($snapshot)))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_snapshot_changed','Inputs changed after the freeze. Reopen through a controlled correction workflow; do not recalculate a changed snapshot.',array('status'=>409)); }
		$params=array(); foreach ($rules as $kind=>$rule) { $params[$kind]=json_decode($rule['rule_parameters_json'],true); if (!is_array($params[$kind])) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_rule_invalid','Approved rule parameters are not valid JSON.',array('status'=>409)); } }
		if (empty($params['PAYE']['bands']) || !is_array($params['PAYE']['bands']) || !isset($params['EMPLOYEE_PENSION']['rate_bps'],$params['EMPLOYER_PENSION']['rate_bps'])) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_rule_invalid','Approved PAYE bands and separate employee/employer pension rates are required.',array('status'=>409)); }
		try {
			Stockland_HRX::progressive_tax_minor(0,$params['PAYE']['bands']);
			foreach (array('EMPLOYEE_PENSION','EMPLOYER_PENSION') as $kind) { if (!is_numeric($params[$kind]['rate_bps']) || (int)$params[$kind]['rate_bps']<0 || (int)$params[$kind]['rate_bps']>10000) throw new RuntimeException('Approved pension rate is outside the valid 0–10000 basis-point range: '.$kind); }
		} catch (Throwable $e) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_rule_invalid',$e->getMessage(),array('status'=>409)); }
		$line_table=Stockland_HRX::table('payroll_lines'); $item_table=Stockland_HRX::table('payroll_line_items');
		$existing=(int)$GLOBALS['wpdb']->get_var($GLOBALS['wpdb']->prepare("SELECT COUNT(*) FROM {$line_table} WHERE payroll_run_id=%d FOR UPDATE",(int)$run['id']));
		if ($existing>0) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payroll_immutable','A payroll run already has calculation lines. Use an approved linked adjustment/reversal run.',array('status'=>409)); }
		$line_count=0; $totals=array_fill_keys(array('gross','taxable','paye','employee_pension','employer_pension','other_deductions','net','employer_cost'),0);
		try {
			foreach ($snapshot as $e) {
				$base=Stockland_Money::minor($e['base_salary']); $gross=$base; $taxable=$e['base_tax_status']==='TAXABLE'?$base:0; $pensionable=$e['base_pension_status']==='PENSIONABLE'?$base:0; $deductions=0; $line_items=array();
				$line_items[]=array('component_code'=>'BASE_SALARY','label'=>'Base salary','item_type'=>'EARNING','amount'=>Stockland_Money::decimal($base),'tax_classification'=>$e['base_tax_status'],'pension_classification'=>$e['base_pension_status'],'rule_id'=>null,'source_type'=>'COMPENSATION_ASSIGNMENT','source_id'=>(int)$e['assignment_id'],'calculation_trace'=>array('source'=>'approved effective-dated base salary'));
				foreach ($e['items'] as $it) {
					$minor=Stockland_Money::minor($it['amount']);
					if ($it['component_type']==='EARNING') { $gross+=$minor; if ($it['tax_status']==='TAXABLE') $taxable+=$minor; if ($it['pension_status']==='PENSIONABLE') $pensionable+=$minor; }
					else { $deductions+=$minor; }
					$line_items[]=array('component_code'=>$it['component_code'],'label'=>$it['label'],'item_type'=>$it['component_type'],'amount'=>Stockland_Money::decimal($minor),'tax_classification'=>$it['tax_status'],'pension_classification'=>$it['pension_status'],'rule_id'=>null,'source_type'=>'COMPENSATION_ITEM','source_id'=>(int)$it['id'],'calculation_trace'=>array('approved monthly compensation item'));
				}
				$paye=Stockland_HRX::progressive_tax_minor($taxable,$params['PAYE']['bands']);
				$employee_pension=Stockland_HRX::rounded_ratio($pensionable*(int)$params['EMPLOYEE_PENSION']['rate_bps'],10000);
				$employer_pension=Stockland_HRX::rounded_ratio($pensionable*(int)$params['EMPLOYER_PENSION']['rate_bps'],10000);
				$net=$gross-$paye-$employee_pension-$deductions; if ($net<0) throw new RuntimeException('Calculated deductions exceed gross pay for employee '.$e['employee_no'].'.');
				$trace=array('method'=>'FROZEN_MONTHLY_GROSS_TO_NET','rule_ids'=>array_map(function($x){return (int)$x['id'];},$rules),'source_snapshot_sha256'=>$run['input_snapshot_hash'],'currency'=>'ETB','note'=>'Attendance/leave/overtime/proration/final settlement are blocked when relevant records or partial employment periods exist.');
				$wpdb=$GLOBALS['wpdb'];
				$ok=$wpdb->insert($line_table,array('payroll_run_id'=>(int)$run['id'],'employment_id'=>(int)$e['id'],'employee_no'=>$e['employee_no'],'employee_name_snapshot'=>'Restricted employee '.$e['employee_no'],'source_snapshot_hash'=>hash('sha256',wp_json_encode($e)),'gross_pay'=>Stockland_Money::decimal($gross),'taxable_income'=>Stockland_Money::decimal($taxable),'pensionable_income'=>Stockland_Money::decimal($pensionable),'paye'=>Stockland_Money::decimal($paye),'employee_pension'=>Stockland_Money::decimal($employee_pension),'employer_pension'=>Stockland_Money::decimal($employer_pension),'other_deductions'=>Stockland_Money::decimal($deductions),'net_pay'=>Stockland_Money::decimal($net),'employer_cost'=>Stockland_Money::decimal($gross+$employer_pension),'calculation_trace'=>wp_json_encode($trace),'status'=>'CALCULATED','created_by'=>get_current_user_id(),'updated_by'=>get_current_user_id(),'created_at'=>Stockland_HRX::now(),'updated_at'=>Stockland_HRX::now()));
				if (!$ok) throw new RuntimeException('Payroll line insert failed.'); $line_id=(int)$wpdb->insert_id;
				foreach ($line_items as $li) { $li['payroll_line_id']=$line_id; $li['calculation_trace']=wp_json_encode($li['calculation_trace']); $li['status']='CALCULATED'; $li['created_by']=get_current_user_id(); $li['updated_by']=get_current_user_id(); $li['created_at']=Stockland_HRX::now(); $li['updated_at']=Stockland_HRX::now(); if (!$wpdb->insert($item_table,$li)) throw new RuntimeException('Payroll line item insert failed.'); }
				foreach (array('gross'=>$gross,'taxable'=>$taxable,'paye'=>$paye,'employee_pension'=>$employee_pension,'employer_pension'=>$employer_pension,'other_deductions'=>$deductions,'net'=>$net,'employer_cost'=>$gross+$employer_pension) as $k=>$v) $totals[$k]+=$v;
				$line_count++;
			}
			$now=Stockland_HRX::now();
			$updated=$GLOBALS['wpdb']->update($run_table,array('status'=>'CALCULATED','employee_count'=>$line_count,'gross_total'=>Stockland_Money::decimal($totals['gross']),'taxable_total'=>Stockland_Money::decimal($totals['taxable']),'paye_total'=>Stockland_Money::decimal($totals['paye']),'employee_pension_total'=>Stockland_Money::decimal($totals['employee_pension']),'employer_pension_total'=>Stockland_Money::decimal($totals['employer_pension']),'other_deduction_total'=>Stockland_Money::decimal($totals['other_deductions']),'net_total'=>Stockland_Money::decimal($totals['net']),'employer_cost_total'=>Stockland_Money::decimal($totals['employer_cost']),'row_version'=>(int)$run['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>(int)$run['id'],'status'=>'INPUTS_FROZEN','row_version'=>(int)$run['row_version']));
			if (1!==$updated) throw new RuntimeException('Payroll run changed concurrently.');
			if (!Stockland_HRX::audit('payroll_runs',(int)$run['id'],'CALCULATE','INPUTS_FROZEN','CALCULATED',null,$totals,array('employee_count'=>$line_count))) throw new RuntimeException('Payroll calculation audit could not be saved.');
			if (false===$GLOBALS['wpdb']->query('COMMIT')) throw new RuntimeException('Payroll calculation transaction failed to commit.');
		} catch (Throwable $e) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payroll_calculation_failed','Payroll was not finalized: '.$e->getMessage(),array('status'=>409)); }
		return rest_ensure_response(array('id'=>(int)$run['id'],'status'=>'CALCULATED','employee_count'=>$line_count,'totals'=>array_map(function($v){return Stockland_Money::decimal($v);},$totals),'statutory_rules'=>'approved effective-dated snapshots','legacy_tables_changed'=>false));
	}

	public function payroll_review($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','An authorized Management/Finance reviewer must review the calculation before submission.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$id=absint($r['id']); $table=Stockland_HRX::table('payroll_runs'); $lines=Stockland_HRX::table('payroll_lines');
		$body=$r->get_json_params(); $note=sanitize_textarea_field((string)($body['review_note']??''));
		if (strlen($note)<10) return new WP_Error('hrx_review_note','Enter a review note of at least 10 characters, explaining checks performed and any variance disposition.',array('status'=>400));
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payroll review transaction.',array('status'=>500));
		$run=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT * FROM {$table} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
		if (!$run) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404)); }
		if ($run['status']!=='CALCULATED') { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_payroll_state','Only a calculated payroll run can be independently reviewed.',array('status'=>409)); }
		if ((int)$run['prepared_by']===get_current_user_id()) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_maker_checker','Payroll preparer cannot review their own calculation.',array('status'=>403)); }
		$totals=$GLOBALS['wpdb']->get_row($GLOBALS['wpdb']->prepare("SELECT COUNT(*) AS line_count,COALESCE(SUM(gross_pay),0) AS gross_total,COALESCE(SUM(taxable_income),0) AS taxable_total,COALESCE(SUM(paye),0) AS paye_total,COALESCE(SUM(employee_pension),0) AS employee_pension_total,COALESCE(SUM(employer_pension),0) AS employer_pension_total,COALESCE(SUM(other_deductions),0) AS other_deduction_total,COALESCE(SUM(net_pay),0) AS net_total,COALESCE(SUM(employer_cost),0) AS employer_cost_total FROM {$lines} WHERE payroll_run_id=%d AND status='CALCULATED'",$id),ARRAY_A);
		if (!is_array($totals) || (int)$totals['line_count']<1) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_review_lines','No calculated payroll lines were available for reconciliation.',array('status'=>409)); }
		$columns=array('gross_total'=>'gross_total','taxable_total'=>'taxable_total','paye_total'=>'paye_total','employee_pension_total'=>'employee_pension_total','employer_pension_total'=>'employer_pension_total','other_deduction_total'=>'other_deduction_total','net_total'=>'net_total','employer_cost_total'=>'employer_cost_total');
		foreach ($columns as $source=>$target) { if (Stockland_Money::minor($totals[$source])!==Stockland_Money::minor($run[$target])) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_review_totals','Payroll line totals do not reconcile with the run total for '.$target.'. Review is blocked.',array('status'=>409)); } }
		if ((int)$totals['line_count']!==(int)$run['employee_count']) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_review_count','Payroll employee count does not match the calculated line count.',array('status'=>409)); }
		$now=Stockland_HRX::now(); $set=array('status'=>'REVIEWED','reviewer_id'=>get_current_user_id(),'reviewed_at'=>$now,'review_note'=>$note,'row_version'=>(int)$run['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now);
		$ok=$GLOBALS['wpdb']->update($table,$set,array('id'=>$id,'status'=>'CALCULATED','row_version'=>(int)$run['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Payroll run changed during independent review.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payroll_runs',$id,'INDEPENDENT_REVIEW','CALCULATED','REVIEWED',$run,array('reviewer_id'=>get_current_user_id(),'review_note_sha256'=>hash('sha256',$note),'reconciled_totals'=>$totals))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Payroll review audit failed; the status was not changed.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Payroll review transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>$id,'status'=>'REVIEWED','reviewer_id'=>get_current_user_id(),'reviewed_at'=>$now,'reviewed_line_count'=>(int)$totals['line_count']));
	}
	public function payroll_submit($r) {
		if (!Stockland_Authority::can_manage_payroll()) return new WP_Error('hrx_management_only','Only authorized Management may submit a reviewed payroll run for independent Owner approval.',array('status'=>403));
		$run=$this->payroll_run($r['id']); if (!$run) return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404));
		if (empty($run['reviewer_id']) || empty($run['reviewed_at']) || (int)$run['reviewer_id']===(int)$run['prepared_by']) return new WP_Error('hrx_review_required','A separate reviewer must verify calculated payroll lines and totals before submission.',array('status'=>409));
		return $this->payroll_status_action($r,'REVIEWED','SUBMITTED',false);
	}
	public function payroll_approve($r) {
		if (!Stockland_Authority::can_approve_payroll()) return new WP_Error('hrx_owner_only','Only the authorized Owner can approve payroll.',array('status'=>403));
		$run=$this->payroll_run($r['id']); if (!$run) return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404));
		if (empty($run['reviewer_id']) || empty($run['reviewed_at']) || (int)$run['reviewer_id']===(int)$run['prepared_by']) return new WP_Error('hrx_review_required','A separate reviewer receipt is required before Owner approval.',array('status'=>409));
		if ((int)$run['prepared_by']===get_current_user_id() || (int)$run['reviewer_id']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The payroll preparer or independent reviewer cannot approve their own run as Owner.',array('status'=>403));
		return $this->payroll_status_action($r,'SUBMITTED','OWNER_APPROVED',true);
	}
	private function payroll_status_action($r,$from,$to,$owner) {
		$run=$this->payroll_run($r['id']); if (!$run) return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404));
		if ($run['status']!==$from) return new WP_Error('hrx_payroll_state','Payroll status must be '.$from.' before '.$to.'.',array('status'=>409));
		if ($owner && ((int)$run['prepared_by']===get_current_user_id() || (int)$run['reviewer_id']===get_current_user_id())) return new WP_Error('hrx_maker_checker','The payroll preparer or independent reviewer cannot approve their own run as Owner.',array('status'=>403));
		$t=Stockland_HRX::table('payroll_runs'); $now=Stockland_HRX::now(); $set=array('status'=>$to,'row_version'=>(int)$run['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now);
		if ($owner) { $set['owner_approved_by']=get_current_user_id(); $set['owner_approved_at']=$now; }
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payroll approval transaction.',array('status'=>500));
		$updated=$GLOBALS['wpdb']->update($t,$set,array('id'=>(int)$run['id'],'status'=>$from,'row_version'=>(int)$run['row_version']));
		if (1!==$updated) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_concurrency','Payroll status changed concurrently.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payroll_runs',(int)$run['id'],$to,$from,$to,$run,$set)) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Approval audit failed; payroll status was not changed.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Payroll approval transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>(int)$run['id'],'status'=>$to));
	}

	public function payroll_post($r) {
		if (!Stockland_Authority::can_approve_payroll()) return new WP_Error('hrx_owner_only','Only the authorized Owner can post approved payroll.',array('status'=>403));
		$ready=$this->require_ready(); if (is_wp_error($ready)) return $ready;
		$run=$this->payroll_run($r['id']); if (!$run) return new WP_Error('hrx_not_found','Payroll run was not found.',array('status'=>404));
		if ($run['status']!=='OWNER_APPROVED') return new WP_Error('hrx_payroll_state','Owner approval is required before posting.',array('status'=>409));
		if ((int)$run['prepared_by']===get_current_user_id() || (int)$run['reviewer_id']===get_current_user_id()) return new WP_Error('hrx_maker_checker','The payroll preparer or independent reviewer cannot post their own run as Owner.',array('status'=>403));
		if (empty($run['reviewer_id']) || empty($run['reviewed_at']) || (int)$run['reviewer_id']===(int)$run['prepared_by']) return new WP_Error('hrx_review_required','A separate reviewer receipt is required before posting.',array('status'=>409));
		if (empty($run['owner_approved_by']) || (int)$run['owner_approved_by']===(int)$run['prepared_by']) return new WP_Error('hrx_owner_approval_missing','A separate Owner approval receipt is required before posting.',array('status'=>409));
		if (!Stockland_Accounting::ensure_payroll_statutory_accounts()) return new WP_Error('hrx_gl_accounts','Payroll statutory ledger accounts are invalid or unavailable.',array('status'=>409));
		$lines=array(
			array('account_code'=>'6200','debit'=>$run['gross_total'],'credit'=>'0.00'),
			array('account_code'=>'6210','debit'=>$run['employer_pension_total'],'credit'=>'0.00'),
			array('account_code'=>'2020','debit'=>'0.00','credit'=>$run['net_total']),
			array('account_code'=>'2030','debit'=>'0.00','credit'=>$run['employee_pension_total']),
			array('account_code'=>'2031','debit'=>'0.00','credit'=>$run['paye_total']),
			array('account_code'=>'2032','debit'=>'0.00','credit'=>$run['employer_pension_total']),
			array('account_code'=>'2033','debit'=>'0.00','credit'=>$run['other_deduction_total']),
		);
		// post_journal is savepoint-aware; the enclosing transaction covers the HRX run state and audit too.
		if (false===$GLOBALS['wpdb']->query('START TRANSACTION')) return new WP_Error('hrx_txn','Could not start payroll posting transaction.',array('status'=>500));
		$jid=Stockland_Accounting::post_journal($run['end_date'],'HRX_PAYROLL',(int)$run['id'],'HRX payroll '.$run['period_key'],$lines,get_current_user_id());
		if (!$jid) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_gl_post_failed','Balanced GL/PLEDGER posting failed; payroll remains unposted.',array('status'=>409)); }
		$t=Stockland_HRX::table('payroll_runs'); $now=Stockland_HRX::now();
		$ok=$GLOBALS['wpdb']->update($t,array('status'=>'POSTED','journal_id'=>(int)$jid,'posted_at'=>$now,'row_version'=>(int)$run['row_version']+1,'updated_by'=>get_current_user_id(),'updated_at'=>$now),array('id'=>(int)$run['id'],'status'=>'OWNER_APPROVED','row_version'=>(int)$run['row_version']));
		if (1!==$ok) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_post_state_conflict','Payroll state could not be committed; posting and run state were rolled back together.',array('status'=>409)); }
		if (!Stockland_HRX::audit('payroll_runs',(int)$run['id'],'POST','OWNER_APPROVED','POSTED',$run,array('journal_id'=>(int)$jid))) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_audit_failed','Posting audit failed; payroll and journal were rolled back together.',array('status'=>500)); }
		if (false===$GLOBALS['wpdb']->query('COMMIT')) { $GLOBALS['wpdb']->query('ROLLBACK'); return new WP_Error('hrx_txn_commit','Payroll posting transaction failed to commit.',array('status'=>500)); }
		return rest_ensure_response(array('id'=>(int)$run['id'],'status'=>'POSTED','journal_id'=>(int)$jid));
	}

}
