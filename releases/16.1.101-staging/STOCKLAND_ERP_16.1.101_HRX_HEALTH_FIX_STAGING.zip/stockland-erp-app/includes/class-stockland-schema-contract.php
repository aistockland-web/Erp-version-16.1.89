<?php
/**
 * Read-only schema contract classifier for Stockland's fixed ERP baseline plus
 * allow-listed additive extensions. Unknown stock-owned tables remain a failure.
 *
 * @package Stockland_ERP
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Stockland_Schema_Contract {
    /**
     * Classify physical table keys without touching the database.
     *
     * @param array $found_keys Physical keys below the wp_stock_ prefix.
     * @param array $base_expected The exact 49 legacy ERP table keys.
     * @param array $extension_expected Explicitly allowed extension keys, e.g. hrx_org_units.
     * @return array Schema contract assessment.
     */
    public static function assess( $found_keys, $base_expected, $extension_expected = array() ) {
        $normalize = static function ( $values ) {
            $normalized = array();
            foreach ( (array) $values as $value ) {
                if ( ! is_string( $value ) && ! is_numeric( $value ) ) {
                    continue;
                }
                $value = trim( (string) $value );
                if ( '' !== $value ) {
                    $normalized[] = $value;
                }
            }
            return array_values( array_unique( $normalized ) );
        };

        $found     = $normalize( $found_keys );
        $base      = $normalize( $base_expected );
        $extension = $normalize( $extension_expected );
        $allowed   = array_values( array_unique( array_merge( $base, $extension ) ) );

        $base_present      = array_values( array_intersect( $base, $found ) );
        $base_missing      = array_values( array_diff( $base, $found ) );
        $extension_present = array_values( array_intersect( $extension, $found ) );
        $extension_missing = array_values( array_diff( $extension, $found ) );
        $unexpected        = array_values( array_diff( $found, $allowed ) );

        return array(
            'base_expected_count'      => count( $base ),
            'base_present_count'       => count( $base_present ),
            'base_present'             => $base_present,
            'base_missing'             => $base_missing,
            'base_contract_exact'      => 49 === count( $base ) && 49 === count( $base_present ) && empty( $base_missing ) && empty( $unexpected ),
            'extension_expected_count' => count( $extension ),
            'extension_present_count'  => count( $extension_present ),
            'extension_present'        => $extension_present,
            'extension_missing'        => $extension_missing,
            'extension_complete'       => ! empty( $extension ) && empty( $extension_missing ),
            'unexpected_keys'          => $unexpected,
            'physical_table_count'     => count( $found ),
            'allowlisted_table_count'  => count( array_intersect( $allowed, $found ) ),
        );
    }
}
