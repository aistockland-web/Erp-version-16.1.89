<?php
/**
 * Captures and redacts fatal runtime diagnostics for System Control.
 *
 * @package Stockland_ERP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores a bounded, redacted summary of the latest fatal runtime failure.
 *
 * @package Stockland_ERP
 */
final class Stockland_Runtime_Diagnostics {
	const OPTION   = 'stockland_runtime_fatal_v1';
	const ALARM_OPTION = 'stockland_system_alarm_dedup_v1';
	const ALARM_COOLDOWN_SECONDS = 900;
	const MAX_TEXT = 1200;

	/**
	 * Lifecycle stage used to contextualize any captured fatal diagnostic.
	 *
	 * @var string
	 */
	private static $stage = 'plugin_boot';

	/** Register the shutdown handler that captures fatal PHP errors. */
	public static function boot() {
		register_shutdown_function( array( __CLASS__, 'capture_fatal' ) );
	}
	/**
	 * Set the lifecycle stage used in any subsequent fatal diagnostic.
	 *
	 * @param string $name Lifecycle stage identifier.
	 * @return void
	 */
	public static function stage( $name ) {
		$name        = sanitize_key( (string) $name );
		self::$stage = substr( '' !== $name ? $name : 'unknown', 0, 80 );
	}
	/**
	 * Writes a redacted diagnostic to the PHP error log only when debugging is enabled.
	 *
	 * Production error context is retained through the protected diagnostic option;
	 * forced logging is reserved for the case where that persistence itself fails.
	 *
	 * @param string $message Redacted diagnostic message.
	 * @param bool   $force Log even when WP_DEBUG is disabled because persistence failed.
	 * @return void
	 */
	public static function log_error( $message, $force = false ) {
		if ( ! $force && ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) ) {
			return;
		}
		$message = self::clean( (string) $message, self::MAX_TEXT );
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- This single gateway is deliberately gated by WP_DEBUG, or forced only when diagnostic persistence fails.
		error_log( 'Stockland ERP: ' . $message );
	}

	/** Capture the last fatal PHP error and persist its redacted metadata.
	 *
	 * @return void
	 */
	public static function capture_fatal() {
		$last = error_get_last();
		if ( ! is_array( $last ) ) {
			return;
		}
		$fatal_types = array( E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE, E_USER_ERROR );
		if ( ! in_array( (int) ( $last['type'] ?? 0 ), $fatal_types, true ) ) {
			return;
		}
		$message = self::clean( (string) ( $last['message'] ?? 'unknown fatal error' ) );
		$file    = (string) ( $last['file'] ?? 'unknown' );
		$line    = (int) ( $last['line'] ?? 0 );
		// Store the path only. Query strings commonly contain WP REST nonces,
		// setup cache-busters, and application-specific tokens; they are never
		// required to identify a failing route.
		// This is diagnostic-only request metadata; never retain query strings or nonces.
		$request_uri        = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		$uri                = self::request_path( $request_uri );
		$entry              = array(
			'reference'    => 'FATAL-' . gmdate( 'YmdHis' ) . '-' . substr( hash( 'sha256', $message . '|' . $file . '|' . $line . '|' . $uri ), 0, 8 ),
			'time_gmt'     => gmdate( 'Y-m-d H:i:s' ),
			'type'         => (int) ( $last['type'] ?? 0 ),
			'message'      => $message,
			'file'         => basename( $file ),
			'line'         => $line,
			'stage'        => self::$stage,
			'method'       => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '',
			'request_path' => $uri,
			'memory_usage' => function_exists( 'memory_get_usage' ) ? memory_get_usage( true ) : null,
			'memory_limit' => function_exists( 'ini_get' ) ? (string) ini_get( 'memory_limit' ) : '',
		);
		$persistence_failed = false;
		try {
			update_option( self::OPTION, $entry, false );
		} catch ( Throwable $e ) {
			// The shutdown logger below is the fallback when the option write fails.
			$persistence_failed = true;
		}
		self::notify_fatal_alarm( $entry );
		self::log_error( 'FATAL [' . $entry['reference'] . '] ' . $message . ' @ ' . $file . ':' . $line . ' stage=' . self::$stage . ' uri=' . $uri . ' persistence_failed=' . ( $persistence_failed ? 'yes' : 'no' ), $persistence_failed );
	}

	/** Create deduplicated internal owner/management alarms for an explicit deep-health failure.
	 *
	 * @param array $failed_checks Failed or unverified deep health check names.
	 * @return bool Whether an alarm was stored or safely deduplicated.
	 */
	public static function notify_health_alarm( $failed_checks ) {
		$failed_checks = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $failed_checks ) ) ) );
		if ( empty( $failed_checks ) ) {
			return false;
		}
		$fingerprint = 'deep_health:' . implode( ',', $failed_checks );
		$message = 'The explicit read-only deep health check reported failed or unverified gates: ' . implode( ', ', $failed_checks ) . '. Open System Health to inspect details. This notification contains no employee, payroll or customer data.';
		return self::create_internal_alarm( $fingerprint, 'Stockland ERP deep health requires attention', $message, 'danger' );
	}

	/** Create a privacy-minimized server-side alarm after a captured PHP fatal.
	 *
	 * @param array $entry Redacted fatal diagnostic.
	 * @return bool Whether an alarm was stored or safely deduplicated.
	 */
	private static function notify_fatal_alarm( $entry ) {
		$file = sanitize_file_name( basename( (string) ( $entry['file'] ?? 'unknown' ) ) );
		$line = absint( $entry['line'] ?? 0 );
		$stage = sanitize_key( (string) ( $entry['stage'] ?? 'unknown' ) );
		$fingerprint = 'fatal:' . (int) ( $entry['type'] ?? 0 ) . ':' . $file . ':' . $line . ':' . $stage;
		$message = 'A PHP fatal error was captured by the ERP shutdown handler. Reference: ' . self::clean( (string) ( $entry['reference'] ?? 'not recorded' ), 100 ) . '; stage: ' . $stage . '; source: ' . $file . ':' . $line . '; path: ' . self::request_path( (string) ( $entry['request_path'] ?? '/' ) ) . '. Review the restricted System Control / System Health screen. Detailed runtime text is not copied to this notification.';
		return self::create_internal_alarm( $fingerprint, 'Stockland ERP server alarm: PHP fatal error', $message, 'danger' );
	}

	/** Deliver an internal, deduplicated Owner/Management notification when DB and schema allow it.
	 * No email/SMS or third-party service is assumed.
	 *
	 * @param string $fingerprint Stable, non-PII alarm fingerprint.
	 * @param string $title Short alarm title.
	 * @param string $message Sanitized alarm summary.
	 * @param string $severity Notification severity.
	 * @return bool Whether an alarm was stored or safely deduplicated.
	 */
	private static function create_internal_alarm( $fingerprint, $title, $message, $severity = 'warning' ) {
		try {
			if ( ! class_exists( 'Stockland_Notifications' ) || ! class_exists( 'Stockland_DB' ) ) {
				return false;
			}
			global $wpdb;
			if ( ! $wpdb || ! Stockland_DB::table_exists( Stockland_DB::table( 'notifications' ) ) ) {
				return false;
			}
			$key = substr( hash( 'sha256', (string) $fingerprint ), 0, 40 );
			$now = time();
			$seen = get_option( self::ALARM_OPTION, array() );
			$seen = is_array( $seen ) ? $seen : array();
			if ( isset( $seen[ $key ] ) && is_numeric( $seen[ $key ] ) && ( $now - (int) $seen[ $key ] ) < self::ALARM_COOLDOWN_SECONDS ) {
				return true;
			}
			$title = self::clean( sanitize_text_field( (string) $title ), 180 );
			$message = self::clean( wp_strip_all_tags( (string) $message ), 650 );
			$owner_ok = Stockland_Notifications::push_role( 'owner', null, 'system_health_alarm', $title, $message, null, null, sanitize_key( $severity ) );
			$management_ok = Stockland_Notifications::push_role( 'management', null, 'system_health_alarm', $title, $message, null, null, sanitize_key( $severity ) );
			if ( $owner_ok || $management_ok ) {
				$seen[ $key ] = $now;
				arsort( $seen, SORT_NUMERIC );
				$seen = array_slice( $seen, 0, 50, true );
				update_option( self::ALARM_OPTION, $seen, false );
				return true;
			}
			return false;
		} catch ( Throwable $e ) {
			// Notification failure must never change ERP transaction results or mask a fatal.
			return false;
		}
	}

	/** Retrieve the last fatal diagnostic after redacting legacy request data.
	 *
	 * @return array<string, mixed> Redacted diagnostic record or an empty array.
	 */
	public static function last_fatal() {
		$v = get_option( self::OPTION, array() );
		if ( ! is_array( $v ) ) {
			return array();
		}
		// Redact legacy records written by earlier releases too, not just new
		// records. This avoids returning stored query secrets after an upgrade.
		if ( isset( $v['request_path'] ) ) {
			$v['request_path'] = self::request_path( (string) $v['request_path'] );
		}
		foreach ( array( 'reference', 'message', 'file', 'stage', 'method' ) as $key ) {
			if ( isset( $v[ $key ] ) && is_string( $v[ $key ] ) ) {
				$v[ $key ] = self::clean( $v[ $key ], 'message' === $key ? self::MAX_TEXT : 300 );
			}
		}
		return $v;
	}
	/**
	 * Return a bounded request path without query or fragment data.
	 *
	 * @param string $uri Raw request URI.
	 * @return string Redacted request path.
	 */
	private static function request_path( $uri ) {
		$raw_uri = (string) $uri;
		$path    = function_exists( 'wp_parse_url' )
			? wp_parse_url( $raw_uri, PHP_URL_PATH )
			: preg_replace( '/[?#].*$/', '', preg_replace( '#^[a-z][a-z0-9+.-]*://[^/]*#i', '', $raw_uri ) );
		if ( ! is_string( $path ) || '' === $path ) {
			$path = '/';
		}
		$path = preg_replace( '/[\x00-\x1F\x7F]/', '', $path );
		return self::clean( $path, 300 );
	}
	/**
	 * Collect read-only runtime and database capability checks.
	 *
	 * @return array<string, mixed> Environment diagnostics safe for System Control.
	 */
	public static function environment() {
		global $wpdb;
		$e = array(
			'php_version'            => PHP_VERSION,
			'wordpress_version'      => function_exists( 'get_bloginfo' ) ? get_bloginfo( 'version' ) : '',
			'memory_limit'           => (string) ini_get( 'memory_limit' ),
			'max_execution_time'     => (string) ini_get( 'max_execution_time' ),
			'upload_max_filesize'    => (string) ini_get( 'upload_max_filesize' ),
			'post_max_size'          => (string) ini_get( 'post_max_size' ),
			'zip_archive'            => class_exists( 'ZipArchive' ),
			'xml_reader'             => class_exists( 'XMLReader' ),
			'xml_reader_from_stream' => class_exists( 'XMLReader' ) && method_exists( 'XMLReader', 'fromStream' ),
			'simplexml'              => class_exists( 'SimpleXMLElement' ),
			'db_version'             => ( $wpdb && method_exists( $wpdb, 'db_version' ) ) ? (string) $wpdb->db_version() : '',
			'db_select_ok'           => false,
		);
		if ( $wpdb ) {
			try {
				$e['db_select_ok'] = ( (string) Stockland_DB::read_var( 'SELECT 1' ) === '1' );
			} catch ( Throwable $x ) {
				// Fail closed: the database probe remains false when the query throws.
				$e['db_select_ok'] = false;
			}
		}
		return $e;
	}
	/**
	 * Remove control characters and local filesystem path details from text.
	 *
	 * @param string $s Raw diagnostic text.
	 * @param int    $max Maximum number of characters to retain.
	 * @return string Sanitized, bounded diagnostic text.
	 */
	private static function clean( $s, $max = self::MAX_TEXT ) {
		$s = str_replace( array( "\0", "\r", "\n" ), ' ', (string) $s );
		if ( defined( 'ABSPATH' ) && ABSPATH !== '' ) {
			$s = str_replace( ABSPATH, '[ABSPATH]/', $s );
		}
		return function_exists( 'mb_substr' ) ? mb_substr( $s, 0, $max, 'UTF-8' ) : substr( $s, 0, $max );
	}
}
