# Stockland ERP 16.1.101 HRX health fix + DDL replay fix + visible SOP Library — STAGING ONLY

> **Do not install this ZIP over the live site.** The user reports the site is running `16.1.98-HRX-REVIEW-ONLY`, but the deployed plugin files have not been independently hash-compared with this local candidate. This candidate originates from the checksum-locked 16.1.95 baseline (`494e777247508d009dfdb216c9607bb1bc96717197e94a0e8ad3459b7cc81625`) plus local HRX/SOP review work. It must be tested first on an isolated clone of the exact live package and database, not treated as a cumulative production update.

This candidate adds a separately namespaced `stock_hrx_` HR/payroll model with **33 additive tables** while preserving the base 49-table contract and the four legacy HR/payroll tables (`employees`, `employee_compensation`, `payroll_periods`, `payroll_lines`). The candidate does not import, delete, truncate, or rewrite legacy HR/payroll records. Legacy HR/payroll GET/read endpoints remain for reconciliation, while legacy mutation endpoints return HTTP 409 in this candidate so that new test work is not split between two active authorities.

## Acceptance status

- **Locally tested:** HRX domain regression (727 assertions), exact schema-extension contract (12 assertions), runtime alarm deduplication (13 assertions), health contract/UI/source checks (21 assertions), and browser-resumable integrity batching (37 assertions, including nonzero and unknown early-batch regressions). All 51 application PHP files in the installer and five separate QA harnesses (56 PHP files total) pass syntax; both JavaScript files, the JSON manifests, and 24 DOCX hashes/document-control entries also pass.
- **Not verified here:** actual WordPress runtime, real MySQL/MariaDB `dbDelta` installation and replay, browser click-through, role/REST penetration tests, private file download authorization, backup/restore/rollback, migration of legacy HR history, two complete payroll cycles, GL/PLEDGER replay and reconciliation.
- **Deliberately blocked:** no HRX statutory rule is seeded or activated by default; salary and tax classification are never inferred. Payroll is blocked unless current official source evidence, actual PDF checksum, independent qualified review and separate Owner approval pass. Joiner/leaver proration, attendance/overtime and overlapping leave are also held until complete approved calculations exist. The private-document vault provider, complete AP/tax workflow for individual payees, and final-separation settlement engine are not yet integrated.
- **No production cutover:** require the project's complete ERD/dependency mapping, migration rehearsal, exact-package WordPress/MariaDB E2E, legal/SOP sign-offs, two parallel payroll periods, backup/restore, rollback and Owner/HR/Finance acceptance before retiring legacy APIs or data.

## How to use this candidate safely

1. Create a disposable staging WordPress instance and take a fresh backup. Do not point the candidate at the live database or overwrite an existing 16.1.97 plugin folder.
2. Upload the ZIP as a staging plugin, activate it, then sign in through Stockland ERP's native front end.
3. Open **HR & Payroll**. The first visit should show the additive-schema installation action; install only in the disposable staging database. The operation leaves legacy tables intact and records a schema receipt.
4. Use synthetic data only. Confirm that missing/invalid legal rules, missing compensation classifications, joiner/leaver periods, attendance/leave exceptions and unverified documents return blocking errors. Do not record simulated real payouts or actual employee data during this review.
5. Keep the report, package SHA-256 and every test failure with the staging run. This candidate is not yet authorized for payroll execution or production cutover.

---

# Locked baseline source notes — Stockland ERP 16.1.95 (historical baseline only)

## Baseline 16.1.95 — cumulative operational hardening from 16.1.94

This update corrects reserved SQL aliases in reports and imports, the missing reservations-table binding, first-activation ordering guards, plain-permalink REST URL handling, profile-less search/setup access, implicit day-close dates, and purchase-order over-receipt status. Existing stock and accounting posting logic remains the source of truth. The 49-table contract and DB schema markers are retained; the build does not mutate business records.

**Cloud AI status:** Management Intelligence provides permission-controlled, source-backed ERP analytics. No external Cloud AI/LLM provider is configured or called by this plugin. Do not send employee, financial, customer, or inventory data to an external provider until Stockland has approved the provider, data-handling rules, and integration credentials.

**Historical Owner-provided System Health (24 October 2026):** the earlier screen reported WordPress 7.1.3, PHP 8.4.27, MariaDB 11.4.13, 49/49 tables, 104 REST routes, a passing audit-chain check and unresolved employee compensation records. This older snapshot is superseded by the latest owner-provided snapshot below.

This release does not create sample employees, fill salary values, change historical postings or weaken the payroll gate. The package must be verified against the exact installed files before production replacement.

## Baseline-only installation notes (not instructions for this review candidate)

The historical 16.1.95 release instructions below describe the baseline release only. They do not authorize installing this HRX review candidate over an existing ERP deployment. Follow the staging-only instructions at the top of this README.

## ERP work areas

Command Center; Product Master; Inventory and Daily Inventory; Retail POS and Wholesale; Central Warehouse and Receiving; Purchase Orders; Requisitions and Reservations; Transfers; Returns, Damage and Adjustments; Finance and Procurement; AP/AR; PLEDGER and General Ledger; HR/Payroll; Reports & Analytics; Management Intelligence; Users/Roles; Audit Trail; Notifications and System Health.

## Stock, reorder and finance rules

Posted stock-ledger movements are the source of truth for physical movement history. Physical on-hand, active reservations, sellable availability and dispatched-but-unreceived transfers remain separate values. Legacy SKU-only movements/reservations are mapped to a canonical Product Master variant only when that mapping exists. Over-reservation remains visible as an integrity exception. Location-specific reorder thresholds must be configured; an unset threshold does not create a false reorder alert. Suggested replenishment is advisory and does not create a purchase order or change stock. In-transit quantities inform the reorder position but are not physical stock until destination receipt is posted.

The ERP uses its shared decimal-safe money service and server-side posting workflows. Historical sale prices, VAT values, staged COGS, posted payroll, journal entries and audit records must not be silently rewritten by later master-data edits. Required report queries fail closed when the database reports an error; an unavailable source must not be shown as a genuine zero.

## Legacy HR/payroll handling in this review candidate

The inherited 16.1.95 statutory model and four legacy HR tables remain in the source/database contract for historical read-only reconciliation. All legacy HR/payroll POST endpoints are disabled with HTTP 409 in this candidate to avoid parallel mutation paths. The new `stock_hrx_` domain does not inherit old statutory defaults, compensation or employee values.

The payroll state machine now requires preparer → independent Management/Finance reviewer (line-total reconciliation plus review note) → Owner approval; the preparer, reviewer and Owner approver must be three distinct actors for a run. The HRX rule registry has no seeded or activated rules. Final payroll is blocked until the actual official legal PDF is attached, the HTTPS `*.gov.et` source and SHA-256 are verified, a separately authorized qualified reviewer records legal review, and a different Owner approves the effective-dated rule. Payroll is also blocked where pay/tax/pension classifications are missing, attendance or leave exceptions exist, or an employee requires joiner/leaver proration that is not yet implemented and approved. The legacy 7%/11% pension constants in the inherited baseline are not automatically copied into HRX.

This candidate also does not yet integrate a verified private document vault, complete creator/freelancer AP/withholding workflow, legally approved final-settlement engine, or full legacy-to-HRX migration. Do not use real salaries, employee PII, or real-payment references during review. These are release blockers, not optional enhancements.

## Runtime

WordPress 6.8+; PHP 8.3+; MySQL 8.0+ or MariaDB 10.11+; HTTPS enabled. The plugin executes inside the existing WordPress/PHP environment on the configured host; it does not require a separate application service or worker for normal ERP operation. Use Stockland ERP's native sign-in, role-based access, profile preferences, internal notifications and existing work areas.

## Third-party software notice

Bootstrap 5.3.8 bundled CSS
Code and documentation copyright 2011-2025 The Bootstrap Authors. Code is released under the MIT License.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.



## HRX-aware health contract and server-side alarms (review-only)

The fixed baseline contract remains 49 expected tables (29 Core/Operations + 16 Finance/Procurement + 4 legacy HR/payroll). The registered HRX extension schema (33 tables) is reported separately under its own readiness check and version marker. Unknown Stockland-prefixed tables remain a contract failure and are listed by the diagnostics. A partial HRX namespace does not by itself make the fixed 49-table baseline appear incomplete.

The supplemental read-only integrity scan runs in bounded browser-resumable batches of eight SELECT-only integrity queries when the database and all required baseline tables are available, even if an extra unregistered table separately fails the exact contract. A short-lived WordPress transient holds only the scan cursor and aggregated diagnostic counts, scoped to the requesting user; it expires after 15 minutes. If a batch is interrupted, the front end can resume from the next expected cursor. If a required baseline table/database query or scan cursor is unavailable, the scan is explicitly marked NOT RUN/INCOMPLETE with a null count; it must never be reported as zero/clean. No business records are mutated by the scan.

An explicit failed deep-health result and captured PHP fatal may create deduplicated internal Stockland notifications for Owner and Management if the existing notifications table is available. Alerts are privacy-minimized, capped and deduplicated for 15 minutes per fingerprint. This does not configure external email/SMS, uptime monitoring, or hosting-provider alerts, and cannot fire on its own when no PHP/WordPress request executes. Hosting-level uptime/backup monitoring remains an operational requirement.

## ERP-wide SOP Process Center (review-only)

This candidate bundles 24 Amharic-language, document-controlled draft SOPs for the ERP-wide process set. The authenticated HR & Payroll workspace -> HR Process Center / resource-documents area lists individual DOCX downloads. A read is allowed only to the HR or Payroll view profile, each download is SHA-256 checked against `resources/erp-sops/manifest.json`, and a successful append-only Stockland audit-chain event is required before bytes are served.

The bundle contains general operating procedures only. Private employee contracts, IDs, bank information and payslips still require a host-verified private vault; they are not served by the SOP catalogue. All 24 documents are DRAFT pending Owner/process-owner approval and qualified legal review where applicable. This local review candidate has not been hash-compared with the deployed 16.1.98-HRX-REVIEW-ONLY files. It must not overwrite the live site until the live plugin ZIP/source identity is recovered, the database and uploads are backed up and restored to isolated staging, and exact-package regression passes. Existing Process Center resources must be preserved and merged, not replaced.


## Latest Owner-provided live System Health snapshot — 30 October 2026

The Owner-provided screen reports WordPress 7.1.4, plugin `16.1.98-HRX-REVIEW-ONLY`, PHP 8.4.27, MariaDB 11.4.13, DB marker 16.1.1, Core 29/29, Full ERP 49/49, and 121 REST v16 routes. It reports `schema_contract_exact_49 = FAIL` and `supplemental_integrity_scan = FAIL`; the detailed scan status is `SCAN_INCOMPLETE` with `Non-zero/unknown checks: 0`. That zero is **not a clean result**: the scan returned no reliable complete receipt, so the count must be unknown, not zero. The supplied material shows the expected distinction between a lightweight QUICK health request and an explicitly started browser-resumable DEEP integrity audit. The actual `schema_contract_details` from the live site is not present in the supplied output, so the exact missing/unexpected table key causing the failed contract is not yet confirmed. Exact source parity remains unverified.

This candidate addresses the observed presentation, contract, scan-timeout and alarm classes of defect as follows:

- Keep the fixed 49-table baseline separate from the 33 explicitly registered HRX tables; unknown Stockland-owned tables remain visible and fail the contract. The failing live check does not prove why the extra/mismatch exists until `schema_contract_details` identifies missing/unexpected keys.
- Run baseline integrity joins when the database and all required baseline tables exist, even when the exact-contract gate fails because of an extra unknown table.
- For interrupted scans, resume sequential batches using a 15-minute, user-scoped cursor. For incomplete or unexecuted scans, return `SCAN_INCOMPLETE`/`SCAN_NOT_RUN`, `healthy=false`, and a null/non-numeric check count with a reason. Never represent a skipped scan as zero.
- Render `UNKNOWN — scan incomplete` in the System Health UI, and keep the ERP-wide SOP section separate from prior HR resources.
- Add internal, deduplicated Owner/Management notifications for explicit deep-health failures and captured PHP fatal errors where the notification table is available. This is not an external email/SMS/uptime alert provider; it cannot notify when WordPress/PHP is not executing or the DB/table is unavailable.

This is local review-candidate code and local regression tests only. It has not been installed on, hash-compared with, or run through authenticated REST/browser operations against the live WordPress site. No production DDL, business data, payroll, stock, or ledger was modified.
